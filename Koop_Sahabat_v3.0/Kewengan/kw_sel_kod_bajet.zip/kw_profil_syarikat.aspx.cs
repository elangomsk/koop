﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Threading;


public partial class kw_profil_syarikat : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();
    StudentWebService service = new StudentWebService();
    string level;
    string Status = string.Empty;
    string userid;
    string ref_id;
    string confirmValue, am;
    string qry1 = string.Empty, qry2 = string.Empty;
    string tn1 = string.Empty, tc1 = string.Empty, tc2 = string.Empty, tc3 = string.Empty, tc4 = string.Empty;
    string url_name = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        app_language();
        string script = " $(function () {$('.select2').select2()});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {
               
                //level = Session["level"].ToString();
                userid = Session["New"].ToString();
               
                btb_kmes.Visible = false;
                ImgPrv.Attributes.Add("src", "../files/Profile_syarikat/user.png");
                txt_nama.Attributes.Remove("Readonly");
                txt_nombo.Attributes.Remove("Readonly");
                txt_alamat.Attributes.Remove("Readonly");
                txt_gstid.Attributes.Remove("Readonly");
                txt_email.Attributes.Remove("Readonly");
                txt_faxno.Attributes.Remove("Readonly");
                txt_teleph.Attributes.Remove("Readonly");
                ImgPrv.Attributes.Remove("Readonly");
                txt_startdt.Attributes.Remove("Readonly");
                txt_enddt.Attributes.Remove("Readonly");
                TextBox3.Attributes.Add("Readonly","Readonly");
                var samp = Request.Url.Query;
              
                if (samp != "")
                {
                    lbl_name.Text = service.Decrypt(HttpUtility.UrlDecode(Request.QueryString["edit"]));
                    view_details();
                }
                //BindData();
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
      
    }
    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('1615','705','1616','1617','709','1618','1010','1016','1011','1036','1013','1018','1011','1019','1014','1021','1620','61','35','15','77')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[15][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[9][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[15][0].ToString().ToLower());
            ps_lbl4.Text = txtinfo.ToTitleCase(gt_lng.Rows[16][0].ToString().ToLower());
            ps_lbl5.Text = txtinfo.ToTitleCase(gt_lng.Rows[19][0].ToString().ToLower());
            ps_lbl6.Text = txtinfo.ToTitleCase(gt_lng.Rows[4][0].ToString().ToLower());
            ps_lbl7.Text = txtinfo.ToTitleCase(gt_lng.Rows[17][0].ToString().ToLower());    
            ps_lbl8.Text = txtinfo.ToTitleCase(gt_lng.Rows[5][0].ToString().ToLower());
            ps_lbl9.Text = txtinfo.ToTitleCase(gt_lng.Rows[11][0].ToString().ToLower());
            ps_lbl10.Text = txtinfo.ToTitleCase(gt_lng.Rows[6][0].ToString().ToLower());
            ps_lbl11.Text = txtinfo.ToTitleCase(gt_lng.Rows[14][0].ToString().ToLower());            
            ps_lbl12.Text = txtinfo.ToTitleCase(gt_lng.Rows[7][0].ToString().ToLower());
            ps_lbl13.Text = txtinfo.ToTitleCase(gt_lng.Rows[12][0].ToString().ToLower());
            ps_lbl14.Text = txtinfo.ToTitleCase(gt_lng.Rows[6][0].ToString().ToLower());
            ps_lbl15.Text = txtinfo.ToTitleCase(gt_lng.Rows[13][0].ToString().ToLower());
            ps_lbl16.Text = txtinfo.ToTitleCase(gt_lng.Rows[10][0].ToString().ToLower());
            ps_lbl17.Text = txtinfo.ToTitleCase(gt_lng.Rows[8][0].ToString().ToLower());
            ps_lbl18.Text = txtinfo.ToTitleCase(gt_lng.Rows[18][0].ToString().ToLower());
            Button4.Text = txtinfo.ToTitleCase(gt_lng.Rows[3][0].ToString().ToLower());
            btb_kmes.Text = txtinfo.ToTitleCase(gt_lng.Rows[2][0].ToString().ToLower());
            Button1.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());
            Button2.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
            
        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }
   
    protected void get_tahun_bulan(object sender, EventArgs e)
    {
        if (txt_startdt.Text != "" && txt_enddt.Text != "")
        {
            if (chk_tahun.Checked == true)
            {
                DateTime startDate = DateTime.ParseExact(txt_startdt.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                DateTime endDate = DateTime.ParseExact(txt_enddt.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                int months = endDate.Subtract(startDate).Days / 30;


                TextBox3.Text = months.ToString();
            }
            else
            {
                TextBox3.Text = "";
            }
        }
    }
    protected void view_details()
    {
        try
        {
            if (lbl_name.Text != "")
            {

                //if (Session["con_id"].ToString() == "Yes")
                //{
                //    txt_value.Text = Session["con_id"].ToString();
                //    txt_nama.Attributes.Add("Readonly", "Readonly");
                //    txt_nombo.Attributes.Add("Readonly", "Readonly");
                //    txt_alamat.Attributes.Add("Readonly", "Readonly");
                //    txt_gstid.Attributes.Add("Readonly", "Readonly");
                //    txt_email.Attributes.Add("Readonly", "Readonly");
                //    txt_faxno.Attributes.Add("Readonly", "Readonly");
                //    txt_teleph.Attributes.Add("Readonly", "Readonly");
                //    ImgPrv.Attributes.Add("Readonly", "Readonly");
                //    txt_startdt.Attributes.Remove("Readonly");
                //    txt_enddt.Attributes.Remove("Readonly");
                //    FileUpload1.Attributes.Add("Readonly", "Readonly");

                //}
                //else if (Session["con_id"].ToString() == "No")
                //{
                //    txt_value.Text = Session["con_id"].ToString();
                //    txt_startdt.Attributes.Add("Readonly", "Readonly");
                //    txt_enddt.Attributes.Add("Readonly", "Readonly");

                //    txt_nama.Attributes.Remove("Readonly");
                //    txt_nombo.Attributes.Remove("Readonly");
                //    txt_alamat.Attributes.Remove("Readonly");
                //    txt_gstid.Attributes.Remove("Readonly");
                //    txt_email.Attributes.Remove("Readonly");
                //    txt_faxno.Attributes.Remove("Readonly");
                //    txt_teleph.Attributes.Remove("Readonly");
                //    ImgPrv.Attributes.Remove("Readonly");
                //    FileUpload1.Attributes.Remove("Readonly");
                //}
                //else
                //{
                //    txt_nama.Attributes.Add("Readonly", "Readonly");
                //    txt_nombo.Attributes.Add("Readonly", "Readonly");
                //    txt_alamat.Attributes.Add("Readonly", "Readonly");
                //    txt_gstid.Attributes.Add("Readonly", "Readonly");
                //    txt_email.Attributes.Add("Readonly", "Readonly");
                //    txt_faxno.Attributes.Add("Readonly", "Readonly");
                //    txt_teleph.Attributes.Add("Readonly", "Readonly");
                //    ImgPrv.Attributes.Add("Readonly", "Readonly");
                //    txt_startdt.Attributes.Add("Readonly", "Readonly");
                //    txt_enddt.Attributes.Add("Readonly", "Readonly");

                //}

                btb_kmes.Visible = true;
                Button4.Visible = false;
                Button1.Visible = false;

                string ogid = lbl_name.Text;
                //og_genid1.Text = og_genid.Text;

                DataTable ddokdicno = new DataTable();
                ddokdicno = DBCon.Ora_Execute_table("select * from KW_Profile_syarikat where id = '" + ogid + "'");

                FileUpload1.Attributes.Add("contentEditable", "false");
                txt_nama.Text = ddokdicno.Rows[0]["nama_syarikat"].ToString();
                txt_nombo.Text = ddokdicno.Rows[0]["kod_syarikat"].ToString();
                txt_alamat.Text = ddokdicno.Rows[0]["alamat_syarikat"].ToString();

                dd_cursts.SelectedValue = ddokdicno.Rows[0]["cur_sts"].ToString();
                TextBox3.Text = ddokdicno.Rows[0]["tahun_kew"].ToString();
                dd_tran_kew.SelectedValue = ddokdicno.Rows[0]["tt_kew"].ToString();

                txt_startdt.Text = Convert.ToDateTime(ddokdicno.Rows[0]["tarikh_mula"]).ToString("dd/MM/yyyy");
                DateTime smp = DateTime.Parse(ddokdicno.Rows[0]["tarikh_mula"].ToString());
                txt_enddt.Text = Convert.ToDateTime(ddokdicno.Rows[0]["tarikh_akhir"]).ToString("dd/MM/yyyy");

                if (smp <= DateTime.Now.Date)
                {
                    txt_startdt.Attributes.Add("Readonly", "Readonly");
                }
                else
                {
                    txt_startdt.Attributes.Remove("Readonly");
                    txt_enddt.Attributes.Remove("Readonly");
                }
                txt_gstid.Text = ddokdicno.Rows[0]["gst_id"].ToString();

                txt_email.Text = ddokdicno.Rows[0]["syar_email"].ToString();
                txt_faxno.Text = ddokdicno.Rows[0]["syar_nombo_fax"].ToString();
                txt_teleph.Text = ddokdicno.Rows[0]["syar_nombo_teleph"].ToString();


                con.Open();
                string checkimage = ddokdicno.Rows[0]["syar_logo"].ToString();

                string fileName = Path.GetFileName(checkimage);
                if (fileName != "")
                {
                    ImgPrv.Attributes.Add("src", "../Files/Profile_syarikat/" + fileName);
                }
                else
                {
                    ImgPrv.Attributes.Add("src", "../Files/Profile_syarikat/user.png");
                }
                con.Close();

            }
        }

        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void btb_kmes_Click(object sender, EventArgs e)
    {

        //confirmValue = Request.Form["confirm_value"];
        //if (txt_value.Text == "Yes")
        //{
        //    DataTable ddokdicno01 = new DataTable();
        //    ddokdicno01 = DBCon.Ora_Execute_table("select syar_logo,tarikh_mula,tarikh_akhir,syar_Cd from KW_Profile_syarikat where id = '"+ lbl_name.Text + "'");
        //    string checkimage01 = ddokdicno01.Rows[0]["syar_logo"].ToString();
        //    DateTime smp1 = DateTime.Parse(ddokdicno01.Rows[0]["tarikh_mula"].ToString());

        //    DataTable ddokdicno02 = new DataTable();
        //    ddokdicno02 = DBCon.Ora_Execute_table("select Id,Max(fin_serno) as fin_serno  From KW_financial_Year where fin_start_dt='" + smp1.Date.ToString("MM/dd/yyyy") + "' and fin_Syar_Cd='" + ddokdicno01.Rows[0]["syar_Cd"] + "' group by Id,fin_serno");

        //    if (smp1 <= DateTime.Now.Date)
        //    {
        //        //if (checkimage01 != null && checkimage01 != "")
        //        //{
        //            if (txt_startdt.Text != "" && txt_enddt.Text != "")
        //            {
        //                SqlCommand prof_upd = new SqlCommand("update KW_Profile_syarikat set tarikh_akhir=@tarikh_akhir, upd_dt=@upd_dt,upd_id=@upd_id where Id=@Id", con);
        //                SqlCommand prof_del = new SqlCommand("delete KW_financial_Year where fin_start_dt > '" + smp1.Date.ToString("MM/dd/yyyy") + "' and fin_Syar_Cd='" + ddokdicno01.Rows[0]["syar_Cd"] + "'", con);

        //                con.Open();
        //                int i = prof_del.ExecuteNonQuery();
        //                con.Close();


        //                prof_upd.Parameters.AddWithValue("id", lbl_name.Text);


        //                string str = txt_startdt.Text;
        //                DateTime dt;
        //                dt = DateTime.ParseExact(str, "dd/MM/yyyy", CultureInfo.InvariantCulture);
        //                prof_upd.Parameters.AddWithValue("@tarikh_mula", dt);

        //                string str1 = txt_enddt.Text;
        //                DateTime dt1;
        //                dt1 = DateTime.ParseExact(str1, "dd/MM/yyyy", CultureInfo.InvariantCulture);

        //                double days2 = (dt1.Date - dt.Date).TotalDays;

        //                prof_upd.Parameters.AddWithValue("@tarikh_akhir", dt1);
        //                prof_upd.Parameters.AddWithValue("upd_id", Session["New"].ToString());
        //                prof_upd.Parameters.AddWithValue("upd_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );



        //                con.Open();
        //                int j = prof_upd.ExecuteNonQuery();
        //                con.Close();


        //                SqlCommand prof_upd1 = new SqlCommand("update KW_financial_Year set fin_end_dt=@fin_end_dt,fin_months=@fin_months, upd_dt=@upd_dt,upd_id=@upd_id where Id='" + ddokdicno02.Rows[0]["Id"] + "'", con);
        //                prof_upd1.Parameters.AddWithValue("@fin_end_dt", dt1);
        //                prof_upd1.Parameters.AddWithValue("upd_id", Session["New"].ToString());
        //                prof_upd1.Parameters.AddWithValue("upd_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );
        //                prof_upd1.Parameters.AddWithValue("@fin_months", days2);
        //                con.Open();
        //                int jk = prof_upd1.ExecuteNonQuery();
        //                con.Close();
        //                string serino = ddokdicno02.Rows[0]["fin_serno"].ToString();
        //                DataTable ddokdicno1 = new DataTable();
        //                ddokdicno1 = DBCon.Ora_Execute_table("select fin_start_dt,fin_end_dt From KW_financial_Year where fin_Syar_Cd='" + ddokdicno01.Rows[0]["syar_Cd"] + "' and fin_serno='" + serino + "'");

        //                int ctr = 1;
        //                do
        //                {
        //                    //int q = ctr - 1;
        //                    //string serino = ddokdicno02.Rows[0]["fin_serno"].ToString();
        //                    int q1 = ctr - 1;
        //                    DataTable ddokdicno11 = new DataTable();
        //                    ddokdicno1 = DBCon.Ora_Execute_table("select fin_start_dt,fin_end_dt From KW_financial_Year where fin_Syar_Cd='" + ddokdicno01.Rows[0]["syar_Cd"] + "' and fin_serno='" + q1 + "'");

        //                    if (ddokdicno1.Rows.Count == 1)
        //                    {
        //                        SqlCommand ins_prof2 = new SqlCommand("insert into [KW_financial_Year] (fin_Syar_Cd,fin_start_dt,fin_end_dt,fin_months,Status,crt_id,cr_dt,fin_serno) values(@fin_Syar_Cd,@fin_start_dt,@fin_end_dt,@fin_months,@Status,@crt_id,@cr_dt,@fin_serno)", con);
        //                        string abc = Convert.ToDateTime(ddokdicno1.Rows[0][0]).ToString("dd/MM/yyyy");
        //                        DateTime abc1;
        //                        abc1 = Convert.ToDateTime(DateTime.ParseExact(abc, "dd/MM/yyyy", CultureInfo.InvariantCulture));
        //                        string cde = Convert.ToDateTime(ddokdicno1.Rows[0][1]).ToString("dd/MM/yyyy");
        //                        DateTime cde1;
        //                        cde1 = Convert.ToDateTime(DateTime.ParseExact(cde, "dd/MM/yyyy", CultureInfo.InvariantCulture));
        //                        double days1 = (cde1.Date - abc1.Date).TotalDays;
        //                        double days = (dt1.Date - dt.Date).TotalDays;
        //                        double mnth = ((dt1.Year * 12) + dt1.Month) - ((dt.Year * 12) + dt.Month);
        //                        double year = dt1.Year - dt.Year;

        //                        int d = Convert.ToInt32(days1);
        //                        int m = Convert.ToInt32(mnth);
        //                        int y = Convert.ToInt32(year);

        //                        DateTime fdate;
        //                        fdate = cde1.AddDays(+1);

        //                        DateTime tdate1;

        //                        if (ctr == int.Parse(serino))
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 2);
        //                            }

        //                        }
        //                        else if (ctr == 3)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + (int.Parse(serino) - 1));
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + (int.Parse(serino) - 1));
        //                            }
        //                        }
        //                        else if (ctr == 4)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d);
        //                            }
        //                        }
        //                        else if (ctr == 7)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                        }
        //                        else if (ctr == 9)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                        }
        //                        else if (ctr == 11)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 2);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 2);
        //                            }
        //                        }
        //                        else
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d);
        //                            }
        //                        }

        //                        ins_prof2.Parameters.AddWithValue("@fin_months", d);
        //                        ins_prof2.Parameters.AddWithValue("@Status", 'A');
        //                        ins_prof2.Parameters.AddWithValue("@fin_Syar_Cd", ddokdicno01.Rows[0]["syar_Cd"]);
        //                        ins_prof2.Parameters.AddWithValue("@fin_start_dt", fdate);
        //                        ins_prof2.Parameters.AddWithValue("@fin_end_dt", tdate1);

        //                        ins_prof2.Parameters.AddWithValue("@fin_serno", ctr + 1);
        //                        ins_prof2.Parameters.AddWithValue("@crt_id", Session["New"].ToString());
        //                        ins_prof2.Parameters.AddWithValue("@cr_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );

        //                        con.Open();
        //                        int k = ins_prof2.ExecuteNonQuery();
        //                        con.Close();


                                
        //                    }

        //                    ctr++;
        //                }
        //            while (ctr <= 15);
        //            Session["validate_success"] = "SUCCESS";
        //            Session["alrt_msg"] = "Rekod Berjaya Dikemaskini.";
        //            Response.Redirect("../kewengan/kw_profil_syarikat_view.aspx");
        //        }
        //        //}
        //    }
        //    else
        //    {
        //        //if (checkimage01 != null && checkimage01 != "")
        //        //{
        //            if (txt_startdt.Text != "" && txt_enddt.Text != "")
        //            {
        //                SqlCommand prof_upd = new SqlCommand("update KW_Profile_syarikat set tarikh_mula=@tarikh_mula, tarikh_akhir=@tarikh_akhir, upd_dt=@upd_dt,upd_id=@upd_id where Id=@Id", con);
        //                SqlCommand prof_del = new SqlCommand("delete KW_financial_Year where fin_start_dt>'" + smp1.Date.ToString("MM/dd/yyyy") + "' and fin_Syar_Cd='" + ddokdicno01.Rows[0]["syar_Cd"] + "'", con);

        //                con.Open();
        //                int i = prof_del.ExecuteNonQuery();
        //                con.Close();

        //                prof_upd.Parameters.AddWithValue("id", lbl_name.Text);

        //                string str = txt_startdt.Text;
        //                DateTime dt;
        //                dt = DateTime.ParseExact(str, "dd/MM/yyyy", CultureInfo.InvariantCulture);
        //                prof_upd.Parameters.AddWithValue("@tarikh_mula", dt);

        //                string str1 = txt_enddt.Text;
        //                DateTime dt1;
        //                dt1 = DateTime.ParseExact(str1, "dd/MM/yyyy", CultureInfo.InvariantCulture);

        //                double days2 = (dt1.Date - dt.Date).TotalDays;

        //                prof_upd.Parameters.AddWithValue("@tarikh_akhir", dt1);
        //                prof_upd.Parameters.AddWithValue("upd_id", Session["New"].ToString());
        //                prof_upd.Parameters.AddWithValue("upd_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );



        //                con.Open();
        //                int j = prof_upd.ExecuteNonQuery();
        //                con.Close();


        //                SqlCommand prof_upd1 = new SqlCommand("update KW_financial_Year set fin_start_dt=@fin_start_dt,fin_end_dt=@fin_end_dt,fin_months=@fin_months, upd_dt=@upd_dt,upd_id=@upd_id where Id='" + ddokdicno02.Rows[0]["Id"] + "'", con);
        //                prof_upd1.Parameters.AddWithValue("@fin_start_dt", dt);
        //                prof_upd1.Parameters.AddWithValue("@fin_end_dt", dt1);
        //                prof_upd1.Parameters.AddWithValue("upd_id", Session["New"].ToString());
        //                prof_upd1.Parameters.AddWithValue("upd_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );
        //                prof_upd1.Parameters.AddWithValue("@fin_months", days2);
        //                con.Open();
        //                int jk = prof_upd1.ExecuteNonQuery();
        //                con.Close();
        //                string serino = ddokdicno02.Rows[0]["fin_serno"].ToString();
        //                DataTable ddokdicno1 = new DataTable();
        //                ddokdicno1 = DBCon.Ora_Execute_table("select fin_start_dt,fin_end_dt From KW_financial_Year where fin_Syar_Cd='" + ddokdicno01.Rows[0]["syar_Cd"] + "' and fin_serno='" + serino + "'");

        //                int ctr = 1;
        //                do
        //                {
        //                    //int q = ctr - 1;
        //                    //string serino = ddokdicno02.Rows[0]["fin_serno"].ToString();
        //                    int q1 = ctr - 1;
        //                    DataTable ddokdicno11 = new DataTable();
        //                    ddokdicno1 = DBCon.Ora_Execute_table("select fin_start_dt,fin_end_dt From KW_financial_Year where fin_Syar_Cd='" + ddokdicno01.Rows[0]["syar_Cd"] + "' and fin_serno='" + q1 + "'");

        //                    if (ddokdicno1.Rows.Count == 1)
        //                    {
        //                        SqlCommand ins_prof2 = new SqlCommand("insert into [KW_financial_Year] (fin_Syar_Cd,fin_start_dt,fin_end_dt,fin_months,Status,crt_id,cr_dt,fin_serno) values(@fin_Syar_Cd,@fin_start_dt,@fin_end_dt,@fin_months,@Status,@crt_id,@cr_dt,@fin_serno)", con);
        //                        string abc = Convert.ToDateTime(ddokdicno1.Rows[0][0]).ToString("dd/MM/yyyy");
        //                        DateTime abc1;
        //                        abc1 = Convert.ToDateTime(DateTime.ParseExact(abc, "dd/MM/yyyy", CultureInfo.InvariantCulture));
        //                        string cde = Convert.ToDateTime(ddokdicno1.Rows[0][1]).ToString("dd/MM/yyyy");
        //                        DateTime cde1;
        //                        cde1 = Convert.ToDateTime(DateTime.ParseExact(cde, "dd/MM/yyyy", CultureInfo.InvariantCulture));
        //                        double days1 = (cde1.Date - abc1.Date).TotalDays;
        //                        double days = (dt1.Date - dt.Date).TotalDays;
        //                        double mnth = ((dt1.Year * 12) + dt1.Month) - ((dt.Year * 12) + dt.Month);
        //                        double year = dt1.Year - dt.Year;

        //                        int d = Convert.ToInt32(days1);
        //                        int m = Convert.ToInt32(mnth);
        //                        int y = Convert.ToInt32(year);

        //                        DateTime fdate;
        //                        fdate = cde1.AddDays(+1);

        //                        DateTime tdate1;

        //                        if (ctr == int.Parse(serino))
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 2);
        //                            }

        //                        }
        //                        else if (ctr == 3)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + (int.Parse(serino) - 1));
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + (int.Parse(serino) - 1));
        //                            }
        //                        }
        //                        else if (ctr == 4)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d);
        //                            }
        //                        }
        //                        else if (ctr == 7)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                        }
        //                        else if (ctr == 9)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 1);
        //                            }
        //                        }
        //                        else if (ctr == 11)
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 2);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d + 2);
        //                            }
        //                        }
        //                        else
        //                        {
        //                            if (d < 364)
        //                            {
        //                                tdate1 = abc1.AddDays(days2 + d + 1);
        //                            }
        //                            else if (d == 364)
        //                            {
        //                                tdate1 = abc1.AddDays(d + d);
        //                            }
        //                            else
        //                            {
        //                                tdate1 = abc1.AddDays(d + d);
        //                            }
        //                        }

        //                        ins_prof2.Parameters.AddWithValue("@fin_months", d);
        //                        ins_prof2.Parameters.AddWithValue("@Status", 'A');
        //                        ins_prof2.Parameters.AddWithValue("@fin_Syar_Cd", ddokdicno01.Rows[0]["syar_Cd"]);
        //                        ins_prof2.Parameters.AddWithValue("@fin_start_dt", fdate);
        //                        ins_prof2.Parameters.AddWithValue("@fin_end_dt", tdate1);

        //                        ins_prof2.Parameters.AddWithValue("@fin_serno", ctr + 1);
        //                        ins_prof2.Parameters.AddWithValue("@crt_id", Session["New"].ToString());
        //                        ins_prof2.Parameters.AddWithValue("@cr_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );

        //                        con.Open();
        //                        int k = ins_prof2.ExecuteNonQuery();
        //                        con.Close();

        //                        Session["validate_success"] = "SUCCESS";
        //                        Session["alrt_msg"] = "Rekod Berjaya Dikemaskini.";
        //                        Response.Redirect("../kewengan/kw_profil_syarikat_view.aspx");

        //                    }

        //                    ctr++;
        //                } while (ctr <= 15);

        //            }
        //        //}
        //    }
        //}

        //else if (txt_value.Text == "No")
        //{
            DataTable ddokdicno = new DataTable();
            ddokdicno = DBCon.Ora_Execute_table("select * from KW_Profile_syarikat where id = '"+ lbl_name.Text + "'");
            string checkimage = ddokdicno.Rows[0]["syar_logo"].ToString();
            if (checkimage != null && checkimage != "")
            {
                if (txt_startdt.Text != "" && txt_enddt.Text != "" && txt_nombo.Text != "" && txt_alamat.Text != "")
                {
                    SqlCommand prof_upd = new SqlCommand("update KW_Profile_syarikat set kod_syarikat=@kod_syarikat,nama_syarikat=@nama_syarikat,alamat_syarikat=@alamat_syarikat,gst_id=@gst_id,syar_email=@syar_email,syar_nombo_fax=@syar_nombo_fax,syar_nombo_teleph=@syar_nombo_teleph, upd_dt=@upd_dt,upd_id=@upd_id,cur_sts=@cur_sts,tt_kew=@tt_kew,tahun_kew=@tahun_kew where Id=@Id", con);
                    prof_upd.Parameters.AddWithValue("id", lbl_name.Text);
                    prof_upd.Parameters.AddWithValue("kod_syarikat", txt_nombo.Text);
                    prof_upd.Parameters.AddWithValue("nama_syarikat", txt_nama.Text);
                    prof_upd.Parameters.AddWithValue("alamat_syarikat", txt_alamat.Text);
                    prof_upd.Parameters.AddWithValue("@gst_id", txt_gstid.Text);
                    prof_upd.Parameters.AddWithValue("@syar_email", txt_email.Text);
                    prof_upd.Parameters.AddWithValue("@syar_nombo_fax", txt_faxno.Text);
                    prof_upd.Parameters.AddWithValue("@syar_nombo_teleph", txt_teleph.Text);
                    prof_upd.Parameters.AddWithValue("upd_id", Session["New"].ToString());
                    prof_upd.Parameters.AddWithValue("upd_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );
                    prof_upd.Parameters.AddWithValue("cur_sts", dd_cursts.SelectedValue);
                    prof_upd.Parameters.AddWithValue("tt_kew", dd_tran_kew.SelectedValue);
                    prof_upd.Parameters.AddWithValue("tahun_kew", TextBox3.Text);
                    con.Open();
                    int j = prof_upd.ExecuteNonQuery();
                    con.Close();

                    Session["validate_success"] = "SUCCESS";
                    Session["alrt_msg"] = "Rekod Berjaya Dikemaskini.";
                    Response.Redirect("../kewengan/kw_profil_syarikat_view.aspx");
                }
            }
            else if (checkimage == null || checkimage == "")
            {
                //if (FileUpload1.HasFile)
                //{
                string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                if (txt_startdt.Text != "" && txt_enddt.Text != "" && txt_nombo.Text != "" && txt_alamat.Text != "")
                {

                    if (fileName != "")
                    {
                        FileUpload1.PostedFile.SaveAs(Server.MapPath("~/FILES/Profile_syarikat/" + fileName));//Or code to save in the DataBase.
                        System.Drawing.Image img = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        decimal size = Math.Round(((decimal)FileUpload1.PostedFile.ContentLength / (decimal)1024), 2);
                    }
                    //if (size <= 100)
                    //{
                    SqlCommand prof_upd = new SqlCommand("update KW_Profile_syarikat set kod_syarikat=@kod_syarikat,nama_syarikat=@nama_syarikat,alamat_syarikat=@alamat_syarikat,gst_id=@gst_id,syar_email=@syar_email,syar_nombo_fax=@syar_nombo_fax,syar_nombo_teleph=@syar_nombo_teleph,syar_logo=@syar_logo, upd_dt=@upd_dt,upd_id=@upd_id,cur_sts=@cur_sts,tt_kew=@tt_kew,tahun_kew=@tahun_kew where Id=@Id", con);
                    prof_upd.Parameters.AddWithValue("id", lbl_name.Text);
                    prof_upd.Parameters.AddWithValue("kod_syarikat", txt_nombo.Text);
                    prof_upd.Parameters.AddWithValue("nama_syarikat", txt_nama.Text);
                    prof_upd.Parameters.AddWithValue("alamat_syarikat", txt_alamat.Text);

                    prof_upd.Parameters.AddWithValue("@gst_id", txt_gstid.Text);
                    prof_upd.Parameters.AddWithValue("@syar_email", txt_email.Text);
                    prof_upd.Parameters.AddWithValue("@syar_nombo_fax", txt_faxno.Text);
                    prof_upd.Parameters.AddWithValue("@syar_nombo_teleph", txt_teleph.Text);
                    prof_upd.Parameters.AddWithValue("@syar_logo", fileName);
                    prof_upd.Parameters.AddWithValue("upd_id", Session["New"].ToString());
                    prof_upd.Parameters.AddWithValue("upd_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );
                    prof_upd.Parameters.AddWithValue("cur_sts", dd_cursts.SelectedValue);
                    prof_upd.Parameters.AddWithValue("tt_kew", dd_tran_kew.SelectedValue);
                    prof_upd.Parameters.AddWithValue("tahun_kew", TextBox3.Text);
                    con.Open();
                    int j = prof_upd.ExecuteNonQuery();
                    con.Close();
                    
                    Session["validate_success"] = "SUCCESS";
                    Session["alrt_msg"] = "Rekod Berjaya Dikemaskini.";
                    Response.Redirect("../kewengan/kw_profil_syarikat_view.aspx");

                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukan Input Carian.',{'type': 'warning','title': 'Warning','auto_close': 2000}); ", true);

                }
               
            }
        //}
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Session["validate_success"] = "";
        Session["alrt_msg"] = "";
        Session["con_id"] = "";
        Response.Redirect("../kewengan/kw_profil_syarikat.aspx");
    }
    SqlDataAdapter adapt;
    DataTable dt;


    protected void Button4_Click(object sender, EventArgs e)
    {
        try
        {
            if (txt_nama.Text != "" && txt_nombo.Text != "" && txt_startdt.Text != "" && txt_enddt.Text != "")
            {
                string str = txt_startdt.Text;
                DateTime dt = DateTime.ParseExact(str, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                string str1 = txt_enddt.Text;
                DateTime dt1 = DateTime.ParseExact(str1, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                DataTable chk_profil = new DataTable();
                chk_profil = DBCon.Ora_Execute_table("select * from KW_Profile_syarikat where kod_syarikat = '" + txt_nombo.Text + "' and nama_syarikat='" + txt_nama.Text.Replace("'", "''") + "' and '" + dt + "' between tarikh_mula and tarikh_akhir");
                if (chk_profil.Rows.Count == 0)
                {
                    DataTable ddicno = new DataTable();
                    int contentLength = FileUpload1.PostedFile.ContentLength; //You may need it for validation
                    string contentType = FileUpload1.PostedFile.ContentType; //You may need it for validation
                    string fileName = FileUpload1.PostedFile.FileName;
                    if (fileName != "")
                    {
                        FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Files/Profile_syarikat/" + fileName));//Or code to save in the DataBase.
                        System.Drawing.Image img = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        decimal size = Math.Round(((decimal)FileUpload1.PostedFile.ContentLength / (decimal)1024), 2);
                    }
                    //if (size <= 100)
                    //{

                    SqlCommand ins_prof = new SqlCommand("insert into KW_Profile_syarikat (kod_syarikat,nama_syarikat,alamat_syarikat,tarikh_mula,tarikh_akhir,gst_id,syar_email,syar_nombo_fax,syar_nombo_teleph,Status,cr_dt,crt_id,syar_Cd,syar_logo,cur_sts,tt_kew,tahun_kew)values(@kod_syarikat,@nama_syarikat,@alamat_syarikat,@tarikh_mula,@tarikh_akhir,@gst_id,@syar_email,@syar_nombo_fax,@syar_nombo_teleph,@Status,@cr_dt,@crt_id,@syar_Cd,@syar_logo,@cur_sts,@tt_kew,@tahun_kew)", con);

                    ins_prof.Parameters.AddWithValue("@kod_syarikat", txt_nombo.Text);
                    ins_prof.Parameters.AddWithValue("@nama_syarikat", txt_nama.Text.Replace("'", "''"));
                    ins_prof.Parameters.AddWithValue("@alamat_syarikat", txt_alamat.Text.Replace("'", "''"));
                    ins_prof.Parameters.AddWithValue("@tarikh_mula", dt);
                    ins_prof.Parameters.AddWithValue("@tarikh_akhir", dt1);
                    ins_prof.Parameters.AddWithValue("@gst_id", txt_gstid.Text.Replace("'", "''"));
                    ins_prof.Parameters.AddWithValue("@syar_email", txt_email.Text.Replace("'", "''"));
                    ins_prof.Parameters.AddWithValue("@syar_nombo_fax", txt_faxno.Text.Replace("'", "''"));
                    ins_prof.Parameters.AddWithValue("@syar_nombo_teleph", txt_teleph.Text.Replace("'", "''"));
                    ins_prof.Parameters.AddWithValue("@syar_logo", fileName);
                    ins_prof.Parameters.AddWithValue("@cur_sts", dd_cursts.SelectedValue);
                    ins_prof.Parameters.AddWithValue("@tt_kew", dd_tran_kew.SelectedValue);
                    ins_prof.Parameters.AddWithValue("@tahun_kew", TextBox3.Text);
                    ins_prof.Parameters.AddWithValue("@Status", 'A');
                    ins_prof.Parameters.AddWithValue("@syar_Cd", "");
                    ins_prof.Parameters.AddWithValue("@crt_id", Session["New"].ToString());
                    ins_prof.Parameters.AddWithValue("@cr_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    con.Open();
                    int i = ins_prof.ExecuteNonQuery();
                    con.Close();
                    ////string Row = "";
                    //DataTable ddokdicno = new DataTable();
                    //ddokdicno = DBCon.Ora_Execute_table("select Count(*)+1 from KW_Profile_syarikat");
                    //string Row = "00" + ddokdicno.Rows[0][0].ToString();
                    //if (dt == dt1)
                    //{
                    //    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Date should not be same!!.');", true);
                    //}
                    //else if (dt > dt1)
                    //{
                    //    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('End Date should Greater then From Date!!.');", true);
                    //}
                    //else if (dt < dt1)
                    //{
                    //    double days = (dt1.Date - dt.Date).TotalDays;
                    //    double mnth = ((dt1.Year * 12) + dt1.Month) - ((dt.Year * 12) + dt.Month);
                    //    double year = dt1.Year - dt.Year;
                    //    if (days <= 0 || days < 30)
                    //    {
                    //        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Month Should not less Then 30 Days!!.');", true);
                    //    }
                    //    else if (days <= 365)
                    //    {
                    //        //ins_prof.Parameters.AddWithValue("@syar_Cd", Row);
                    //        //ins_prof.Parameters.AddWithValue("@crt_id", Session["New"].ToString());
                    //        //ins_prof.Parameters.AddWithValue("@cr_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );
                    //        //con.Open();
                    //        //int i = ins_prof.ExecuteNonQuery();
                    //        //con.Close();

                    //        SqlCommand ins_prof1 = new SqlCommand("insert into [KW_financial_Year] (fin_Syar_Cd,fin_start_dt,fin_end_dt,fin_months,Status,crt_id,cr_dt,fin_serno) values(@fin_Syar_Cd,@fin_start_dt,@fin_end_dt,@fin_months,@Status,@crt_id,@cr_dt,@fin_serno)", con);
                    //        ins_prof1.Parameters.AddWithValue("@fin_months", days);
                    //        ins_prof1.Parameters.AddWithValue("@Status", 'A');
                    //        ins_prof1.Parameters.AddWithValue("@fin_Syar_Cd", Row);
                    //        ins_prof1.Parameters.AddWithValue("@fin_start_dt", dt);
                    //        ins_prof1.Parameters.AddWithValue("@fin_end_dt", dt1);
                    //        ins_prof1.Parameters.AddWithValue("@fin_serno", "1");
                    //        ins_prof1.Parameters.AddWithValue("@crt_id", Session["New"].ToString());
                    //        ins_prof1.Parameters.AddWithValue("@cr_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );
                    //        con.Open();
                    //        int j = ins_prof1.ExecuteNonQuery();
                    //        con.Close();
                    //        int ctr = 1;
                    //        do
                    //        {
                    //            int q = ctr - 1;
                    //            DataTable ddokdicno1 = new DataTable();
                    //            ddokdicno1 = DBCon.Ora_Execute_table("select fin_start_dt,fin_end_dt From KW_financial_Year where fin_Syar_Cd='" + Row + "' and fin_serno='" + q + "'");

                    //            if (ddokdicno1.Rows.Count == 1)
                    //            {
                    //                SqlCommand ins_prof2 = new SqlCommand("insert into [KW_financial_Year] (fin_Syar_Cd,fin_start_dt,fin_end_dt,fin_months,Status,crt_id,cr_dt,fin_serno) values(@fin_Syar_Cd,@fin_start_dt,@fin_end_dt,@fin_months,@Status,@crt_id,@cr_dt,@fin_serno)", con);
                    //                string abc = Convert.ToDateTime(ddokdicno1.Rows[0][0]).ToString("dd/MM/yyyy");
                    //                DateTime abc1;
                    //                abc1 = Convert.ToDateTime(DateTime.ParseExact(abc, "dd/MM/yyyy", CultureInfo.InvariantCulture));
                    //                string cde = Convert.ToDateTime(ddokdicno1.Rows[0][1]).ToString("dd/MM/yyyy");
                    //                DateTime cde1;
                    //                cde1 = Convert.ToDateTime(DateTime.ParseExact(cde, "dd/MM/yyyy", CultureInfo.InvariantCulture));
                    //                double days1 = (cde1.Date - abc1.Date).TotalDays;
                    //                int d = Convert.ToInt32(days1);
                    //                int m = Convert.ToInt32(mnth);
                    //                int y = Convert.ToInt32(year);

                    //                DateTime fdate;
                    //                fdate = cde1.AddDays(+1);

                    //                DateTime tdate1;

                    //                if (ctr == 2)
                    //                {
                    //                    if (d < 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(days + d + 1);
                    //                    }
                    //                    else if (d == 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(days + d + 1);
                    //                    }
                    //                    else
                    //                    {
                    //                        tdate1 = abc1.AddDays(days + d + 2);
                    //                    }

                    //                }
                    //                else if (ctr == 4)
                    //                {
                    //                    if (d < 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + 1);
                    //                    }
                    //                    else if (d == 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + (q - 1));
                    //                    }
                    //                    else
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + (q - 1));
                    //                    }
                    //                }
                    //                else if (ctr == 6)
                    //                {
                    //                    if (d < 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + 1);
                    //                    }
                    //                    else if (d == 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d);
                    //                    }
                    //                    else
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d);
                    //                    }
                    //                }
                    //                else if (ctr == 8)
                    //                {
                    //                    if (d < 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(days + d + 1);
                    //                    }
                    //                    else if (d == 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + 1);
                    //                    }
                    //                    else
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + 1);
                    //                    }
                    //                }
                    //                else if (ctr == 10)
                    //                {
                    //                    if (d < 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(days + d + 1);
                    //                    }
                    //                    else if (d == 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + 1);
                    //                    }
                    //                    else
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + 1);
                    //                    }
                    //                }
                    //                else if (ctr == 12)
                    //                {
                    //                    if (d < 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(days + d + 1);
                    //                    }
                    //                    else if (d == 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + 2);
                    //                    }
                    //                    else
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d + 2);
                    //                    }
                    //                }
                    //                else
                    //                {
                    //                    if (d < 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(days + d + 1);
                    //                    }
                    //                    else if (d == 364)
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d);
                    //                    }
                    //                    else
                    //                    {
                    //                        tdate1 = abc1.AddDays(d + d);
                    //                    }
                    //                }

                    //                ins_prof2.Parameters.AddWithValue("@fin_months", d);
                    //                ins_prof2.Parameters.AddWithValue("@Status", 'A');
                    //                ins_prof2.Parameters.AddWithValue("@fin_Syar_Cd", Row);
                    //                ins_prof2.Parameters.AddWithValue("@fin_start_dt", fdate);
                    //                ins_prof2.Parameters.AddWithValue("@fin_end_dt", tdate1);

                    //                ins_prof2.Parameters.AddWithValue("@fin_serno", ctr + 1);
                    //                ins_prof2.Parameters.AddWithValue("@crt_id", Session["New"].ToString());
                    //                ins_prof2.Parameters.AddWithValue("@cr_dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") );

                    //                con.Open();
                    //                int k = ins_prof2.ExecuteNonQuery();
                    //                con.Close();
                    //            }

                    //            ctr++;
                    //        } while (ctr <= 15);

                    Session["validate_success"] = "SUCCESS";
                    Session["alrt_msg"] = "Rekod Berjaya Disimpan.";
                    Response.Redirect("../kewengan/kw_profil_syarikat_view.aspx");
                    //ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('" + Session["alrt_msg"].ToString() + "',{'type': 'confirmation','title': 'Success'});window.location ='../kewengan/kw_profil_syarikat_view.aspx';", true);
                    //}
                    //else
                    //{
                    //    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('No of days should be less then 365!!.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
                    //}                

                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Sedia Ada.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukan Input Carian.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void Click_bck(object sender, EventArgs e)
    {
        Session["validate_success"] = "";
        Session["alrt_msg"] = "";
        Session["con_id"] = "";
        Response.Redirect("../kewengan/kw_profil_syarikat_view.aspx");
    }

    
}