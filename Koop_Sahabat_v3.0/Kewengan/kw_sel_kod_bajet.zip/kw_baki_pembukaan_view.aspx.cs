﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;

public partial class kw_baki_pembukaan_view : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();

    string level;
    string Status = string.Empty, Status1 = string.Empty;
    string userid;
    string ref_id;
    string confirmValue, am;
    string qry1 = string.Empty, qry2 = string.Empty;
    string tn1 = string.Empty, tc1 = string.Empty, tc2 = string.Empty, tc3 = string.Empty, tc4 = string.Empty;
    string get_stt = string.Empty, get_edt = string.Empty;
    string str_sdt1 = string.Empty, end_edt1 = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        app_language();
        DataTable sel_gst2 = new DataTable();
        sel_gst2 = DBCon.Ora_Execute_table("select top(1) Format(tarikh_mula,'dd/MM/yyyy') as st_dt,Format(tarikh_akhir,'dd/MM/yyyy') as end_dt from kw_profile_syarikat where cur_sts='1' order by tarikh_akhir desc");

        if (sel_gst2.Rows.Count != 0)
        {
            get_stt = sel_gst2.Rows[0]["st_dt"].ToString();
            get_edt = sel_gst2.Rows[0]["end_dt"].ToString();
            DateTime fd = DateTime.ParseExact(get_stt, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            DateTime fd1 = DateTime.ParseExact(get_edt, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            str_sdt1 = fd.ToString("yyyy-MM-dd");
            end_edt1 = fd1.ToString("yyyy-MM-dd");


        }
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.Button2);
        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {
                if (Session["validate_success"].ToString() == "SUCCESS")
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('"+ Session["alrt_msg"].ToString() + "',{'type': 'confirmation','title': 'Success'});", true);
                   
                }
                no_akaun.Attributes.Add("Readonly", "Readonly");
                txt_nama_akaun.Attributes.Add("Readonly", "Readonly");
                Session["validate_success"] = "";
                Session["alrt_msg"] = "";
                userid = Session["New"].ToString();
                BindData();
                BindGrid();
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
    }
    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('721','705','14','36')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[3][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[2][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[3][0].ToString().ToLower());             
            button4.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());
            Button2.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
           

        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }
    protected void BindData()
    {
        string sqry = string.Empty;
        if (txtSearch.Text == "")
        {
            sqry = "";
        }
        else
        {
            sqry = "where m1.nama_akaun LIKE'%" + txtSearch.Text + "%' OR m1.kod_akaun LIKE'%" + txtSearch.Text + "%'";
        }

        //string query = "select * from KW_Ref_Carta_Akaun " + sqry + "";

        string query = "select m1.Id,m1.jenis_akaun_type,m1.kat_akaun,m1.nama_akaun,m1.kod_akaun,m1.jenis_akaun,m1.under_parent,case when s1.opening_amt > 0 then opening_amt else '0.00' end as KW_Debit_amt,case when s1.opening_amt < 0 then opening_amt else '0.00' end as KW_kredit_amt from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and s1.kat_akaun=m1.kat_akaun and s1.start_dt='" + str_sdt1 + "' and s1.end_dt='" + end_edt1 + "' and s1.set_sts='1' " + sqry + " order by kat_akaun";

        //string query = "BEGIN  with  ITERATE_NODES_RECURSIVE AS (select a1.kat_akaun,a1.kod_akaun,a1.nama_akaun,a1.Id,a1.under_parent, case when a1.under_parent = '0' then a1.nama_akaun else a2.nama_akaun end as jenis_name, 0 as LEVEL_DEPTH,a1.KW_Debit_amt,a1.KW_kredit_amt,a1.Kw_open_amt,a1.under_jenis,a1.jenis_akaun_type from dbo.KW_Ref_Carta_Akaun a1 left join dbo.KW_Ref_Carta_Akaun as a2 on a2.kod_akaun=a1.jenis_akaun where (a1.Id IN (select Id from dbo.KW_Ref_Carta_Akaun where (under_parent = '0')))UNION ALL select super.kat_akaun,super.kod_akaun,super.nama_akaun,super.Id,super.under_parent,case when super.under_parent = '0' then super.nama_akaun else sub.nama_akaun end as jenis_name, sub.LEVEL_DEPTH + 1  as LEVEL_DEPTH,super.KW_Debit_amt,super.KW_kredit_amt,super.Kw_open_amt,super.under_jenis,super.jenis_akaun_type from dbo.KW_Ref_Carta_Akaun as super INNER JOIN ITERATE_NODES_RECURSIVE as sub on sub.id=super.under_parent ) select m1.Id,m1.jenis_akaun_type,m1.kat_akaun,m1.nama_akaun,m1.kod_akaun,m1.under_parent,case when s1.opening_amt > 0 then opening_amt else '0.00' end as KW_Debit_amt,case when s1.opening_amt < 0 then opening_amt else '0.00' end as KW_kredit_amt from ITERATE_NODES_RECURSIVE m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and s1.kat_akaun=m1.kat_akaun and s1.set_sts='1' " + sqry + " order by m1.kat_akaun,m1.Id,m1.LEVEL_DEPTH; END ";

        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        DataSet ds = new DataSet();
                        sda.Fill(ds);
                        if (ds.Tables[0].Rows.Count != 0)
                        {
                            GridView1.DataSource = dt;
                            GridView1.DataBind();

                            //Calculate Sum and display in Footer Row
                            decimal debit = dt.AsEnumerable().Sum(row => row.Field<decimal>("KW_Debit_amt"));
                            decimal kredit = dt.AsEnumerable().Sum(row => row.Field<decimal>("KW_Kredit_amt"));
                            GridView1.FooterRow.Cells[2].Text = "<strong>JUMLAH (RM)</strong>";
                            GridView1.FooterRow.Cells[2].HorizontalAlign = HorizontalAlign.Right;
                            GridView1.FooterRow.Cells[3].HorizontalAlign = HorizontalAlign.Right;
                            GridView1.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                            GridView1.FooterRow.Cells[3].Text = debit.ToString("C").Replace("RM", "").Replace("$", "");
                            GridView1.FooterRow.Cells[4].Text = kredit.ToString("C").Replace("RM", "").Replace("$", "");
                        }

                    }
                }
            }
        }
    }

    protected void gv_refdata_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ViewState["PreviousRowIndex"] = null;
        BindData();
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        System.Web.UI.WebControls.Label lnk2 = (System.Web.UI.WebControls.Label)e.Row.FindControl("og_genid");
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataTable get_value = new DataTable();
            get_value = DBCon.Ora_Execute_table("select * From KW_Ref_Carta_Akaun where Id='" + lnk2.Text + "'");
            LinkButton lnk_roe = (LinkButton)e.Row.FindControl("lnkView");
            if (get_value.Rows[0]["jenis_akaun_type"].ToString() == "1")
            {
                lnk_roe.Attributes.Add("style", "pointer-events:none; font-weight:Bold;");
                lnk_roe.ForeColor = System.Drawing.Color.Blue;
            }
            else
            {
                lnk_roe.Attributes.Remove("style");
            }
        }
    }

    protected void GridView8_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            e.Row.Attributes["onclick"] = ClientScript.GetPostBackClientHyperlink(this.GridView1, "Select$" + e.Row.RowIndex);
        }
    }
    protected void GridView8_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "LinkButtonClicked")
        {
            string strgroupids = string.Empty, ss1 = string.Empty;
            int id, v1, s1, s2, s3, s4;
            if (Int32.Parse(e.CommandArgument.ToString()) > 20)
            {
                strgroupids = e.CommandArgument.ToString().Remove(e.CommandArgument.ToString().Length - 1);

                string myString = e.CommandArgument.ToString().Substring(e.CommandArgument.ToString().Length - 1, 1);
                if (Int32.Parse(myString) > 0)
                {
                    s1 = (((Int32.Parse(strgroupids) / 2)) * 20);

                    //v1 = (Int32.Parse(s1.PadRight(2, '0')) + 30);
                    id = ((Int32.Parse(e.CommandArgument.ToString()) - 1) - s1);
                }
                else
                {
                    s1 = (((Int32.Parse(strgroupids) / 2) + 1) * 20);
                    //v1 = (Int32.Parse(strgroupids.PadRight(2, '0')) + 20);
                    id = ((s1 - Int32.Parse(e.CommandArgument.ToString())) - 1);
                }

            }
            else
            {
                id = (Int32.Parse(e.CommandArgument.ToString()) - 1);
            }


            if (ViewState["PreviousRowIndex"] != null)
            {
                var previousRowIndex = (int)ViewState["PreviousRowIndex"];
                GridViewRow PreviousRow = GridView1.Rows[previousRowIndex];
                PreviousRow.BackColor = System.Drawing.Color.White;
            }
            if (id != null)
            {
                int currentRowIndex = id;
                GridViewRow row = GridView1.Rows[currentRowIndex];
                row.BackColor = System.Drawing.Color.LightBlue;
                ViewState["PreviousRowIndex"] = currentRowIndex;
            }

        }
    }
    protected void BindGrid()
    {
        //SqlCommand cmd2 = new SqlCommand("select ISNULL(ho.org_name,'') as org_name,ISNULL(dd.dis_dispose_type_cd,'') as dis_dispose_type_cd,rk.ast_kategori_desc,rja.ast_jeniaset_desc,aca.cas_asset_desc,a.sas_asset_id,a.sas_curr_price_amt, a.sas_asset_cat_cd,a.sas_asset_sub_cat_cd,a.sas_asset_type_cd,a.sas_asset_cd,a.sas_org_id, case a.sas_asset_cat_cd when '01' then (select FORMAT(com_reg_dt,'dd/MM/yyyy', 'en-us') as reg_dt from ast_component where com_asset_cat_cd=a.sas_asset_cat_cd and com_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and com_asset_type_cd=a.sas_asset_type_cd and com_asset_cd=a.sas_asset_cd) when '02' then (select FORMAT(car_reg_dt,'dd/MM/yyyy', 'en-us') as reg_dt from ast_car where car_asset_cat_cd=a.sas_asset_cat_cd and car_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and car_asset_type_cd=a.sas_asset_type_cd and car_asset_cd=a.sas_asset_cd and sas_staff_no='" + Session["New"].ToString() + "') when '03' then (select FORMAT(inv_reg_dt,'dd/MM/yyyy', 'en-us') as reg_dt from ast_inventory where inv_asset_cat_cd=a.sas_asset_cat_cd and inv_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and inv_asset_type_cd=a.sas_asset_type_cd and inv_asset_cd=a.sas_asset_cd and sas_staff_no='" + Session["New"].ToString() + "') end as a1, case a.sas_asset_cat_cd when '01' then (select DATEDIFF(day,com_reg_dt,GETDATE()) as u_dt from ast_component where com_asset_cat_cd=a.sas_asset_cat_cd and com_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and com_asset_type_cd=a.sas_asset_type_cd and com_asset_cd=a.sas_asset_cd and sas_staff_no='" + Session["New"].ToString() + "') when '02' then (select DATEDIFF(day,car_reg_dt,GETDATE()) as u_dt from ast_car where car_asset_cat_cd=a.sas_asset_cat_cd and car_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and car_asset_type_cd=a.sas_asset_type_cd and car_asset_cd=a.sas_asset_cd and sas_staff_no='" + Session["New"].ToString() + "') when '03' then (select  DATEDIFF(day,inv_reg_dt,GETDATE()) as u_dt from ast_inventory where inv_asset_cat_cd=a.sas_asset_cat_cd and inv_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and inv_asset_type_cd=a.sas_asset_type_cd and inv_asset_cd=a.sas_asset_cd and sas_staff_no='" + Session["New"].ToString() + "') end as a2, case a.sas_asset_cat_cd when '01' then (select com_price_amt from ast_component where com_asset_cat_cd=a.sas_asset_cat_cd and com_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and com_asset_type_cd=a.sas_asset_type_cd and com_asset_cd=a.sas_asset_cd and sas_staff_no='" + Session["New"].ToString() + "') when '02' then (select car_price_amt from ast_car where car_asset_cat_cd=a.sas_asset_cat_cd and car_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and car_asset_type_cd=a.sas_asset_type_cd and car_asset_cd=a.sas_asset_cd and sas_staff_no='" + Session["New"].ToString() + "') when '03' then (select inv_price_amt from ast_inventory where inv_asset_cat_cd=a.sas_asset_cat_cd and inv_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and inv_asset_type_cd=a.sas_asset_type_cd and inv_asset_cd=a.sas_asset_cd and sas_staff_no='" + Session["New"].ToString() + "') end as a3 from (select * from ast_staff_asset  where sas_cond_sts_cd = '03' and ISNULL(sas_dispose_cfm_ind,'' ) !='Y' and sas_staff_no='" + Session["New"].ToString() + "') as a left join Ref_ast_kategori as rk on rk.ast_kategori_code=a.sas_asset_cat_cd left join Ref_ast_jenis_aset as rja on rja.ast_jeniaset_Code=a.sas_asset_type_cd left join ast_cmn_asset as aca on aca.cas_asset_cd=a.sas_asset_cd and aca.cas_asset_cat_cd=a.sas_asset_cat_cd and aca.cas_asset_sub_cat_cd=a.sas_asset_sub_cat_cd and aca.cas_asset_type_cd=a.sas_asset_type_cd left join hr_organization as ho on ho.org_gen_id=a.sas_org_id left join ast_dispose as dd on dd.dis_asset_id=a.sas_asset_id", con);
        //SqlCommand cmd2 = new SqlCommand("select *,case when jenis_akaun_type='1' then kat_akaun else kod_akaun end as kod_akaun1 from KW_Ref_Carta_Akaun order by kat_akaun", con);
        SqlCommand cmd2 = new SqlCommand("select m1.Id,case when m1.jenis_akaun_type='1' then m1.kat_akaun else m1.kod_akaun end as kod_akaun1,m1.jenis_akaun_type,m1.kat_akaun,m1.nama_akaun,m1.kod_akaun,m1.jenis_akaun,m1.under_parent,case when s1.opening_amt > 0 then opening_amt else '0.00' end as KW_Debit_amt,case when s1.opening_amt < 0 then opening_amt else '0.00' end as KW_kredit_amt from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and s1.kat_akaun=m1.kat_akaun and s1.opening_year='" + DateTime.Now.Year + "' and s1.set_sts='1' order by m1.kat_akaun", con);
        //SqlCommand cmd2 = new SqlCommand("BEGIN  with  ITERATE_NODES_RECURSIVE AS (select a1.kat_akaun,a1.kod_akaun,a1.nama_akaun,a1.Id,a1.under_parent, case when a1.under_parent = '0' then a1.nama_akaun else a2.nama_akaun end as jenis_name, 0 as LEVEL_DEPTH,a1.KW_Debit_amt,a1.KW_kredit_amt,a1.Kw_open_amt,a1.under_jenis,a1.jenis_akaun_type from dbo.KW_Ref_Carta_Akaun a1 left join dbo.KW_Ref_Carta_Akaun as a2 on a2.kod_akaun=a1.jenis_akaun where (a1.Id IN (select Id from dbo.KW_Ref_Carta_Akaun where (under_parent = '0')))UNION ALL select super.kat_akaun,super.kod_akaun,super.nama_akaun,super.Id,super.under_parent,case when super.under_parent = '0' then super.nama_akaun else sub.nama_akaun end as jenis_name, sub.LEVEL_DEPTH + 1  as LEVEL_DEPTH,super.KW_Debit_amt,super.KW_kredit_amt,super.Kw_open_amt,super.under_jenis,super.jenis_akaun_type from dbo.KW_Ref_Carta_Akaun as super INNER JOIN ITERATE_NODES_RECURSIVE as sub on sub.id=super.under_parent ) select m1.Id,m1.jenis_akaun_type,m1.kat_akaun,m1.nama_akaun,m1.kod_akaun,m1.under_parent,case when s1.opening_amt > 0 then opening_amt else '0.00' end as KW_Debit_amt,case when s1.opening_amt < 0 then opening_amt else '0.00' end as KW_kredit_amt,case when m1.jenis_akaun_type='1' then m1.kat_akaun else m1.kod_akaun end as kod_akaun1 from ITERATE_NODES_RECURSIVE m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and s1.kat_akaun=m1.kat_akaun and s1.set_sts='1' order by m1.kat_akaun,m1.Id,m1.LEVEL_DEPTH; END", con);
        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataSet ds2 = new DataSet();
        da2.Fill(ds2);
        gv_refdata.DataSource = ds2;
        gv_refdata.DataBind();

    }

    protected void clk_submit(object sender, EventArgs e)
    {
       

        string samt1 = string.Empty, samt2 = string.Empty;
        if (txt_kredit.Text != "")
        {
            samt1 = txt_kredit.Text;
        }
        else
        {
            samt1 = "0.00";
        }

        if (txt_debit.Text != "")
        {
            samt2 = txt_debit.Text;
        }
        else
        {
            samt2 = "0.00";
        }


        if (samt1 != "0.00" || samt2 != "0.00")
        {
            string tot_amt = string.Empty, tot_amt1 = string.Empty;
            DataTable sel_val = new DataTable();
            sel_val = DBCon.Ora_Execute_table("select * From KW_Ref_Carta_Akaun where Id='" + get_id.Text + "'");
            if (sel_val.Rows.Count != 0)
            {
                //DataTable sel_val3 = new DataTable();
                //sel_val3 = DBCon.Ora_Execute_table("select Kw_open_amt From KW_Ref_Carta_Akaun where Id='" + get_id.Text + "'");

                //tot_amt1 = (double.Parse(sel_val3.Rows[0]["Kw_open_amt"].ToString()).ToString() + double.Parse(txt_debit.Text).ToString());


                decimal at1 = Convert.ToDecimal(samt1);
                decimal at2 = Convert.ToDecimal(samt2);
                decimal tot_amt2 = at2 - at1;

                string Inssql = "UPDATE KW_Ref_Carta_Akaun set Kw_open_amt='" + tot_amt2.ToString("###,###.00") + "',KW_Debit_amt='" + samt2 + "',KW_kredit_amt='" + samt1 + "',upd_id='" + Session["New"].ToString() + "',upd_dt='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where Id = '" + get_id.Text + "'";
                Status = DBCon.Ora_Execute_CommamdText(Inssql);
                if (Status == "SUCCESS")
                {
                    DataTable sel_val3 = new DataTable();
                    sel_val3 = DBCon.Ora_Execute_table("select * From KW_Opening_Balance where kod_akaun='" + sel_val.Rows[0]["kod_akaun"].ToString() + "' and start_dt='" + str_sdt1 + "' and end_dt='" + end_edt1 + "' and set_sts='1'");
                    if (sel_val3.Rows.Count == 0)
                    {
                        string Inssql1 = "Insert into KW_Opening_Balance (kod_akaun,opeing_date,opening_year,Status,crt_id,cr_dt,opening_amt,ending_amt,kat_akaun,set_sts,start_dt,end_dt) values('" + sel_val.Rows[0]["kod_akaun"].ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','" + DateTime.Now.ToString("yyyy") + "','A','" + Session["New"].ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','" + tot_amt2.ToString() + "','" + tot_amt2.ToString() + "','" + sel_val.Rows[0]["kat_akaun"].ToString() + "','1','" + str_sdt1 + "','" + end_edt1 + "')";
                        Status = DBCon.Ora_Execute_CommamdText(Inssql1);
                    }
                    else
                    {
                        string Inssql1 = "Update  KW_Opening_Balance set kat_akaun='" + sel_val.Rows[0]["kat_akaun"].ToString() + "',opening_amt='" + tot_amt2.ToString() + "',ending_amt='" + tot_amt2.ToString() + "',upd_id='" + Session["New"].ToString() + "',upd_dt='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where kod_akaun='" + sel_val.Rows[0]["kod_akaun"].ToString() + "' and opening_year='" + DateTime.Now.ToString("yyyy") + "' and set_sts='1'";
                        Status = DBCon.Ora_Execute_CommamdText(Inssql1);
                    }
                    empty_fld();
                    BindData();
                    BindGrid();
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Berjaya Dikemaskini.',{'type': 'confirmation','title': 'Success','auto_close': 2000});", true);
                }
                else
                {
                    ModalPopupExtender1.Show();
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Not Insert.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
                }
            }
        }
        else
        {
            ModalPopupExtender1.Show();
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukkan Jumlah yang sah.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
        }

    }

    void empty_fld()
    {
        get_id.Text = "";
        no_akaun.Text = "";
        txt_nama_akaun.Text = "";
        txt_debit.Text = "";
        txt_kredit.Text = "";
    }
    //protected void btn_set_baki(object sender, EventArgs e)
    //{
    //    BindGrid();
    //    string rcount = string.Empty;
    //    int count = 0;
    //    foreach (GridViewRow gvrow in gv_refdata.Rows)
    //    {
    //        count++;
    //        rcount = count.ToString();
    //    }
    //    if (rcount != "0")
    //    {
    //        foreach (GridViewRow row in gv_refdata.Rows)
    //        {
    //            int RowIndex = row.RowIndex;
    //            DataTable ddicno = new DataTable();
    //            string getid = ((Label)row.FindControl("lbl_id")).Text.ToString(); //this store the  value in varName1
    //            DataTable chk_row = new DataTable();
    //            chk_row = DBCon.Ora_Execute_table("select * From KW_Ref_Carta_Akaun where Id='" + getid + "'");
    //            DataTable chk_row_ob = new DataTable();
    //            chk_row_ob = DBCon.Ora_Execute_table("select * From KW_Opening_Balance where kod_akaun='" + chk_row.Rows[0]["kod_akaun"].ToString() + "' and opening_year='" + DateTime.Now.ToString("yyyy") + "' and set_sts='1'");
    //            if (chk_row_ob.Rows.Count != 0)
    //            {
    //                DataTable chk_payment = new DataTable();
    //                chk_payment = DBCon.Ora_Execute_table("select count(*) as cnt From KW_General_Ledger where kod_akaun='" + chk_row.Rows[0]["kod_akaun"].ToString() + "' and YEAR(cr_dt)='" + DateTime.Now.ToString("yyyy") + "'");
    //                if (chk_payment.Rows[0]["cnt"].ToString() == "0")
    //                {
    //                    string Inssql1 = "Update  KW_Opening_Balance set set_sts='0',upd_id='" + Session["New"].ToString() + "',upd_dt='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where kod_akaun='" + chk_row.Rows[0]["kod_akaun"].ToString() + "' and opening_year='" + DateTime.Now.ToString("yyyy") + "' and set_sts='1'";
    //                    Status = DBCon.Ora_Execute_CommamdText(Inssql1);
    //                    if (Status == "SUCCESS")
    //                    {
    //                        string Inssql2 = "UPDATE KW_Ref_Carta_Akaun set Kw_open_amt='0.00',KW_Debit_amt='0.00',KW_kredit_amt='0.00',upd_id='" + Session["New"].ToString() + "',upd_dt='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where Id = '" + getid + "'";
    //                        Status1 = DBCon.Ora_Execute_CommamdText(Inssql2);
    //                    }
    //                }
    //            }

    //        }
    //        if (Status1 == "SUCCESS")
    //        {
    //            BindData();
    //            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Berjaya Dikemaskini.',{'type': 'confirmation','title': 'Success','auto_close': 2000});", true);
    //        }
    //    }
    //    else
    //    {
    //        ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Pilih Rekod Yang Ingin Dihapuskan.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
    //    }
    //}
    protected void ctk_values(object sender, EventArgs e)
    {

        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        dt = DBCon.Ora_Execute_table("select *,case when jenis_akaun_type='1' then kat_akaun else kod_akaun end as kod_akaun1 from KW_Ref_Carta_Akaun");
        Rptviwer_baki.Reset();
        ds.Tables.Add(dt);

        List<DataRow> listResult = dt.AsEnumerable().ToList();
        listResult.Count();
        int countRow = 0;
        countRow = listResult.Count();

        Rptviwer_baki.LocalReport.DataSources.Clear();
        if (countRow != 0)
        {

            StringBuilder builder = new StringBuilder();
            string strFileName = string.Format("{0}.{1}", "BAKI_PEMBUKAAN_" + DateTime.Now.ToString("yyyyMMdd") + "", "csv");
            builder.Append("NAMA AKAUN ,KOD AKAUN ,DEBIT (RM),KREDIT (RM)" + Environment.NewLine);
            string oamt1 = string.Empty, oamt2 = string.Empty;
            foreach (GridViewRow row in gv_refdata.Rows)
            {
                string kodakaun = ((System.Web.UI.WebControls.Label)row.FindControl("lbl1")).Text.ToString();
                string akaunname = ((System.Web.UI.WebControls.Label)row.FindControl("lbl2")).Text.ToString();
                string Kamt = ((System.Web.UI.WebControls.Label)row.FindControl("lbl3")).Text.ToString();
                string Damt = ((System.Web.UI.WebControls.Label)row.FindControl("lbl5")).Text.ToString();
                string type = ((System.Web.UI.WebControls.Label)row.FindControl("lbl4")).Text.ToString();
                if (type == "1")
                {
                    oamt1 = "";
                    oamt2 = "";
                }
                else
                {
                    oamt1 = Kamt;
                    oamt2 = Damt;
                }

                builder.Append(akaunname.ToUpper().Replace(",", "") + "," + kodakaun + "," + oamt2 + "," + oamt1 + Environment.NewLine);
            }
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.AddHeader("Content-Disposition", "attachment;filename=" + strFileName);
            Response.Write(builder.ToString());
            Response.End();

        }
        else if (countRow == 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod tidak dijumpai. Sila Pastikan Semua Maklumat Dimasukkan Dengan Betul.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
        }
    }

    protected void lnkView_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btnButton = sender as LinkButton;
            GridViewRow gvRow = (GridViewRow)btnButton.NamingContainer;
            System.Web.UI.WebControls.Label og_genid = (System.Web.UI.WebControls.Label)gvRow.FindControl("og_genid");
            string ogid = og_genid.Text;
            DataTable get_value = new DataTable();
            //get_value = DBCon.Ora_Execute_table("select * From KW_Ref_Carta_Akaun where Id='" + ogid + "'");
            get_value = DBCon.Ora_Execute_table("select m1.jenis_akaun_type,m1.kat_akaun,m1.nama_akaun,m1.kod_akaun,m1.jenis_akaun,m1.under_parent,case when s1.opening_amt > 0 then opening_amt else '0.00' end as KW_Debit_amt,case when s1.opening_amt < 0 then opening_amt else '0.00' end as KW_kredit_amt from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and s1.kat_akaun=m1.kat_akaun and s1.set_sts='1' where m1.Id='" + ogid + "'");
            if (get_value.Rows.Count != 0)
            {
                
                DataTable chk_table = new DataTable();
                chk_table = DBCon.Ora_Execute_table("select * From KW_Opening_Balance where kod_akaun='" + get_value.Rows[0]["kod_akaun"].ToString() + "' and start_dt='" + str_sdt1 + "' and end_dt='" + end_edt1 + "' and set_sts='1'");
                DataTable chk_gl = new DataTable();
                chk_gl = DBCon.Ora_Execute_table("select * From KW_General_Ledger where kod_akaun='" + get_value.Rows[0]["kod_akaun"].ToString() + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '"+ str_sdt1 + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + end_edt1 + "'), +1)");
                if (chk_gl.Rows.Count == 0)
                {
                    DataTable ddokdicno = new DataTable();
                    ddokdicno = DBCon.Ora_Execute_table("select * from KW_Ref_Carta_Akaun where jenis_akaun='" + get_value.Rows[0]["kod_akaun"].ToString() + "'");

                    if (get_value.Rows[0]["jenis_akaun_type"].ToString() != "1")
                    {
                        ModalPopupExtender1.Show();
                        txt_kredit.Attributes.Remove("Readonly");
                        txt_debit.Attributes.Remove("Readonly");
                        txt_debit.Text = double.Parse(get_value.Rows[0]["KW_Debit_amt"].ToString()).ToString("C").Replace("$", "").Replace("RM", "").Replace(",", "").Replace("(", "").Replace(")", "");
                        txt_kredit.Text = double.Parse(get_value.Rows[0]["KW_kredit_amt"].ToString()).ToString("C").Replace("$", "").Replace("RM", "").Replace(",", "").Replace("(", "").Replace(")", "").Replace("-", "");

                        //Button4.Attributes.Remove("style");
                        //Button1.Attributes.Remove("style");
                        get_id.Text = ogid;
                        no_akaun.Text = get_value.Rows[0]["kod_akaun"].ToString();
                        txt_nama_akaun.Text = get_value.Rows[0]["nama_akaun"].ToString();
                        txt_debit.Focus();
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Baki pembukaan yang telah Didaftarkan untuk tahun Semasa.');", true);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void txtSearch_TextChanged(object sender, EventArgs e)
    {

        SearchText();
    }

    protected void btn_search_Click(object sender, EventArgs e)
    {
        BindData();
    }

    public string Highlight(string InputTxt)
    {
        string Search_Str = txtSearch.Text.ToString();
        // Setup the regular expression and add the Or operator.
        Regex RegExp = new Regex(Search_Str.Replace(" ", "|").Trim(),
        RegexOptions.IgnoreCase);

        // Highlight keywords by calling the 
        //delegate each time a keyword is found.
        return RegExp.Replace(InputTxt,
        new MatchEvaluator(ReplaceKeyWords));

        // Set the RegExp to null.
        RegExp = null;

    }

    public string ReplaceKeyWords(Match m)
    {

        return "<span class=highlight>" + m.Value + "</span>";

    }
    private void SearchText()
    {
        BindData();

    }
}