﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Threading;

public partial class kw_lep_pl : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();
    private static int PageSize = 20;
    string qry1 = string.Empty, qry2 = string.Empty;
    string level;
    string Status = string.Empty;
    string userid;
    string CommandArgument1 = string.Empty, CommandArgument2 = string.Empty, CommandArgument3 = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        app_language();
        Button4.OnClientClick = @"if(this.value == 'Please wait...')
           return false;
           this.value = 'Please wait...';this.disabled=true";
        string script = " $(function () {$('.select2').select2()});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        //ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        //scriptManager.RegisterPostBackControl(this.Button4);
        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {
                userid = Session["New"].ToString();
                BindData();
                project();
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
    }
    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('829','705','1724','64','65','169','830','121','15')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[7][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[6][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[7][0].ToString().ToLower());
            ps_lbl4.Text = txtinfo.ToTitleCase(gt_lng.Rows[8][0].ToString().ToLower());         
            ps_lbl5.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
            ps_lbl6.Text = txtinfo.ToTitleCase(gt_lng.Rows[2][0].ToString().ToLower());
            ps_lbl7.Text = txtinfo.ToTitleCase(gt_lng.Rows[3][0].ToString().ToLower());
            ps_lbl8.Text = txtinfo.ToTitleCase(gt_lng.Rows[5][0].ToString().ToLower());
            Button4.Text = txtinfo.ToTitleCase(gt_lng.Rows[4][0].ToString().ToLower());
            Button1.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());


        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }
    void project()
    {
        DataSet Ds = new DataSet();
        try
        {
            string com = "select Ref_Projek_code,Ref_Projek_name from  KW_Ref_Projek";
            SqlDataAdapter adpt = new SqlDataAdapter(com, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            ddpro.DataSource = dt;
            ddpro.DataTextField = "Ref_Projek_name";
            ddpro.DataValueField = "Ref_Projek_code";
            ddpro.DataBind();
            ddpro.Items.Insert(0, new ListItem("--- PILIH ---", ""));

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    //void BindDropdown()
    //{
    //    DateTimeFormatInfo info = DateTimeFormatInfo.GetInstance(null);

    //    int year = DateTime.Now.Year - 5;

    //    for (int Y = year; Y <= DateTime.Now.Year; Y++)

    //    {

    //        Tahun_kew.Items.Add(new ListItem(Y.ToString(), Y.ToString()));

    //    }

    //    Tahun_kew.SelectedValue = DateTime.Now.Year.ToString();

    //}

    protected void BindData()
    {

    }

    protected void clk_submit(object sender, EventArgs e)
    {
        if (Tk_mula.Text != "" && Tk_akhir.Text != "")
        {
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            string val1 = string.Empty, val2 = string.Empty, val3 = string.Empty, val4 = string.Empty, val5 = string.Empty, val6 = string.Empty;

            string fmdate = string.Empty, fmonth = string.Empty, fyear = string.Empty, stdate = string.Empty, tmdate = string.Empty, tmdate1 = string.Empty, pre_day = string.Empty, pre_year = string.Empty, curr_yr = string.Empty, prev_yr = string.Empty;
            if (Tk_mula.Text != "")
            {
                string fdate = Tk_mula.Text;
                DateTime fd = DateTime.ParseExact(fdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                fmdate = fd.ToString("yyyy-MM-dd");
                fmonth = fd.ToString("MM");
                fyear = fd.ToString("yyyy");
                pre_day = fd.AddDays(-1).ToString("yyyy-MM-dd");
                pre_year = fd.AddYears(-1).ToString("yyyy-MM-dd");
                curr_yr = fd.ToString("yyyy");
            }
            if (Tk_akhir.Text != "")
            {
                string tdate = Tk_akhir.Text;
                DateTime td = DateTime.ParseExact(tdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                tmdate = td.ToString("yyyy-MM-dd");
                tmdate1 = td.ToString("dd MMMM yyyy");
                prev_yr = td.ToString("yyyy");
            }
            int min_val = 1;
            
          
            if (Tk_mula.Text != "" && Tk_akhir.Text != "" && ddpro.SelectedValue == "" && akaun_level.SelectedValue != "")
            {


                //val6 = "select case when r1.kat_cd='10' then '01' when r1.kat_cd='11' then '02' when r1.kat_cd='15' then '03' when r1.kat_cd='12' then '04' when r1.kat_cd='17' then '05' else '06' end as oby,r1.bal_type as baltype,case when r1.bal_type='01' then 'K' else 'D' end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun, case when a.kod_akaun ='12.03' then (case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(( (cast(replace(((ISNULL(a1.opening_amt, '0.00') + ISNULL(a2.debit, '0.00')) - ISNULL(a2.kredit, '0.00')), '-', '') as money) + ISNULL(b3.deb, '0.00')) - ISNULL(b3.kre, '0.00')),'-','') as money)   else cast(replace(((ISNULL(b1.opening_amt, '0.00') + ISNULL(b3.deb, '0.00')) - ISNULL(b3.kre, '0.00')), '-', '') as money) end)  when a.kod_akaun = '12.05' then(case when ISNULL(b1.opening_amt, '0.00') = '0.00' then cast(replace((  (cast(replace(((ISNULL(a1.opening_amt, '0.00') + ISNULL(a2.debit, '0.00')) - ISNULL(a2.kredit, '0.00')), '-', '') as money) + ISNULL(b4.deb, '0.00')) - ISNULL(b4.kre, '0.00')), '-', '') as money)   else cast(replace(((ISNULL(b1.opening_amt, '0.00') + ISNULL(b4.deb, '0.00')) - ISNULL(b4.kre, '0.00')), '-', '') as money) end)  else (case when ISNULL(b1.opening_amt, '0.00') = '0.00' then cast(replace((  (cast(replace(((ISNULL(a1.opening_amt, '0.00') + ISNULL(a2.debit, '0.00')) - ISNULL(a2.kredit, '0.00')), '-', '') as money) + ISNULL(b2.debit, '0.00')) - ISNULL(b2.kredit, '0.00')), '-', '') as money)   else cast(replace(((ISNULL(b1.opening_amt, '0.00') + ISNULL(b3.deb, '0.00')) - ISNULL(b3.kre, '0.00')), '-', '') as money) end) end as val1,cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+pre_year+"' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+pre_day+"'), +0) group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+fmdate+"' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b2 on b2.kod_akaun=a.kod_akaun left join (select kod,sum(debit) as deb,sum(kredit) as kre  from (select '12.03' as kod,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as a where kod_akaun like '%12.03%' group by kod) as b3 on b3.kod = a.kod_akaun left join (select kod, sum(debit) as deb, sum(kredit) as kre  from(select '12.05' as kod, kod_akaun, sum(KW_Debit_amt) as debit, sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as a where kod_akaun like '%12.05%' group by kod) as b4 on b4.kod = a.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun order by oby asc";
                val6 = "select case when r1.kat_cd='10' then '01' when r1.kat_cd='11' then '02' when r1.kat_cd='15' then '03' when r1.kat_cd='12' then '04' when r1.kat_cd='17' then '05' else '06' end as oby,r1.bal_type as baltype,case when r1.bal_type='01' then 'K' else 'D' end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money)) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + pre_year + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + pre_day + "'), +0) group by kod_akaun,kat_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' and a2.kat_akaun=a.kat_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun group by kat_cd,bal_type,a.kat_akaun,kat_akuan,nama_akaun,a.kod_akaun order by oby asc";
                val5 = "select r1.bal_type as baltype,SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money)) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+pre_year+"' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+pre_day+"'), +0) group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+fmdate+ "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' group by r1.bal_type";
            }
            else if (Tk_mula.Text != "" && Tk_akhir.Text != "" && ddpro.SelectedValue != "" && akaun_level.SelectedValue != "")
            {

                //val6 = "select case when r1.kat_cd='10' then '01' when r1.kat_cd='11' then '02' when r1.kat_cd='15' then '03' when r1.kat_cd='12' then '04' when r1.kat_cd='17' then '05' else '06' end as oby,r1.bal_type as baltype,case when r1.bal_type='01' then 'K' else 'D' end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun, case when a.kod_akaun ='12.03' then (case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(( (cast(replace(((ISNULL(a1.opening_amt, '0.00') + ISNULL(a2.debit, '0.00')) - ISNULL(a2.kredit, '0.00')), '-', '') as money) + ISNULL(b3.deb, '0.00')) - ISNULL(b3.kre, '0.00')),'-','') as money)   else cast(replace(((ISNULL(b1.opening_amt, '0.00') + ISNULL(b3.deb, '0.00')) - ISNULL(b3.kre, '0.00')), '-', '') as money) end)  when a.kod_akaun = '12.05' then(case when ISNULL(b1.opening_amt, '0.00') = '0.00' then cast(replace((  (cast(replace(((ISNULL(a1.opening_amt, '0.00') + ISNULL(a2.debit, '0.00')) - ISNULL(a2.kredit, '0.00')), '-', '') as money) + ISNULL(b4.deb, '0.00')) - ISNULL(b4.kre, '0.00')), '-', '') as money)   else cast(replace(((ISNULL(b1.opening_amt, '0.00') + ISNULL(b4.deb, '0.00')) - ISNULL(b4.kre, '0.00')), '-', '') as money) end)  else (case when ISNULL(b1.opening_amt, '0.00') = '0.00' then cast(replace((  (cast(replace(((ISNULL(a1.opening_amt, '0.00') + ISNULL(a2.debit, '0.00')) - ISNULL(a2.kredit, '0.00')), '-', '') as money) + ISNULL(b2.debit, '0.00')) - ISNULL(b2.kredit, '0.00')), '-', '') as money)   else cast(replace(((ISNULL(b1.opening_amt, '0.00') + ISNULL(b3.deb, '0.00')) - ISNULL(b3.kre, '0.00')), '-', '') as money) end) end as val1,cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+pre_year+"' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+pre_day+"'), +0) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+fmdate+"' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as b2 on b2.kod_akaun=a.kod_akaun left join (select kod,sum(debit) as deb,sum(kredit) as kre  from (select '12.03' as kod,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as a where kod_akaun like '%12.03%' group by kod) as b3 on b3.kod = a.kod_akaun left join (select kod, sum(debit) as deb, sum(kredit) as kre  from(select '12.05' as kod, kod_akaun, sum(KW_Debit_amt) as debit, sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as a where kod_akaun like '%12.05%' group by kod) as b4 on b4.kod = a.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun order by oby asc";
                val6 = "select case when r1.kat_cd='10' then '01' when r1.kat_cd='11' then '02' when r1.kat_cd='15' then '03' when r1.kat_cd='12' then '04' when r1.kat_cd='17' then '05' else '06' end as oby,r1.bal_type as baltype,case when r1.bal_type='01' then 'K' else 'D' end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money)) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + pre_year + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + pre_day + "'), +0) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' and a2.kat_akaun=a.kat_akaun  Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun group by kat_cd,bal_type,kat_akaun,a.kat_akuan,nama_akaun,a.kod_akaun order by oby asc";
                val5 = "select r1.bal_type as baltype,SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money)) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+pre_year+"' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+pre_day+"'), +0) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+fmdate+ "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun  inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' group by r1.bal_type";
            }

            else if (Tk_mula.Text != "" && Tk_akhir.Text != "" && ddpro.SelectedValue == "" && akaun_level.SelectedValue == "")
            {

                //val6 = "select case when r1.kat_cd='10' then '01' when r1.kat_cd='11' then '02' when r1.kat_cd='15' then '03' when r1.kat_cd='12' then '04' when r1.kat_cd='17' then '05' else '06' end as oby,r1.bal_type as baltype,case when r1.bal_type='01' then 'K' else 'D' end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun, case when a.kod_akaun ='12.03' then (case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(( (cast(replace(((ISNULL(a1.opening_amt, '0.00') + ISNULL(a2.debit, '0.00')) - ISNULL(a2.kredit, '0.00')), '-', '') as money) + ISNULL(b3.deb, '0.00')) - ISNULL(b3.kre, '0.00')),'-','') as money)   else cast(replace(((ISNULL(b1.opening_amt, '0.00') + ISNULL(b3.deb, '0.00')) - ISNULL(b3.kre, '0.00')), '-', '') as money) end)  when a.kod_akaun = '12.05' then(case when ISNULL(b1.opening_amt, '0.00') = '0.00' then cast(replace((  (cast(replace(((ISNULL(a1.opening_amt, '0.00') + ISNULL(a2.debit, '0.00')) - ISNULL(a2.kredit, '0.00')), '-', '') as money) + ISNULL(b4.deb, '0.00')) - ISNULL(b4.kre, '0.00')), '-', '') as money)   else cast(replace(((ISNULL(b1.opening_amt, '0.00') + ISNULL(b4.deb, '0.00')) - ISNULL(b4.kre, '0.00')), '-', '') as money) end)  else (case when ISNULL(b1.opening_amt, '0.00') = '0.00' then cast(replace((  (cast(replace(((ISNULL(a1.opening_amt, '0.00') + ISNULL(a2.debit, '0.00')) - ISNULL(a2.kredit, '0.00')), '-', '') as money) + ISNULL(b2.debit, '0.00')) - ISNU LL(b2.kredit, '0.00')), '-', '') as money)   else cast(replace(((ISNULL(b1.opening_amt, '0.00') + ISNULL(b3.deb, '0.00')) - ISNULL(b3.kre, '0.00')), '-', '') as money) end) end as val1,cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + pre_year+"' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+pre_day+"'), +0) group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+fmdate+"' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b2 on b2.kod_akaun=a.kod_akaun left join (select kod,sum(debit) as deb,sum(kredit) as kre  from (select '12.03' as kod,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as a where kod_akaun like '%12.03%' group by kod) as b3 on b3.kod = a.kod_akaun left join (select kod, sum(debit) as deb, sum(kredit) as kre  from(select '12.05' as kod, kod_akaun, sum(KW_Debit_amt) as debit, sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as a where kod_akaun like '%12.05%' group by kod) as b4 on b4.kod = a.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun order by oby asc";
                val6 = "select case when r1.kat_cd='10' then '01' when r1.kat_cd='11' then '02' when r1.kat_cd='15' then '03' when r1.kat_cd='12' then '04' when r1.kat_cd='17' then '05' else '06' end as oby,r1.bal_type as baltype,case when r1.bal_type='01' then 'K' else 'D' end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money)) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + pre_year + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + pre_day + "'), +0) group by kod_akaun,kat_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' and a2.kat_akaun=a.kat_akaun  Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%'  and b2.kat_akaun=a.kat_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun group by kat_cd,bal_type,a.kat_akaun,kat_akuan,nama_akaun,a.kod_akaun order by oby asc";
                val5 = "select r1.bal_type as baltype,SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money)) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+pre_year+"' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+pre_day+"'), +0) group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '"+fmdate+ "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where  GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun   inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' group by r1.bal_type";
            }

            dt = DBCon.Ora_Execute_table(val6);
            //dt1 = DBCon.Ora_Execute_table(val5);
            Rptviwerlejar.Reset();
            ds.Tables.Add(dt);
            //ds1.Tables.Add(dt1);

            List<DataRow> listResult = dt.AsEnumerable().ToList();
            listResult.Count();
            int countRow = 0;
            countRow = listResult.Count();



            Rptviwerlejar.LocalReport.DataSources.Clear();
            if (countRow != 0)
            {
                DataTable sel_gst1 = new DataTable();
                sel_gst1 = DBCon.Ora_Execute_table(val5);
                string get_edt = string.Empty;
                //DataTable sel_gst2 = new DataTable();
                //sel_gst2 = DBCon.Ora_Execute_table("select top(1) Format(tarikh_akhir,'dd MMMM yyyy') as end_dt from kw_profile_syarikat where cur_sts='1' order by tarikh_akhir desc");
                //if (sel_gst2.Rows.Count != 0)
                //{
                //    get_edt = sel_gst2.Rows[0]["end_dt"].ToString();
                  
                //}
               

                if (sel_gst1.Rows.Count != 0)
                {
                    val2 = double.Parse(sel_gst1.Rows[0]["val1"].ToString()).ToString("C").Replace("$","").Replace("RM", "");
                    val3 = double.Parse(sel_gst1.Rows[0]["val2"].ToString()).ToString("C").Replace("$", "").Replace("RM", "");
                }
                else
                {
                    val2 = "0.00";
                    val3 = "0.00";
                }

                Rptviwerlejar.LocalReport.ReportPath = "Kewengan/KW_pandl.rdlc";
                ReportDataSource rds = new ReportDataSource("kwpl", dt);
                //ReportDataSource rds1 = new ReportDataSource("kwpl1", dt1);
                ReportParameter[] rptParams = new ReportParameter[]{
                     new ReportParameter("d1", Convert.ToString(( Int32.Parse(prev_yr) - 1))),
                     new ReportParameter("d2", prev_yr),
                     new ReportParameter("d3", val2),
                     new ReportParameter("d4", val3),
                     new ReportParameter("d5", tmdate1),
                     new ReportParameter("d6", akaun_level.SelectedItem.Text),
                          };

                Rptviwerlejar.LocalReport.SetParameters(rptParams);
                Rptviwerlejar.LocalReport.DataSources.Add(rds);
                //Rptviwerlejar.LocalReport.DataSources.Add(rds1);
                Rptviwerlejar.LocalReport.Refresh();
                System.Threading.Thread.Sleep(1);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod tidak dijumpai. Sila Pastikan Semua Maklumat Dimasukkan Dengan Betul.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukan Input Carian.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
        }
    }



    protected void btn_reset(object sender, EventArgs e)
    {
        Response.Redirect("../kewengan/kw_lep_pl.aspx");
    }


}