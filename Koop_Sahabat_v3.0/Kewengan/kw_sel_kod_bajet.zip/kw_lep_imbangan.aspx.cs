﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Threading;

public partial class kw_lep_imbangan : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();
    private static int PageSize = 20;
    string qry1 = string.Empty, qry2 = string.Empty;
    string level;
    string Status = string.Empty;
    string userid;
    string CommandArgument1 = string.Empty, CommandArgument2 = string.Empty, CommandArgument3 = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        app_language();
        Button4.OnClientClick = @"if(this.value == 'Please wait...')
           return false;
           this.value = 'Please wait...';this.disabled=true";
        string script = " $(function () {$('.select2').select2()});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        //ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        //scriptManager.RegisterPostBackControl(this.Button4);
        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {
                userid = Session["New"].ToString();
                BindData();
                project();
                //BindDropdown();
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
    }
    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('826','705','1724','64','65','827','169','1840','121','15')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[5][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[7][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[5][0].ToString().ToLower());
            ps_lbl4.Text = txtinfo.ToTitleCase(gt_lng.Rows[8][0].ToString().ToLower());
            ps_lbl5.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());      
            ps_lbl6.Text = txtinfo.ToTitleCase(gt_lng.Rows[2][0].ToString().ToLower());
            //ps_lbl7.Text = txtinfo.ToTitleCase(gt_lng.Rows[6][0].ToString().ToLower());
            ps_lbl8.Text = txtinfo.ToTitleCase(gt_lng.Rows[3][0].ToString().ToLower());
            ps_lbl9.Text = txtinfo.ToTitleCase(gt_lng.Rows[9][0].ToString().ToLower());
            Button4.Text = txtinfo.ToTitleCase(gt_lng.Rows[4][0].ToString().ToLower());
            Button1.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());

        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }
    void project()
    {
        DataSet Ds = new DataSet();
        try
        {
            string com = "select Ref_Projek_code,Ref_Projek_name from  KW_Ref_Projek";
            SqlDataAdapter adpt = new SqlDataAdapter(com, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            ddpro.DataSource = dt;
            ddpro.DataTextField = "Ref_Projek_name";
            ddpro.DataValueField = "Ref_Projek_code";
            ddpro.DataBind();
            ddpro.Items.Insert(0, new ListItem("--- PILIH ---", ""));

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    //void BindDropdown()
    //{
    //    DateTimeFormatInfo info = DateTimeFormatInfo.GetInstance(null);

    //    int year = DateTime.Now.Year - 5;

    //    for (int Y = year; Y <= DateTime.Now.Year; Y++)

    //    {

    //        Tahun_kew.Items.Add(new ListItem(Y.ToString(), Y.ToString()));

    //    }

    //    Tahun_kew.SelectedValue = DateTime.Now.Year.ToString();

    //}

    protected void BindData()
    {

    }

    protected void clk_submit(object sender, EventArgs e)
    {
        if (Tk_mula.Text != "" && Tk_akhir.Text != "")
        {
            string fmdate = string.Empty, tmdate = string.Empty, val6 = string.Empty, val7 = string.Empty;
            if (Tk_mula.Text != "")
            {
                string fdate = Tk_mula.Text;
                DateTime fd = DateTime.ParseExact(fdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                fmdate = fd.ToString("yyyy-MM-dd");
            }
            if (Tk_akhir.Text != "")
            {
                string tdate = Tk_akhir.Text;
                DateTime td = DateTime.ParseExact(tdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                tmdate = td.ToString("yyyy-MM-dd");
            }

            if (Tk_mula.Text != "" && Tk_akhir.Text != "" && ddpro.SelectedValue == "")
            {
                if (zero_bal.Checked == true)
                {
                    val6 = "select * from (select a.kat_name,a.kat_akaun,a.nama_akaun,a.kod_akaun, case when a.bal_type='D' then ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end KW_Debit_amt,cast(replace(case when a.bal_type='K' then  ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end , '-','') as money) KW_kredit_amt,ISNULL(o.opening_amt,'0.00') Kw_open_amt,'' as net,'' as ending_bal from (select s1.bal_type,s1.kat_akuan as kat_name,m1.kat_akaun,m1.kod_akaun,m1.nama_akaun from KW_Ref_Carta_Akaun m1 left join KW_Kategori_akaun s1 on s1.kat_cd=m1.kat_akaun where m1.jenis_akaun_type != '1') as a left join (select * from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as o on o.kod_akaun = a.kod_akaun left join (select kod_akaun, ISNULL(sum(KW_kredit_amt),'0.00') Kredit, sum(KW_Debit_amt) Debit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun ) as b on b.kod_akaun=a.kod_akaun ) as m1 ";
                }
                else
                {
                    val6 = "select * from (select a.kat_name,a.kat_akaun,a.nama_akaun,a.kod_akaun, case when a.bal_type='D' then ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end KW_Debit_amt,cast(replace(case when a.bal_type='K' then  ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end , '-','') as money) KW_kredit_amt,ISNULL(o.opening_amt,'0.00') Kw_open_amt,'' as net,'' as ending_bal from (select s1.bal_type,s1.kat_akuan as kat_name,m1.kat_akaun,m1.kod_akaun,m1.nama_akaun from KW_Ref_Carta_Akaun m1 left join KW_Kategori_akaun s1 on s1.kat_cd=m1.kat_akaun where m1.jenis_akaun_type != '1') as a left join (select * from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as o on o.kod_akaun = a.kod_akaun left join (select kod_akaun, ISNULL(sum(KW_kredit_amt),'0.00') Kredit, sum(KW_Debit_amt) Debit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun ) as b on b.kod_akaun=a.kod_akaun ) as m1 where ISNULL(m1.KW_Debit_amt,'0.00') != '0.00' or ISNULL(m1.KW_kredit_amt,'0.00') != '0.00'  or ISNULL(m1.Kw_open_amt,'0.00') != '0.00' ";
                }
            }
            else if (Tk_mula.Text != "" && Tk_akhir.Text != "" && ddpro.SelectedValue != "")
            {

                if (zero_bal.Checked == true)
                {
                    val6 = "select * from (select a.kat_name,a.kat_akaun,a.nama_akaun,a.kod_akaun, case when a.bal_type='D' then ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end KW_Debit_amt,replace(case when a.bal_type='K' then  ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end , '-','') KW_kredit_amt,ISNULL(o.opening_amt,'0.00') Kw_open_amt,'' as net,'' as ending_bal from (select s1.bal_type,s1.kat_akuan as kat_name,m1.kat_akaun,m1.kod_akaun,m1.nama_akaun from KW_Ref_Carta_Akaun m1 left join KW_Kategori_akaun s1 on s1.kat_cd=m1.kat_akaun where m1.jenis_akaun_type != '1') as a left join (select * from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as o on o.kod_akaun = a.kod_akaun left join (select kod_akaun, ISNULL(sum(KW_kredit_amt),'0.00') Kredit, sum(KW_Debit_amt) Debit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun ) as b on b.kod_akaun=a.kod_akaun ) as m1 ";
                }
                else
                {
                    val6 = "select * from (select a.kat_name,a.kat_akaun,a.nama_akaun,a.kod_akaun, case when a.bal_type='D' then ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end KW_Debit_amt,replace(case when a.bal_type='K' then  ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end , '-','') KW_kredit_amt,ISNULL(o.opening_amt,'0.00') Kw_open_amt,'' as net,'' as ending_bal from (select s1.bal_type,s1.kat_akuan as kat_name,m1.kat_akaun,m1.kod_akaun,m1.nama_akaun from KW_Ref_Carta_Akaun m1 left join KW_Kategori_akaun s1 on s1.kat_cd=m1.kat_akaun where m1.jenis_akaun_type != '1') as a left join (select * from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as o on o.kod_akaun = a.kod_akaun left join (select kod_akaun, ISNULL(sum(KW_kredit_amt),'0.00') Kredit, sum(KW_Debit_amt) Debit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun ) as b on b.kod_akaun=a.kod_akaun ) as m1 where ISNULL(m1.KW_Debit_amt,'0.00') != '0.00' or ISNULL(m1.KW_kredit_amt,'0.00') != '0.00'  or ISNULL(m1.Kw_open_amt,'0.00') != '0.00' ";
                }
            }
            //else if (Tk_mula.Text == "" && Tk_akhir.Text == "" && ddpro.SelectedValue != "")
            //{
            //    if (zero_bal.Checked == true)
            //    {
            //        val6 = "select s1.kat_akuan as kat_name,a.kat_akaun,a.nama_akaun,a.kod_akaun, case when s1.bal_type='D' then ISNULL(b.Debit,'0.00') else '0.00' end KW_Debit_amt,case when s1.bal_type='K' then ISNULL(b.Kredit,'0.00') else '0.00' end KW_kredit_amt,ISNULL(a.Kw_open_amt,'0.00') Kw_open_amt,'' as net,'' as ending_bal from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1') as a full outer join (select kod_akaun, sum(KW_kredit_amt) Kredit, sum(KW_Debit_amt) Debit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + Tahun_kew.SelectedValue + "') and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun ) as b on b.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun s1 on s1.kat_cd=a.kat_akaun order by a.kat_akaun";
            //    }
            //    else
            //    {
            //        val6 = "select s1.kat_akuan as kat_name,a.kat_akaun,a.nama_akaun,a.kod_akaun, case when s1.bal_type='D' then ISNULL(b.Debit,'0.00') else '0.00' end KW_Debit_amt,case when s1.bal_type='K' then ISNULL(b.Kredit,'0.00') else '0.00' end KW_kredit_amt,ISNULL(a.Kw_open_amt,'0.00') Kw_open_amt,'' as net,'' as ending_bal from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1') as a inner join (select kod_akaun, sum(KW_kredit_amt) Kredit, sum(KW_Debit_amt) Debit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + Tahun_kew.SelectedValue + "') and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun ) as b on b.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun s1 on s1.kat_cd=a.kat_akaun where ISNULL(a.Kw_open_amt,'0.00') != '0.00' order by a.kat_akaun";
            //    }
            //}
            else
            {
                if (zero_bal.Checked == true)
                {
                    val6 = "select * from (select a.kat_name,a.kat_akaun,a.nama_akaun,a.kod_akaun, case when a.bal_type='D' then ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end KW_Debit_amt,replace(case when a.bal_type='K' then  ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end , '-','') KW_kredit_amt,ISNULL(o.opening_amt,'0.00') Kw_open_amt,'' as net,'' as ending_bal from (select s1.bal_type,s1.kat_akuan as kat_name,m1.kat_akaun,m1.kod_akaun,m1.nama_akaun from KW_Ref_Carta_Akaun m1 left join KW_Kategori_akaun s1 on s1.kat_cd=m1.kat_akaun where m1.jenis_akaun_type != '1') as a left join (select * from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as o on o.kod_akaun = a.kod_akaun left join (select kod_akaun, ISNULL(sum(KW_kredit_amt),'0.00') Kredit, sum(KW_Debit_amt) Debit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun ) as b on b.kod_akaun=a.kod_akaun ) as m1 ";
                }
                else
                {
                    val6 = "select * from (select a.kat_name,a.kat_akaun,a.nama_akaun,a.kod_akaun, case when a.bal_type='D' then ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end KW_Debit_amt,replace(case when a.bal_type='K' then  ((ISNULL(o.opening_amt,'0.00') + ISNULL(b.Debit,'0.00')) - ISNULL(b.Kredit,'0.00')) else '0.00' end , '-','') KW_kredit_amt,ISNULL(o.opening_amt,'0.00') Kw_open_amt,'' as net,'' as ending_bal from (select s1.bal_type,s1.kat_akuan as kat_name,m1.kat_akaun,m1.kod_akaun,m1.nama_akaun from KW_Ref_Carta_Akaun m1 left join KW_Kategori_akaun s1 on s1.kat_cd=m1.kat_akaun where m1.jenis_akaun_type != '1') as a left join (select * from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as o on o.kod_akaun = a.kod_akaun left join (select kod_akaun, ISNULL(sum(KW_kredit_amt),'0.00') Kredit, sum(KW_Debit_amt) Debit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun ) as b on b.kod_akaun=a.kod_akaun ) as m1 where ISNULL(m1.KW_Debit_amt,'0.00') != '0.00' or ISNULL(m1.KW_kredit_amt,'0.00') != '0.00'  or ISNULL(m1.Kw_open_amt,'0.00') != '0.00' ";
                }
            }

            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            //dt = DBCon.Ora_Execute_table("select nama_akaun,kod_akaun,Kw_open_amt,KW_Debit_amt,KW_kredit_amt, case when KW_Debit_amt = '0.00' then KW_kredit_amt else  KW_Debit_amt end net,case when KW_Debit_amt != '0.00' then (Kw_open_amt + KW_Debit_amt) else  (Kw_open_amt - KW_kredit_amt) end ending_bal from KW_Ref_Carta_Akaun");
            dt = DBCon.Ora_Execute_table(val6);
            Rptviwerlejar.Reset();
            ds.Tables.Add(dt);
            if (dt.Rows.Count % 25 != 0)
            {
                if (dt.Rows.Count > 25)
                {
                    int addCount = 25 - dt.Rows.Count % 25;
                    for (int i = 0; i < addCount; i++)
                    {
                        DataRow dr = dt.NewRow();
                        dr[0] = "";
                        dt.Rows.Add(dr);
                    }
                }

            }

            List<DataRow> listResult = dt.AsEnumerable().ToList();
            listResult.Count();
            int countRow = 0;
            countRow = listResult.Count();
            Rptviwerlejar.LocalReport.DataSources.Clear();
            if (countRow != 0)
            {
                if (ddpro.SelectedValue != "")
                {
                    val7 = ddpro.SelectedItem.Text;
                }
                else
                {
                    val7 = "SEMUA";
                }

                Rptviwerlejar.LocalReport.ReportPath = "Kewengan/KW_Imbangan_duga.rdlc";
                ReportDataSource rds = new ReportDataSource("kwimbangan", dt);
                ReportParameter[] rptParams = new ReportParameter[]{
                     new ReportParameter("s1", Tk_mula.Text),
                     new ReportParameter("s2", Tk_akhir.Text),
                     new ReportParameter("s3", ""),
                     new ReportParameter("s4", val7)
                          };

                Rptviwerlejar.LocalReport.SetParameters(rptParams);
                Rptviwerlejar.LocalReport.DataSources.Add(rds);
                Rptviwerlejar.LocalReport.Refresh();
                System.Threading.Thread.Sleep(1);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod tidak dijumpai. Sila Pastikan Semua Maklumat Dimasukkan Dengan Betul.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukan Input Carian.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
        }
    }

    protected void btn_reset(object sender, EventArgs e)
    {
        Response.Redirect("../kewengan/kw_lep_imbangan.aspx");
    }


}