﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Threading;

public partial class kw_template_aliran : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();
    string level;
    string Status = string.Empty;
    string userid;
    string ref_id;
    string qry1 = string.Empty, qry2 = string.Empty;
    string tn1 = string.Empty, tc1 = string.Empty, tc2 = string.Empty, tc3 = string.Empty, tc4 = string.Empty, tc5 = string.Empty, tc6 = string.Empty, tc7 = string.Empty, tc8 = string.Empty, tc9 = string.Empty, tc10 = string.Empty, tc11 = string.Empty, tc12 = string.Empty;
    string h1 = string.Empty, h2 = string.Empty, h3 = string.Empty, h4 = string.Empty, h5 = string.Empty, h6 = string.Empty, h7 = string.Empty, sq1 = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        app_language();
        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {
                userid = Session["New"].ToString();
                BindData();
                sel_val();
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
    }
    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('1637','705')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
            
        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }
    void ref_table()
    {

        tn1 = "kw_template_aliran";
        tc1 = "tmp_kod_akaun";
        tc2 = "tmp_position";
        tc3 = "tmp_Status";
        tc4 = "Id";
        tc5 = "tmp_h1";
        tc6 = "tmp_h2";
        tc7 = "tmp_h3";
        tc8 = "tmp_h4";
        tc9 = "tmp_h5";
        tc10 = "sqno";
        tc11 = "tmp_h6";
        tc12 = "tmp_h7";

    }

    void sel_val()
    {
        ref_table();
      
        BindData();

    }

    //protected void srch_id_TextChanged(object sender, EventArgs e)
    //{
    //    BindData();

    //}

    //protected void btn_search_Click(object sender, EventArgs e)
    //{
    //    BindData();
    //}
    protected void BindData()
    {
        //if (srch_id.Text != "")
        //{
        //    qry1 = "select (kod_akaun +' | '+nama_akaun) as c1,ISNULL(s1.tmp_position,'') as c2,ISNULL(s1.tmp_Status,'') as c3,ISNULL(s1.Id,'') as c4,ISNULL(s1.tmp_h1,'') as c5,ISNULL(s1.tmp_h2,'') as c6,ISNULL(s1.tmp_h3,'') as c7,ISNULL(s1.tmp_h4,'') as c8,ISNULL(s1.tmp_h5,'') as c9,kod_akaun as c10,ISNULL(s1.sqno,'100') as c11 from KW_Ref_Carta_Akaun left join kw_template_aliran as s1 on s1.tmp_kod_akaun = kod_akaun where kod_akaun like '%" + srch_id.Text + "%' and jenis_akaun_type != '1' and AT_rep='1' order by cast(ISNULL(s1.sqno,'100') as int),cast(ISNULL(s1.tmp_position,'') as int) asc";
        //}
        //else
        //{
            qry1 = "select (kod_akaun +' | '+nama_akaun) as c1,ISNULL(s1.tmp_position,'') as c2,ISNULL(s1.tmp_Status,'') as c3,ISNULL(s1.Id,'') as c4,ISNULL(s1.tmp_h1,'') as c5,ISNULL(s1.tmp_h2,'') as c6,ISNULL(s1.tmp_h3,'') as c7,ISNULL(s1.tmp_h4,'') as c8,ISNULL(s1.tmp_h5,'') as c9,kod_akaun as c10,ISNULL(s1.sqno,'100') as c11,ISNULL(s1.tmp_h6,'') as c12,ISNULL(s1.tmp_h7,'') as c13 from KW_Ref_Carta_Akaun left join kw_template_aliran as s1 on s1.tmp_kod_akaun = kod_akaun where jenis_akaun_type != '1' and AT_rep='1' order by cast(ISNULL(s1.sqno,'100') as int),cast(ISNULL(s1.tmp_position,'') as int) asc";
        //}

        SqlCommand cmd2 = new SqlCommand("" + qry1 + "", con);
        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataSet ds2 = new DataSet();
        da2.Fill(ds2);

        if (ds2.Tables[0].Rows.Count == 0)
        {
            ds2.Tables[0].Rows.Add(ds2.Tables[0].NewRow());
            gv_refdata.DataSource = ds2;
            gv_refdata.DataBind();
            int columncount = gv_refdata.Rows[0].Cells.Count;
            gv_refdata.Rows[0].Cells.Clear();
            gv_refdata.Rows[0].Cells.Add(new TableCell());
            gv_refdata.Rows[0].Cells[0].ColumnSpan = columncount;
            gv_refdata.Rows[0].Cells[0].Text = "<center><strong>Maklumat Carian Tidak Dijumpai</strong></center>";
        }
        else
        {
            gv_refdata.DataSource = ds2;
            gv_refdata.DataBind();
        }
    }



    protected void gv_refdata_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("ADD"))
        {
            System.Web.UI.WebControls.TextBox txtAddName = (System.Web.UI.WebControls.TextBox)gv_refdata.FooterRow.FindControl("txtAddName");
            System.Web.UI.WebControls.TextBox txtAddcode = (System.Web.UI.WebControls.TextBox)gv_refdata.FooterRow.FindControl("txtAddcode");
            //DropDownList ddlStatus = (DropDownList)gv_refdata.FooterRow.FindControl("ddlStatus");
            System.Web.UI.WebControls.CheckBox chk_h1 = ((System.Web.UI.WebControls.CheckBox)gv_refdata.FooterRow.FindControl("chk_h1_upd1"));
            System.Web.UI.WebControls.CheckBox chk_h2 = ((System.Web.UI.WebControls.CheckBox)gv_refdata.FooterRow.FindControl("chk_h2_upd1"));
            System.Web.UI.WebControls.CheckBox chk_h3 = ((System.Web.UI.WebControls.CheckBox)gv_refdata.FooterRow.FindControl("chk_h3_upd1"));
            System.Web.UI.WebControls.CheckBox chk_h4 = ((System.Web.UI.WebControls.CheckBox)gv_refdata.FooterRow.FindControl("chk_h4_upd1"));
            System.Web.UI.WebControls.CheckBox chk_h5 = ((System.Web.UI.WebControls.CheckBox)gv_refdata.FooterRow.FindControl("chk_h5_upd1"));
            System.Web.UI.WebControls.CheckBox chk_h6 = ((System.Web.UI.WebControls.CheckBox)gv_refdata.FooterRow.FindControl("chk_h6_upd1"));
            System.Web.UI.WebControls.CheckBox chk_h7 = ((System.Web.UI.WebControls.CheckBox)gv_refdata.FooterRow.FindControl("chk_h7_upd1"));
            if (chk_h1 != null && chk_h1.Checked)
            {
                h1 = "S";
            }
            else
            {
                h1 = "T";
            }
            if (chk_h2 != null && chk_h2.Checked)
            {
                h2 = "S";
            }
            else
            {
                h2 = "T";
            }
            if (chk_h3 != null && chk_h3.Checked)
            {
                h3 = "S";
            }
            else
            {
                h3 = "T";
            }
            if (chk_h4 != null && chk_h4.Checked)
            {
                h4 = "S";
            }
            else
            {
                h4 = "T";
            }
            if (chk_h5 != null && chk_h5.Checked)
            {
                h5 = "S";
            }
            else
            {
                h5 = "T";
            }

            if (chk_h6 != null && chk_h6.Checked)
            {
                h6 = "S";
            }
            else
            {
                h6 = "T";
            }

            if (chk_h7 != null && chk_h7.Checked)
            {
                h7 = "S";
            }
            else
            {
                h7 = "T";
            }


            if (txtAddName.Text != "" && txtAddcode.Text != "")
            {

                DataTable dtcenter = new DataTable();
                ref_table();
                dtcenter = Dblog.Ora_Execute_table("select * from " + tn1 + " where " + tc1 + "='" + txtAddName.Text + "'");
                if (dtcenter.Rows.Count == 0)
                {
                    conn.Open();
                    string cmdstr = "insert into " + tn1 + " (" + tc1 + "," + tc2 + "," + tc3 + "," + tc5 + "," + tc6 + "," + tc7 + "," + tc8 + "," + tc9 + "," + tc11 + "," + tc12 + ") values(@" + tc1 + ",@" + tc2 + ",@" + tc3 + ",@" + tc5 + ",@" + tc6 + ",@" + tc7 + ",@" + tc8 + ",@" + tc9 + ",@" + tc11 + ",@" + tc12 + ")";
                    SqlCommand cmd = new SqlCommand(cmdstr, conn);
                    cmd.Parameters.AddWithValue("@" + tc1 + "", txtAddName.Text);
                    cmd.Parameters.AddWithValue("@" + tc2 + "", txtAddcode.Text);
                    cmd.Parameters.AddWithValue("@" + tc3 + "", "A");
                    cmd.Parameters.AddWithValue("@" + tc5 + "", h1.ToString());
                    cmd.Parameters.AddWithValue("@" + tc6 + "", h2.ToString());
                    cmd.Parameters.AddWithValue("@" + tc7 + "", h3.ToString());
                    cmd.Parameters.AddWithValue("@" + tc8 + "", h4.ToString());
                    cmd.Parameters.AddWithValue("@" + tc9 + "", h5.ToString());
                    cmd.Parameters.AddWithValue("@" + tc11 + "", h6.ToString());
                    cmd.Parameters.AddWithValue("@" + tc12 + "", h7.ToString());
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    sel_val();
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Berjaya Masukkan rekod.',{'type': 'confirmation','title': 'Success','auto_close': 2000});", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Sudah Wujud.',{'type': 'warning','title': 'Warning','auto_close': 2000});", true);
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukkan Nilai.',{'type': 'warning','title': 'Warning','auto_close': 2000});", true);
                sel_val();
            }
        }
    }


    protected void ChckedChangedBil1(object sender, EventArgs e)
    {
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        decimal numTotal1 = 0;
        int selRowIndex = ((GridViewRow)(((System.Web.UI.WebControls.CheckBox)sender).Parent.Parent)).RowIndex;
        System.Web.UI.WebControls.CheckBox cb = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[selRowIndex].FindControl("chk_h1_upd");
        System.Web.UI.WebControls.TextBox tOt = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[selRowIndex].FindControl("txtEditcode");
        DataTable dtcenter1 = new DataTable();
        dtcenter1 = Dblog.Ora_Execute_table("select top(1) (tmp_position + 1) as cnt from kw_template_aliran where tmp_h1='S' order by cast(tmp_position as int) desc");
        if (cb.Checked == true)
        {
            if (dtcenter1.Rows.Count != 0)
            {
                tOt.Text = dtcenter1.Rows[0]["cnt"].ToString();
            }
            else
            {
                tOt.Text = "1";
            }
        }
        else
        {
            tOt.Text = "";
        }

    }

    protected void ChckedChangedBil2(object sender, EventArgs e)
    {
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        decimal numTotal1 = 0;
        int selRowIndex = ((GridViewRow)(((System.Web.UI.WebControls.CheckBox)sender).Parent.Parent)).RowIndex;
        System.Web.UI.WebControls.CheckBox cb = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[selRowIndex].FindControl("chk_h2_upd");
        System.Web.UI.WebControls.TextBox tOt = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[selRowIndex].FindControl("txtEditcode");
        DataTable dtcenter1 = new DataTable();
        dtcenter1 = Dblog.Ora_Execute_table("select top(1) (tmp_position + 1) as cnt from kw_template_aliran where tmp_h2='S' order by cast(tmp_position as int) desc");
        if (cb.Checked == true)
        {
            if (dtcenter1.Rows.Count != 0)
            {
                tOt.Text = dtcenter1.Rows[0]["cnt"].ToString();
            }
            else
            {
                tOt.Text = "1";
            }
        }
        else
        {
            tOt.Text = "";
        }

    }

    protected void ChckedChangedBil3(object sender, EventArgs e)
    {
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        decimal numTotal1 = 0;
        int selRowIndex = ((GridViewRow)(((System.Web.UI.WebControls.CheckBox)sender).Parent.Parent)).RowIndex;
        System.Web.UI.WebControls.CheckBox cb = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[selRowIndex].FindControl("chk_h3_upd");
        System.Web.UI.WebControls.TextBox tOt = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[selRowIndex].FindControl("txtEditcode");
        DataTable dtcenter1 = new DataTable();
        dtcenter1 = Dblog.Ora_Execute_table("select top(1) (tmp_position + 1) as cnt from kw_template_aliran where tmp_h3='S' order by cast(tmp_position as int) desc");
        if (cb.Checked == true)
        {
            if (dtcenter1.Rows.Count != 0)
            {
                tOt.Text = dtcenter1.Rows[0]["cnt"].ToString();
            }
            else
            {
                tOt.Text = "1";
            }
        }
        else
        {
            tOt.Text = "";
        }

    }

    protected void ChckedChangedBil4(object sender, EventArgs e)
    {
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        decimal numTotal1 = 0;
        int selRowIndex = ((GridViewRow)(((System.Web.UI.WebControls.CheckBox)sender).Parent.Parent)).RowIndex;
        System.Web.UI.WebControls.CheckBox cb = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[selRowIndex].FindControl("chk_h4_upd");
        System.Web.UI.WebControls.TextBox tOt = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[selRowIndex].FindControl("txtEditcode");
        DataTable dtcenter1 = new DataTable();
        dtcenter1 = Dblog.Ora_Execute_table("select top(1) (tmp_position + 1) as cnt from kw_template_aliran where tmp_h4='S' order by cast(tmp_position as int) desc");
        if (cb.Checked == true)
        {
            if (dtcenter1.Rows.Count != 0)
            {
                tOt.Text = dtcenter1.Rows[0]["cnt"].ToString();
            }
            else
            {
                tOt.Text = "1";
            }
        }
        else
        {
            tOt.Text = "";
        }

    }

    protected void ChckedChangedBil5(object sender, EventArgs e)
    {
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        decimal numTotal1 = 0;
        int selRowIndex = ((GridViewRow)(((System.Web.UI.WebControls.CheckBox)sender).Parent.Parent)).RowIndex;
        System.Web.UI.WebControls.CheckBox cb = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[selRowIndex].FindControl("chk_h5_upd");
        System.Web.UI.WebControls.TextBox tOt = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[selRowIndex].FindControl("txtEditcode");
        DataTable dtcenter1 = new DataTable();
        dtcenter1 = Dblog.Ora_Execute_table("select top(1) (tmp_position + 1) as cnt from kw_template_aliran where tmp_h5='S' order by cast(tmp_position as int) desc");
        if (cb.Checked == true)
        {
            if (dtcenter1.Rows.Count != 0)
            {
                tOt.Text = dtcenter1.Rows[0]["cnt"].ToString();
            }
            else
            {
                tOt.Text = "1";
            }
        }
        else
        {
            tOt.Text = "";
        }

    }

    protected void ChckedChangedBil6(object sender, EventArgs e)
    {
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        decimal numTotal1 = 0;
        int selRowIndex = ((GridViewRow)(((System.Web.UI.WebControls.CheckBox)sender).Parent.Parent)).RowIndex;
        System.Web.UI.WebControls.CheckBox cb = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[selRowIndex].FindControl("chk_h6_upd");
        System.Web.UI.WebControls.TextBox tOt = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[selRowIndex].FindControl("txtEditcode");
        DataTable dtcenter1 = new DataTable();
        dtcenter1 = Dblog.Ora_Execute_table("select top(1) (tmp_position + 1) as cnt from kw_template_aliran where tmp_h6='S' order by cast(tmp_position as int) desc");
        if (cb.Checked == true)
        {
            if (dtcenter1.Rows.Count != 0)
            {
                tOt.Text = dtcenter1.Rows[0]["cnt"].ToString();
            }
            else
            {
                tOt.Text = "1";
            }
        }
        else
        {
            tOt.Text = "";
        }

    }

    protected void ChckedChangedBil7(object sender, EventArgs e)
    {
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        decimal numTotal1 = 0;
        int selRowIndex = ((GridViewRow)(((System.Web.UI.WebControls.CheckBox)sender).Parent.Parent)).RowIndex;
        System.Web.UI.WebControls.CheckBox cb = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[selRowIndex].FindControl("chk_h7_upd");
        System.Web.UI.WebControls.TextBox tOt = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[selRowIndex].FindControl("txtEditcode");
        DataTable dtcenter1 = new DataTable();
        dtcenter1 = Dblog.Ora_Execute_table("select top(1) (tmp_position + 1) as cnt from kw_template_aliran where tmp_h7='S' order by cast(tmp_position as int) desc");
        if (cb.Checked == true)
        {
            if (dtcenter1.Rows.Count != 0)
            {
                tOt.Text = dtcenter1.Rows[0]["cnt"].ToString();
            }
            else
            {
                tOt.Text = "1";
            }
        }
        else
        {
            tOt.Text = "";
        }

    }

    protected void gv_refdata_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        //sel_val();
        System.Web.UI.WebControls.TextBox Id = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[e.RowIndex].FindControl("Id");
        System.Web.UI.WebControls.TextBox lblEditName = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[e.RowIndex].FindControl("id_kod");
        System.Web.UI.WebControls.TextBox txtEditcode = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[e.RowIndex].FindControl("txtEditcode");
        //DropDownList editddlStatus = (DropDownList)gv_refdata.Rows[e.RowIndex].FindControl("editddlStatus");
        DropDownList ddlStatus = (DropDownList)gv_refdata.FooterRow.FindControl("ddlStatus");
        System.Web.UI.WebControls.CheckBox chk_h1 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h1_upd") as System.Web.UI.WebControls.CheckBox;
        System.Web.UI.WebControls.CheckBox chk_h2 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h2_upd") as System.Web.UI.WebControls.CheckBox;
        System.Web.UI.WebControls.CheckBox chk_h3 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h3_upd") as System.Web.UI.WebControls.CheckBox;
        System.Web.UI.WebControls.CheckBox chk_h4 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h4_upd") as System.Web.UI.WebControls.CheckBox;
        System.Web.UI.WebControls.CheckBox chk_h5 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h5_upd") as System.Web.UI.WebControls.CheckBox;
        System.Web.UI.WebControls.CheckBox chk_h6 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h6_upd") as System.Web.UI.WebControls.CheckBox;
        System.Web.UI.WebControls.CheckBox chk_h7 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h7_upd") as System.Web.UI.WebControls.CheckBox;
        DataTable dtcenter1 = new DataTable();
        if (chk_h1 != null && chk_h1.Checked)
        {
            h1 = "S";
            sq1 = "1";
            dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h1='S' and cast(tmp_position as int) >= '" + txtEditcode.Text + "' and tmp_kod_akaun !='" + lblEditName.Text + "' order by cast(tmp_position as int) asc");
        }
        else
        {
            h1 = "T";
        }
        if (chk_h2 != null && chk_h2.Checked)
        {
            h2 = "S";
            sq1 = "2";
            dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h2='S' and cast(tmp_position as int) >= '" + txtEditcode.Text + "' and tmp_kod_akaun !='" + lblEditName.Text + "' order by cast(tmp_position as int) asc");
        }
        else
        {
            h2 = "T";
        }
        if (chk_h3 != null && chk_h3.Checked)
        {
            h3 = "S";
            sq1 = "3";
            dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h3='S' and cast(tmp_position as int) >= '" + txtEditcode.Text + "' and tmp_kod_akaun !='" + lblEditName.Text + "' order by cast(tmp_position as int) asc");
        }
        else
        {
            h3 = "T";
        }
        if (chk_h4 != null && chk_h4.Checked)
        {
            h4 = "S";
            sq1 = "4";
            dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h4='S' and cast(tmp_position as int) >= '" + txtEditcode.Text + "' and tmp_kod_akaun !='" + lblEditName.Text + "' order by cast(tmp_position as int) asc");
        }
        else
        {
            h4 = "T";
        }
        if (chk_h5 != null && chk_h5.Checked)
        {
            h5 = "S";
            sq1 = "5";

            dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h5='S' and cast(tmp_position as int) >= '" + txtEditcode.Text + "' and tmp_kod_akaun !='" + lblEditName.Text + "' order by cast(tmp_position as int) asc");
        }
        else
        {
            h5 = "T";
        }

        if (chk_h6 != null && chk_h6.Checked)
        {
            h6 = "S";
            sq1 = "6";

            dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h6='S' and cast(tmp_position as int) >= '" + txtEditcode.Text + "' and tmp_kod_akaun !='" + lblEditName.Text + "' order by cast(tmp_position as int) asc");
        }
        else
        {
            h6 = "T";
        }

        if (chk_h7 != null && chk_h7.Checked)
        {
            h7 = "S";
            sq1 = "7";

            dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h7='S' and cast(tmp_position as int) >= '" + txtEditcode.Text + "' and tmp_kod_akaun !='" + lblEditName.Text + "' order by cast(tmp_position as int) asc");
        }
        else
        {
            h7 = "T";
        }

        ref_table();
        DataTable dtcenter = new DataTable();
        dtcenter = Dblog.Ora_Execute_table("select * from " + tn1 + " where " + tc1 + "='" + lblEditName.Text + "'");
        if (dtcenter.Rows.Count == 0)
        {

            if (dtcenter1.Rows.Count != 0)
            {
                for (int k = 0; k < dtcenter1.Rows.Count; k++)
                {
                    int pos_no = ((Int32.Parse(txtEditcode.Text) + 1) + k);
                    string Inssql = "UPDATE kw_template_aliran set tmp_position='" + pos_no + "' where tmp_kod_akaun = '" + dtcenter1.Rows[k]["tmp_kod_akaun"].ToString() + "'";
                    Status = DBCon.Ora_Execute_CommamdText(Inssql);
                }
            }
            conn.Open();
            string cmdstr = "insert into " + tn1 + " (" + tc1 + "," + tc2 + "," + tc3 + "," + tc5 + "," + tc6 + "," + tc7 + "," + tc8 + "," + tc9 + " ," + tc10 + "," + tc11 + "," + tc12 + ") values(@" + tc1 + ",@" + tc2 + ",@" + tc3 + ",@" + tc5 + ",@" + tc6 + ",@" + tc7 + ",@" + tc8 + ",@" + tc9 + ",@" + tc10 + ",@" + tc11 + ",@" + tc12 + ")";
            SqlCommand cmd = new SqlCommand(cmdstr, conn);
            cmd.Parameters.AddWithValue("@" + tc1 + "", lblEditName.Text);
            cmd.Parameters.AddWithValue("@" + tc2 + "", txtEditcode.Text);
            cmd.Parameters.AddWithValue("@" + tc3 + "", "A");
            cmd.Parameters.AddWithValue("@" + tc5 + "", h1.ToString());
            cmd.Parameters.AddWithValue("@" + tc6 + "", h2.ToString());
            cmd.Parameters.AddWithValue("@" + tc7 + "", h3.ToString());
            cmd.Parameters.AddWithValue("@" + tc8 + "", h4.ToString());
            cmd.Parameters.AddWithValue("@" + tc9 + "", h5.ToString());
            cmd.Parameters.AddWithValue("@" + tc10 + "", sq1.ToString());
            cmd.Parameters.AddWithValue("@" + tc11 + "", h6.ToString());
            cmd.Parameters.AddWithValue("@" + tc12 + "", h7.ToString());
            cmd.ExecuteNonQuery();
            conn.Close();
            gv_refdata.EditIndex = -1;
            sel_val();
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Berjaya Simpan.',{'type': 'confirmation','title': 'Success','auto_close': 2000});", true);
        }
        else
        {

            if (dtcenter1.Rows.Count != 0)
            {
                for (int k = 0; k < dtcenter1.Rows.Count; k++)
                {
                    int pos_no = ((Int32.Parse(txtEditcode.Text) + 1) + k);
                    string Inssql = "UPDATE kw_template_aliran set tmp_position='" + pos_no + "' where tmp_kod_akaun = '" + dtcenter1.Rows[k]["tmp_kod_akaun"].ToString() + "'";
                    Status = DBCon.Ora_Execute_CommamdText(Inssql);
                }
            }
            conn.Open();
            string cmdstr = "update " + tn1 + " set " + tc1 + "=@" + tc1 + "," + tc2 + "=@" + tc2 + "," + tc3 + "=@" + tc3 + "," + tc5 + "=@" + tc5 + "," + tc6 + "=@" + tc6 + "," + tc7 + "=@" + tc7 + "," + tc8 + "=@" + tc8 + "," + tc9 + "=@" + tc9 + "," + tc10 + "=@" + tc10 + "," + tc11 + "=@" + tc11 + "," + tc12 + "=@" + tc12 + " where " + tc4 + "=@" + tc4 + "";
            SqlCommand cmd = new SqlCommand(cmdstr, conn);
            cmd.Parameters.AddWithValue("@" + tc1 + "", lblEditName.Text);
            cmd.Parameters.AddWithValue("@" + tc2 + "", txtEditcode.Text);
            cmd.Parameters.AddWithValue("@" + tc3 + "", "A");
            cmd.Parameters.AddWithValue("@" + tc5 + "", h1.ToString());
            cmd.Parameters.AddWithValue("@" + tc6 + "", h2.ToString());
            cmd.Parameters.AddWithValue("@" + tc7 + "", h3.ToString());
            cmd.Parameters.AddWithValue("@" + tc8 + "", h4.ToString());
            cmd.Parameters.AddWithValue("@" + tc9 + "", h5.ToString());
            cmd.Parameters.AddWithValue("@" + tc10 + "", sq1.ToString());
            cmd.Parameters.AddWithValue("@" + tc11 + "", h6.ToString());
            cmd.Parameters.AddWithValue("@" + tc12 + "", h7.ToString());
            cmd.Parameters.AddWithValue("@" + tc4 + "", Id.Text);
            cmd.ExecuteNonQuery();
            conn.Close();

            gv_refdata.EditIndex = -1;
            sel_val();
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Berjaya Dikemaskini.',{'type': 'confirmation','title': 'Success','auto_close': 2000});", true);

        }
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        BindData();
    }

    protected void gv_refdata_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string confirmValue = Request.Form["confirm_value"].ToString();
        if (confirmValue == "Yes" || confirmValue == "Yes,Yes" || confirmValue == "Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes" || confirmValue == "Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes,Yes")
        {
            System.Web.UI.WebControls.TextBox Id = (System.Web.UI.WebControls.TextBox)gv_refdata.Rows[e.RowIndex].FindControl("Id");
            System.Web.UI.WebControls.Label post = (System.Web.UI.WebControls.Label)gv_refdata.Rows[e.RowIndex].FindControl("lblName");
            System.Web.UI.WebControls.CheckBox chk_h1 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h1");
            System.Web.UI.WebControls.CheckBox chk_h2 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h2");
            System.Web.UI.WebControls.CheckBox chk_h3 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h3");
            System.Web.UI.WebControls.CheckBox chk_h4 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h4");
            System.Web.UI.WebControls.CheckBox chk_h5 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h5");
            System.Web.UI.WebControls.CheckBox chk_h6 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h6");
            System.Web.UI.WebControls.CheckBox chk_h7 = (System.Web.UI.WebControls.CheckBox)gv_refdata.Rows[e.RowIndex].FindControl("chk_h7");
            DataTable dtcenter1 = new DataTable();
            if (chk_h1 != null && chk_h1.Checked)
            {
                dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h1='S' and cast(tmp_position as int) > '" + post.Text + "' order by cast(tmp_position as int) asc");
            }

            if (chk_h2 != null && chk_h2.Checked)
            {

                dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h2='S' and cast(tmp_position as int) > '" + post.Text + "' order by cast(tmp_position as int) asc");
            }

            if (chk_h3 != null && chk_h3.Checked)
            {

                dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h3='S' and cast(tmp_position as int) > '" + post.Text + "' order by cast(tmp_position as int) asc");
            }

            if (chk_h4 != null && chk_h4.Checked)
            {

                dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h4='S' and cast(tmp_position as int) > '" + post.Text + "' order by cast(tmp_position as int) asc");
            }

            if (chk_h5 != null && chk_h5.Checked)
            {
                dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h5='S' and cast(tmp_position as int) > '" + post.Text + "' order by cast(tmp_position as int) asc");
            }

            if (chk_h6 != null && chk_h6.Checked)
            {
                dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h6='S' and cast(tmp_position as int) > '" + post.Text + "' order by cast(tmp_position as int) asc");
            }

            if (chk_h7 != null && chk_h7.Checked)
            {
                dtcenter1 = Dblog.Ora_Execute_table("select * from kw_template_aliran where tmp_h7='S' and cast(tmp_position as int) > '" + post.Text + "' order by cast(tmp_position as int) asc");
            }

            if (dtcenter1.Rows.Count != 0)
            {
                for (int k = 0; k < dtcenter1.Rows.Count; k++)
                {
                    int pos_no = (Int32.Parse(post.Text) + k);
                    string Inssql = "UPDATE kw_template_aliran set tmp_position='" + pos_no + "' where tmp_kod_akaun = '" + dtcenter1.Rows[k]["tmp_kod_akaun"].ToString() + "'";
                    Status = DBCon.Ora_Execute_CommamdText(Inssql);
                }
            }
            conn.Open();
            ref_table();
            string cmdstr = "delete from " + tn1 + " where " + tc4 + "=@Id";
            SqlCommand cmd = new SqlCommand(cmdstr, conn);
            cmd.Parameters.AddWithValue("@Id", Id.Text);
            cmd.ExecuteNonQuery();
            conn.Close();
            sel_val();
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod berjaya dipadamkan.',{'type': 'confirmation','title': 'Success','auto_close': 2000});", true);
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Anda Buang Lebih 20 Records Sila muat semula dan cuba lagi!!.',{'type': 'warning','title': 'Warning','auto_close': 2000});", true);
        }
    }

    //protected void gvSelected_PageIndexChanging(object sender, GridViewPageEventArgs e)
    //{
    //    gv_refdata.PageIndex = e.NewPageIndex;
    //    gv_refdata.DataBind();
    //    BindData();
    //}
    protected void gv_refdata_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gv_refdata.EditIndex = -1;
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        sel_val();
    }

    protected void gv_refdata_RowEditing(object sender, GridViewEditEventArgs e)
    {
        string script = " $(function () {$(" + gv_refdata.ClientID + ") .prepend($('<thead></thead>').append($(this).find('tr:first'))).DataTable({'responsive': true,'sPaginationType': 'full_numbers',  'iDisplayLength': 15,'aLengthMenu': [[15, 30, 50, 100], [15, 30, 50, 100]]});});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        gv_refdata.EditIndex = e.NewEditIndex;
        sel_val();
    }



    protected void btn_reset(object sender, EventArgs e)
    {
        Response.Redirect("../kewengan/kw_template_aliran.aspx");
    }


}