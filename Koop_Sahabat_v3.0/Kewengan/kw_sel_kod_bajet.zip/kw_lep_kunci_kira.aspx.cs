﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Threading;

public partial class kw_lep_kunci_kira : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();
    private static int PageSize = 20;
    string qry1 = string.Empty, qry2 = string.Empty;
    string level;
    string Status = string.Empty;
    string userid;
    string CommandArgument1 = string.Empty, CommandArgument2 = string.Empty, CommandArgument3 = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        app_language();
        Button4.OnClientClick = @"if(this.value == 'Please wait...')
           return false;
           this.value = 'Please wait...';this.disabled=true";
        string script = " $(function () {$('.select2').select2()});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        //ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        //scriptManager.RegisterPostBackControl(this.Button4);
        
        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {
                userid = Session["New"].ToString();
                project();
                //BindDropdown();
                
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
    }

    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('828','705','1724','65','502','169','1841','121','15','64')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[7][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[6][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[7][0].ToString().ToLower());
            ps_lbl4.Text = txtinfo.ToTitleCase(gt_lng.Rows[8][0].ToString().ToLower());          
            ps_lbl5.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
            ps_lbl6.Text = txtinfo.ToTitleCase(gt_lng.Rows[2][0].ToString().ToLower());
            //ps_lbl7.Text = txtinfo.ToTitleCase(gt_lng.Rows[5][0].ToString().ToLower());
            ps_lbl8.Text = txtinfo.ToTitleCase(gt_lng.Rows[3][0].ToString().ToLower());
            ps_lbl9.Text = txtinfo.ToTitleCase(gt_lng.Rows[9][0].ToString().ToLower());
            Button4.Text = txtinfo.ToTitleCase(gt_lng.Rows[4][0].ToString().ToLower());
            Button1.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());
           
        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }
    void project()
    {
        DataSet Ds = new DataSet();
        try
        {
            string com = "select Ref_Projek_code,Ref_Projek_name from  KW_Ref_Projek";
            SqlDataAdapter adpt = new SqlDataAdapter(com, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            ddpro.DataSource = dt;
            ddpro.DataTextField = "Ref_Projek_name";
            ddpro.DataValueField = "Ref_Projek_code";
            ddpro.DataBind();
            ddpro.Items.Insert(0, new ListItem("--- PILIH ---", ""));

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    //void BindDropdown()
    //{
    //    DateTimeFormatInfo info = DateTimeFormatInfo.GetInstance(null);

    //    int year = DateTime.Now.Year - 6;

    //    for (int Y = year; Y <= DateTime.Now.Year; Y++)

    //    {

    //        Tahun_kew.Items.Add(new ListItem(Y.ToString(), Y.ToString()));

    //    }

    //    Tahun_kew.SelectedValue = DateTime.Now.Year.ToString();

    //}



    protected void clk_submit(object sender, EventArgs e)
    {
        if (Tk_mula.Text != "" && Tk_akhir.Text != "")
        {
            string val1 = string.Empty, val2 = string.Empty, val3 = string.Empty, val4 = string.Empty, val5 = string.Empty, val6 = string.Empty, sqry = string.Empty, py_fdate = string.Empty, py_ldate = string.Empty, curr_yr = string.Empty, prev_yr = string.Empty;

            int min_val = 1;
            string fmdate = string.Empty, tmdate = string.Empty, tmdate1 = string.Empty;
            if (Tk_mula.Text != "")
            {
                string fdate = Tk_mula.Text;
                DateTime fd = DateTime.ParseExact(fdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                fmdate = fd.ToString("yyyy-MM-dd");
                prev_yr = fd.ToString("yyyy");
            }
            if (Tk_akhir.Text != "")
            {
                string tdate = Tk_akhir.Text;
                DateTime td = DateTime.ParseExact(tdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                tmdate = td.ToString("yyyy-MM-dd");
                curr_yr = td.ToString("yyyy");
               
                tmdate1 = td.ToString("dd MMMM yyyy");
            }
            //int curr_yr = Int32.Parse(Tahun_kew.SelectedValue);
            //int prev_yr = (Int32.Parse(Tahun_kew.SelectedValue) - min_val);
            //py_fdate = prev_yr + "-01-01";
            //py_ldate = prev_yr + "-12-31";
            
            
            py_fdate = fmdate;
            py_ldate = tmdate;

            if (Tk_mula.Text != "" && Tk_akhir.Text != "" && ddpro.SelectedValue == "")
            {
                //qry1 = "select r1.bal_type as baltype,case when r1.kat_cd = '04' then 'D' else r1.bal_type end as baltype1,case when r1.kat_cd = '06' then 'D' when r1.kat_cd = '07' then 'D' when r1.kat_cd = '08' then 'D' else r1.bal_type end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun , cast((replace( (( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') )) ,'-','') + ISNULL(b2.kt,'0.00')) as money) as val2,cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money) as val1,(cast((replace( (( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') )) ,'-','') + ISNULL(b2.kt,'0.00')) as money) - cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where kkk_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "' and Susu_nilai != '1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate +"' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '"+ fmdate +"'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+ tmdate +"'), +1) group by kat_akaun,kod_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun =a.kat_akaun  left join(select m1.kat_akaun,m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and '"+ fmdate + "' between start_dt and end_dt where jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1' and Susu_nilai = '1' group by m1.kat_akaun,m1.under_jenis,m1.kod_akaun) as d on d.under_jenis=a.kod_akaun Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate +"'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+ tmdate + "'), +1) group by kat_akaun,kod_akaun) as b1 on b1.kod_akaun = d.kod_akaun and b1.kat_akaun =d.kat_akaun left join (select '05.02' as kod_akaun,(ISNULL(a.val1,'0.00') - ISNULL(b.val1,'0.00')) as kt from (select '01' as vv1,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1 from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type='" + akaun_level.SelectedValue + "' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) group by kod_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate +"' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '"+ fmdate +"'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+ tmdate + "'), +1) group by kod_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun ) as a left join (select '01' as vv1,(SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) * 2) as val1 from (select * from KW_Ref_Carta_Akaun where PAL_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate +"' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '"+ fmdate +"'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '"+ tmdate +"'), +1) group by kod_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' ) as b on b.vv1=a.vv1) as b2 on b2.kod_akaun=a.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun order by r1.bal_type,r1.kat_cd,a.kod_akaun asc";
                qry1 = "select distinct r1.bal_type as baltype,case when r1.kat_cd = '04' then 'D' else r1.bal_type end as baltype1,case when r1.kat_cd = '06' then 'D' when r1.kat_cd = '07' then 'D' when r1.kat_cd = '08' then 'D' else r1.bal_type end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun , cast(replace(( (( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') ))  + ISNULL(b2.kt,'0.00')),'-','') as money) as val2,cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money) as val1,(cast(replace( ((( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') )) + ISNULL(b2.kt,'0.00'))  ,'-','') as money) - cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where kkk_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "' and Susu_nilai != '1') as a Left join(select kod_akaun,kat_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kat_akaun,kod_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun =a.kat_akaun  left join(select m1.kat_akaun,m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1' and Susu_nilai = '1' group by m1.kat_akaun,m1.under_jenis,m1.kod_akaun) as d on d.under_jenis like '%'+a.kod_akaun+'%' Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kat_akaun,kod_akaun) as b1 on b1.kod_akaun = d.kod_akaun and b1.kat_akaun =d.kat_akaun left join (select '05.02' as kod_akaun,(ISNULL(a.val1,'0.00') - ISNULL(b.val1,'0.00')) as kt from (select '01' as vv1,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1 from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1') as a Left join(select kod_akaun,kat_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,kat_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) group by kod_akaun,kat_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' and a2.kat_akaun=a.kat_akaun Left join(select kod_akaun,kat_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as b1 on b1.kod_akaun like '%'+a.kod_akaun+'%' and b1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun ) as a left join (select '01' as vv1,(SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) * 2) as val1 from (select * from KW_Ref_Carta_Akaun where kkk_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt,kat_akaun from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) group by kod_akaun,kat_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' and a2.kat_akaun=a.kat_akaun Left join(select kod_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt,kat_akaun from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as b1 on b1.kod_akaun like '%'+a.kod_akaun+'%' and b1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' ) as b on b.vv1=a.vv1) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun order by r1.bal_type,r1.kat_cd,a.kod_akaun asc";
                sqry = "select s1.kod_akaun as a11,s1.kod_akaun +' | ' +s1.nama_akaun as a1,'KEUNTUNGAN (KERUGIAN) BERSIH' as a2,ISNULL((b.val1 -a.val1), '0.00') as a3 from (select r1.bal_type as baltype,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,sum(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' group by r1.bal_type) as a left join(select r1.bal_type as baltype,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,sum(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and kkk_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='K' group by r1.bal_type) as b on b.baltype!=a.baltype left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun='05.02.01'";

            }
            else if (Tk_mula.Text != "" && Tk_akhir.Text != "" && ddpro.SelectedValue != "")
            {
                //qry1 = "select r1.bal_type as baltype,case when r1.kat_cd = '04' then 'D' else r1.bal_type end as baltype1,case when r1.kat_cd = '06' then 'D' when r1.kat_cd = '07' then 'D' when r1.kat_cd = '08' then 'D' else r1.bal_type end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun , cast((replace( (( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') )) ,'-','') + ISNULL(b2.kt,'0.00')) as money) as val2,cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money) as val1,(cast((replace( (( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') )) ,'-','') + ISNULL(b2.kt,'0.00')) as money) - cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where kkk_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "' and Susu_nilai != '1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where  GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kat_akaun,kod_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun =a.kat_akaun  left join(select m1.kat_akaun,m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1' and Susu_nilai = '1' group by m1.kat_akaun,m1.under_jenis,m1.kod_akaun) as d on d.under_jenis=a.kod_akaun Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where  GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kat_akaun,kod_akaun) as b1 on b1.kod_akaun = d.kod_akaun and b1.kat_akaun =d.kat_akaun left join (select '05.02' as kod_akaun,(ISNULL(a.val1,'0.00') - ISNULL(b.val1,'0.00')) as kt from (select '01' as vv1,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1 from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type='" + akaun_level.SelectedValue + "' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun ) as a left join (select '01' as vv1,(SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) * 2) as val1 from (select * from KW_Ref_Carta_Akaun where PAL_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1)  and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' ) as b on b.vv1=a.vv1) as b2 on b2.kod_akaun=a.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun order by r1.bal_type,r1.kat_cd,a.kod_akaun asc";
                qry1 = "select distinct r1.bal_type as baltype,case when r1.kat_cd = '04' then 'D' else r1.bal_type end as baltype1,case when r1.kat_cd = '06' then 'D' when r1.kat_cd = '07' then 'D' when r1.kat_cd = '08' then 'D' else r1.bal_type end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun , cast(replace(( (( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') ))  + ISNULL(b2.kt,'0.00')),'-','') as money) as val2,cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money) as val1,(cast(replace( ((( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') )) + ISNULL(b2.kt,'0.00'))  ,'-','') as money) - cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where kkk_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "' and Susu_nilai != '1') as a Left join(select kod_akaun,kat_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kat_akaun,kod_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun =a.kat_akaun  left join(select m1.kat_akaun,m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1' and Susu_nilai = '1' group by m1.kat_akaun,m1.under_jenis,m1.kod_akaun) as d on d.under_jenis like '%'+a.kod_akaun+'%' Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kat_akaun,kod_akaun) as b1 on b1.kod_akaun = d.kod_akaun and b1.kat_akaun =d.kat_akaun left join (select '05.02' as kod_akaun,(ISNULL(a.val1,'0.00') - ISNULL(b.val1,'0.00')) as kt from (select '01' as vv1,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1 from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1') as a Left join(select kod_akaun,kat_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,kat_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' and a2.kat_akaun=a.kat_akaun Left join(select kod_akaun,kat_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as b1 on b1.kod_akaun like '%'+a.kod_akaun+'%' and b1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun ) as a left join (select '01' as vv1,(SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) * 2) as val1 from (select * from KW_Ref_Carta_Akaun where kkk_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt,kat_akaun from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' and a2.kat_akaun=a.kat_akaun Left join(select kod_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt,kat_akaun from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as b1 on b1.kod_akaun like '%'+a.kod_akaun+'%' and b1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' ) as b on b.vv1=a.vv1) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun order by r1.bal_type,r1.kat_cd,a.kod_akaun asc";
                sqry = "select s1.kod_akaun as a11,s1.kod_akaun +' | ' +s1.nama_akaun as a1,'KEUNTUNGAN (KERUGIAN) BERSIH' as a2,ISNULL((b.val1 -a.val1), '0.00') as a3 from (select r1.bal_type as baltype,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,sum(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and kkk_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' group by r1.bal_type) as a left join(select r1.bal_type as baltype,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,sum(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where  jenis_akaun_type != '1' and kkk_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "'group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='K' group by r1.bal_type) as b on b.baltype!=a.baltype left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun='05.02.01'";
            }

            else
            {
                qry1 = "select distinct r1.bal_type as baltype,case when r1.kat_cd = '04' then 'D' else r1.bal_type end as baltype1,case when r1.kat_cd = '06' then 'D' when r1.kat_cd = '07' then 'D' when r1.kat_cd = '08' then 'D' else r1.bal_type end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun , cast(replace(( (( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') ))  + ISNULL(b2.kt,'0.00')),'-','') as money) as val2,cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money) as val1,(cast(replace( ((( (ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00') ) +( (ISNULL(d.amt1,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00') )) + ISNULL(b2.kt,'0.00'))  ,'-','') as money) - cast(replace(ISNULL(a1.opening_amt,'0.00') ,'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where kkk_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "' and Susu_nilai != '1') as a Left join(select kod_akaun,kat_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kat_akaun,kod_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun =a.kat_akaun  left join(select m1.kat_akaun,m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1' and Susu_nilai = '1' group by m1.kat_akaun,m1.under_jenis,m1.kod_akaun) as d on d.under_jenis like '%'+a.kod_akaun+'%' Left join (select kat_akaun,kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kat_akaun,kod_akaun) as b1 on b1.kod_akaun = d.kod_akaun and b1.kat_akaun =d.kat_akaun left join (select '05.02' as kod_akaun,(ISNULL(a.val1,'0.00') - ISNULL(b.val1,'0.00')) as kt from (select '01' as vv1,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1 from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1') as a Left join(select kod_akaun,kat_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,kat_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' and a2.kat_akaun=a.kat_akaun Left join(select kod_akaun,kat_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as b1 on b1.kod_akaun like '%'+a.kod_akaun+'%' and b1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun ) as a left join (select '01' as vv1,(SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) * 2) as val1 from (select * from KW_Ref_Carta_Akaun where kkk_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt,kat_akaun from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' and a2.kat_akaun=a.kat_akaun Left join(select kod_akaun,sum(ISNULL(opening_amt,'0.00')) as opening_amt,kat_akaun from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as b1 on b1.kod_akaun like '%'+a.kod_akaun+'%' and b1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun,kat_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' and b2.kat_akaun=a.kat_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' ) as b on b.vv1=a.vv1) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun order by r1.bal_type,r1.kat_cd,a.kod_akaun asc";
                sqry = "select s1.kod_akaun as a11,s1.kod_akaun +' | ' +s1.nama_akaun as a1,'KEUNTUNGAN (KERUGIAN) BERSIH' as a2,ISNULL((b.val1 -a.val1), '0.00') as a3 from (select r1.bal_type as baltype,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,sum(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and jenis_akaun_type='" + akaun_level.SelectedValue + "' and kkk_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' group by r1.bal_type) as a left join(select r1.bal_type as baltype,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,sum(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and kkk_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='K' group by r1.bal_type) as b on b.baltype!=a.baltype left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun='05.02.01'";
            }

            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            dt = DBCon.Ora_Execute_table(qry1);
            Rptviwerlejar.Reset();
            ds.Tables.Add(dt);



            List<DataRow> listResult = dt.AsEnumerable().ToList();
            listResult.Count();
            int countRow = 0;
            countRow = listResult.Count();

            Rptviwerlejar.LocalReport.DataSources.Clear();
            if (countRow != 0)
            {
                DataTable sel_gst1 = new DataTable();
                sel_gst1 = DBCon.Ora_Execute_table(sqry);

                if (sel_gst1.Rows.Count != 0)
                {
                    val6 = double.Parse(sel_gst1.Rows[0]["a3"].ToString()).ToString("C").Replace("RM", "").Replace("$", "");
                }
                else
                {
                    val6 = "0.00";
                }

           

                Rptviwerlejar.LocalReport.ReportPath = "Kewengan/KW_Kunci_kira.rdlc";
                ReportDataSource rds = new ReportDataSource("kwkunci", dt);
                ReportParameter[] rptParams = new ReportParameter[]{
                     new ReportParameter("d1", Convert.ToString(curr_yr)),
                     new ReportParameter("d2", Convert.ToString(( Int32.Parse(curr_yr) - 1))),
                     new ReportParameter("d3", val2),
                     new ReportParameter("d4", val3),
                     new ReportParameter("d5", val6),
                     new ReportParameter("d6", tmdate1),
                          };

                Rptviwerlejar.LocalReport.SetParameters(rptParams);
                Rptviwerlejar.LocalReport.DataSources.Add(rds);
                Rptviwerlejar.LocalReport.Refresh();
                System.Threading.Thread.Sleep(1);                
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod tidak dijumpai. Sila Pastikan Semua Maklumat Dimasukkan Dengan Betul.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukan Input Carian.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
        }
    }


    protected void btn_reset(object sender, EventArgs e)
    {
        Response.Redirect("../kewengan/kw_lep_kunci_kira.aspx");
    }


}