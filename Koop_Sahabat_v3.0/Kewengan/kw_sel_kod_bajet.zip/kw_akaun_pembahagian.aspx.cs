﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;

public partial class kw_akaun_pembahagian : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();
    decimal total = 0, total1 = 0;
    string level, userid;
    string Status = string.Empty;
    string qry1 = string.Empty, qry2 = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        app_language();
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.Button4);
        string script = " $(function () {$('.select2').select2()});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {
                userid = Session["New"].ToString();
                ver_id.Text = "0";
                BindDropdown();
                BindData();

                FirstGridViewRow();
                FirstGridViewRow1();
                FirstGridViewRow2();
                FirstGridViewRow3();
                Button2.Attributes.Add("style", "pointer-events:None; opacity: 0.5;");
                Button1.Attributes.Add("style", "pointer-events:None; opacity: 0.5;");
                Button4.Attributes.Remove("style");
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
    }
    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('1723','705','1724','827','65','1725','1726','1728','1729','121','754','755','14','15')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[13][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[7][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[13][0].ToString().ToLower());
            ps_lbl4.Text = txtinfo.ToTitleCase(gt_lng.Rows[8][0].ToString().ToLower());
            ps_lbl5.Text = txtinfo.ToTitleCase(gt_lng.Rows[6][0].ToString().ToLower());
            ps_lbl6.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
            Button5.Text = txtinfo.ToTitleCase(gt_lng.Rows[2][0].ToString().ToLower());       
            Button3.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());
            ps_lbl9.Text = txtinfo.ToTitleCase(gt_lng.Rows[12][0].ToString().ToLower());
            ps_lbl10.Text = txtinfo.ToTitleCase(gt_lng.Rows[9][0].ToString().ToLower());
            ps_lbl11.Text = txtinfo.ToTitleCase(gt_lng.Rows[10][0].ToString().ToLower());
            ps_lbl12.Text = txtinfo.ToTitleCase(gt_lng.Rows[11][0].ToString().ToLower());
            Button2.Text = txtinfo.ToTitleCase(gt_lng.Rows[3][0].ToString().ToLower());
            Button4.Text = txtinfo.ToTitleCase(gt_lng.Rows[4][0].ToString().ToLower());
            Button1.Text = txtinfo.ToTitleCase(gt_lng.Rows[5][0].ToString().ToLower());
           

        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }
    void BindDropdown()
    {
        DateTimeFormatInfo info = DateTimeFormatInfo.GetInstance(null);

        int year = DateTime.Now.Year - 5;

        for (int Y = year; Y <= DateTime.Now.Year; Y++)
        {

            Tahun_kew.Items.Add(new ListItem(Y.ToString(), Y.ToString()));

        }

        Tahun_kew.SelectedValue = DateTime.Now.Year.ToString();

    }
    protected void BindData()
    {

        string sqry = string.Empty;
        string fmdate = string.Empty, tmdate = string.Empty;
        int curr_yr = Int32.Parse(Tahun_kew.SelectedValue);
        if (Tk_akhir.Text != "")
        {
            fmdate = curr_yr + "-01-01";
            string tdate = Tk_akhir.Text;
            DateTime td = DateTime.ParseExact(tdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            tmdate = td.ToString("yyyy-MM-dd");
        }

        if (Tk_akhir.Text != "")
        {
            sqry = "select ISNULL(s1.kod_akaun,'') as a11,case when ISNULL(s1.kod_akaun,'') != '' then ISNULL(s1.kod_akaun,'') +' | ' +ISNULL(s1.nama_akaun,'') else '' end as a1,'KEUNTUNGAN (KERUGIAN) BERSIH' as a2,(ISNULL(b.val1,'0.00') -ISNULL(a.val1,'0.00')) as a3 from (select r1.bal_type as baltype,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,sum(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + curr_yr + "') as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' group by r1.bal_type) as a left join(select r1.bal_type as baltype,sum(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,sum(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + curr_yr + "') as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='K' group by r1.bal_type) as b on b.baltype!=a.baltype left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun='05.02.01'";
        }
        else
        {
            sqry = "select ISNULL(s1.kod_akaun,'') as a11,case when ISNULL(s1.kod_akaun,'') != '' then ISNULL(s1.kod_akaun,'') +' | ' +ISNULL(s1.nama_akaun,'') else '' end as a1,'KEUNTUNGAN (KERUGIAN) BERSIH' as a2,(ISNULL(b.val1,'0.00') -ISNULL(a.val1,'0.00')) as a3 from (select r1.bal_type as baltype,SUM(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,SUM(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + curr_yr + "') as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' group by r1.bal_type) as a left join(select r1.bal_type as baltype,SUM(cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') as money)) val1,SUM(cast(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money)) as val2,SUM(cast(replace((ISNULL(a1.opening_amt,'0.00') - ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))),'-','') as money)) as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + curr_yr + "') as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') group by kod_akaun) as c on c.kod_akaun=a.kod_akaun inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='K' group by r1.bal_type) as b on b.baltype!=a.baltype left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun='05.02.01'";
        }

        DataTable dd_hrsal = new DataTable();
        dd_hrsal = DBCon.Ora_Execute_table(sqry);
        if (dd_hrsal.Rows.Count != 0)
        {
            TextBox1.Text = double.Parse(dd_hrsal.Rows[0]["a3"].ToString()).ToString("C").Replace("RM", "").Replace("$", "");
        }
        else
        {
            TextBox1.Text = "0.00";
        }
        con.Open();
        DataTable ddicno = new DataTable();
        SqlCommand cmd = new SqlCommand(sqry, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count == 0)
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gv_refdata.DataSource = ds;
            gv_refdata.DataBind();
            int columncount = gv_refdata.Rows[0].Cells.Count;
            gv_refdata.Rows[0].Cells.Clear();
            gv_refdata.Rows[0].Cells.Add(new TableCell());
            gv_refdata.Rows[0].Cells[0].ColumnSpan = columncount;
            gv_refdata.Rows[0].Cells[0].Text = "<center>Maklumat Carian Tidak Dijumpai</center>";

        }
        else
        {
            gv_refdata.DataSource = ds;
            gv_refdata.DataBind();
        }

        con.Close();
        //FirstGridViewRow();
        //FirstGridViewRow1();
        //FirstGridViewRow2();
        //FirstGridViewRow3();
    }


    protected void clk_cerian(object sender, EventArgs e)
    {
        //if (Tk_akhir.Text != "")
        //{
            BindData();
        //}
        //else
        //{
        //    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukan Input Carian.',{'type': 'warning','title': 'Warning','auto_close': 2000});", true);
        //}
    }

    //1st grid

    protected void QtyChanged(object sender, EventArgs eventArgs)
    {
        decimal numTotal = 0;
        decimal unit1 = 0;
        GridViewRow row = ((GridViewRow)((TextBox)sender).NamingContainer);
        TextBox per = (TextBox)row.FindControl("Col3");
        TextBox amt1 = (TextBox)row.FindControl("Col4");
        TextBox tot1 = (TextBox)row.FindControl("Col5");
        //Label jum1 = (Label)grvStudentDetails.FooterRow.FindControl("lblTotal2");
        int qty1 = Convert.ToInt32(per.Text);
        if (amt1.Text != "")
        {
            unit1 = Convert.ToDecimal(amt1.Text.Replace("(","-").Replace(")", ""));
        }
        else
        {
            unit1 = 0;
        }

        if (qty1.ToString() != "")
        {
            if (amt1.Text != "")
            {
                numTotal = (qty1 * unit1) / 100;
                if (unit1 > 0)
                {
                    tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                }
                else
                {
                    tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                }
            }
        }
        amt1.Focus();
        GrandTotal();
        tab1();
    }

    protected void QtyChanged1(object sender, EventArgs eventArgs)
    {
        decimal numTotal = 0;
        decimal unit1 = 0;
        GridViewRow row = ((GridViewRow)((TextBox)sender).NamingContainer);
        TextBox per = (TextBox)row.FindControl("Col3");
        TextBox amt1 = (TextBox)row.FindControl("Col4");
        TextBox tot1 = (TextBox)row.FindControl("Col5");
        if (per.Text != "")
        {
            int qty1 = Convert.ToInt32(per.Text);
            if (amt1.Text != "")
            {
                unit1 = Convert.ToDecimal(amt1.Text.Replace("(","-").Replace(")", ""));
            }
            else
            {
                unit1 = 0;
            }

            if (qty1.ToString() != "")
            {
                if (amt1.Text != "")
                {
                    numTotal = (qty1 * unit1) / 100;
                    if (unit1 > 0)
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                    }
                    else
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                    }
                }
            }
        }
        tab1();
        GrandTotal();
    }

    private void GrandTotal()
    {
        decimal GTotal = 0;
        decimal GTotal1 = 0;
        decimal ITotal = 0;
        decimal Gst = 0;
        for (int i = 0; i < grvStudentDetails.Rows.Count; i++)
        {
            String total = (grvStudentDetails.Rows[i].FindControl("col5") as TextBox).Text;

            TextBox jumI = (TextBox)grvStudentDetails.FooterRow.FindControl("lblTotal2");
            if (total != "")
            {
                GTotal1 = (decimal)Convert.ToDecimal(total);
            }
            else
            {
                GTotal1 = 0;
            }
            GTotal += (decimal)Convert.ToDecimal(GTotal1);

            jumI.Text = GTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");

        }

    }

    private void FirstGridViewRow()
    {
        DataTable dt = new DataTable();
        DataRow dr = null;
        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Col1", typeof(string)));
        dt.Columns.Add(new DataColumn("Col2", typeof(string)));
        dt.Columns.Add(new DataColumn("Col3", typeof(string)));
        dt.Columns.Add(new DataColumn("Col4", typeof(string)));
        dt.Columns.Add(new DataColumn("Col5", typeof(string)));
        dr = dt.NewRow();
        //dr["RowNumber"] = 1;
        dr["Col1"] = string.Empty;
        dr["Col2"] = string.Empty;
        dr["Col3"] = string.Empty;
        dr["Col4"] = string.Empty;
        dr["Col5"] = string.Empty;
        dt.Rows.Add(dr);

        ViewState["CurrentTable"] = dt;

        grvStudentDetails.DataSource = dt;
        grvStudentDetails.DataBind();
        grvStudentDetails.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
        grvStudentDetails.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        AddNewRow();
        tab1();
    }

    void tab1()
    {
        p1.Attributes.Add("class", "tab-pane");
        p2.Attributes.Add("class", "tab-pane");
        p6.Attributes.Add("class", "tab-pane active");
        p3.Attributes.Add("class", "tab-pane");

        pp3.Attributes.Remove("class");
        pp1.Attributes.Remove("class");
        pp2.Attributes.Remove("class");
        pp6.Attributes.Add("class", "active");
        BindData();

    }

    private void AddNewRow()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            //if (dtCurrentTable.Rows.Count < 2)
            //{
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList v1 =
                      (DropDownList)grvStudentDetails.Rows[rowIndex].Cells[1].FindControl("Col1");
                    TextBox v2 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[2].FindControl("Col2");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[3].FindControl("Col3");
                    TextBox v3 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[4].FindControl("Col4");
                    TextBox v4 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[5].FindControl("Col5");
                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["RowNumber"] = i + 1;

                    dtCurrentTable.Rows[i - 1]["Col1"] = v1.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["Col2"] = v2.Text;
                    dtCurrentTable.Rows[i - 1]["Col3"] = v2_1.Text;
                    dtCurrentTable.Rows[i - 1]["Col4"] = v3.Text;
                    dtCurrentTable.Rows[i - 1]["Col5"] = v4.Text;
                    rowIndex++;
                    //if (v3.Text != "")
                    //{
                    //    decimal amt1 = Convert.ToDecimal(v3.Text);
                    //    total += (double)amt1;
                    //}
                    //if (v4.Text != "")
                    //{
                    //    decimal amt2 = Convert.ToDecimal(v4.Text);
                    //    total1 += (double)amt2;
                    //}
                }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable"] = dtCurrentTable;

                grvStudentDetails.DataSource = dtCurrentTable;
                grvStudentDetails.DataBind();

                grvStudentDetails.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
                grvStudentDetails.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                ((TextBox)grvStudentDetails.FooterRow.Cells[4].FindControl("lblTotal2")).Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");

            }
            //}
        }
        else
        {
            Response.Write("ViewState is null");
        }
        SetPreviousData();
    }



    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownList v1 =
                          (DropDownList)grvStudentDetails.Rows[rowIndex].Cells[1].FindControl("Col1");
                    TextBox v2 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[2].FindControl("Col2");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[3].FindControl("Col3");
                    TextBox v3 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[4].FindControl("Col4");
                    TextBox v4 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[5].FindControl("Col5");

                    v1.SelectedValue = dt.Rows[i]["Col1"].ToString();
                    v2.Text = dt.Rows[i]["Col2"].ToString();
                    v2_1.Text = dt.Rows[i]["Col3"].ToString();
                    v3.Text = dt.Rows[i]["Col4"].ToString();
                    v4.Text = dt.Rows[i]["Col5"].ToString();
                    rowIndex++;
                    if (v3.Text != "")
                    {
                        decimal amt1 = Convert.ToDecimal(v3.Text.Replace("(", "").Replace(")", ""));
                        total += amt1;
                    }
                    if (v4.Text != "")
                    {
                        decimal amt2 = Convert.ToDecimal(v4.Text);
                        total1 += amt2;
                    }
                }
            }
        }
    }

    protected void grvStudentDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        SetRowData();
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            int rowIndex = Convert.ToInt32(e.RowIndex);
            if (dt.Rows.Count > 1)
            {
                dt.Rows.Remove(dt.Rows[rowIndex]);
                drCurrentRow = dt.NewRow();
                ViewState["CurrentTable"] = dt;
                grvStudentDetails.DataSource = dt;
                grvStudentDetails.DataBind();

                for (int i = 0; i < grvStudentDetails.Rows.Count - 1; i++)
                {
                    grvStudentDetails.Rows[i].Cells[0].Text = Convert.ToString(i + 1);
                }
                SetPreviousData();
                grvStudentDetails.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
                grvStudentDetails.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                //((TextBox)grvStudentDetails.FooterRow.Cells[3].FindControl("lblTotal1")).Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                ((TextBox)grvStudentDetails.FooterRow.Cells[4].FindControl("lblTotal2")).Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
            }
        }
    }

    private void SetRowData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList v1 =
                         (DropDownList)grvStudentDetails.Rows[rowIndex].Cells[1].FindControl("Col1");
                    TextBox v2 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[2].FindControl("Col2");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[3].FindControl("Col3");
                    TextBox v3 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[4].FindControl("Col4");
                    TextBox v4 =
                      (TextBox)grvStudentDetails.Rows[rowIndex].Cells[5].FindControl("Col5");
                    drCurrentRow["RowNumber"] = i + 1;
                    dtCurrentTable.Rows[i - 1]["Col1"] = v1.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["Col2"] = v2.Text;
                    dtCurrentTable.Rows[i - 1]["Col3"] = v2_1.Text;
                    dtCurrentTable.Rows[i - 1]["Col4"] = v3.Text;
                    dtCurrentTable.Rows[i - 1]["Col5"] = v4.Text;
                    rowIndex++;

                }

                ViewState["CurrentTable"] = dtCurrentTable;
                //grvStudentDetails.DataSource = dtCurrentTable;
                //grvStudentDetails.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }
        //SetPreviousData();
    }

    protected void gvEmp_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            var ddl = (DropDownList)e.Row.FindControl("Col1");
            //int CountryId = Convert.ToInt32(e.Row.Cells[0].Text);
            SqlCommand cmd = new SqlCommand("select kod_akaun,(kod_akaun + ' | ' + UPPER(nama_akaun)) as name from KW_Ref_Carta_Akaun where jenis_akaun_type !='1' and Status='A' order by kod_akaun asc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "name";
            ddl.DataValueField = "kod_akaun";
            ddl.DataBind();
            ddl.SelectedValue = ((DataRowView)e.Row.DataItem)["Col1"].ToString();
            ddl.Items.Insert(0, new ListItem("--- PILIH ---", ""));



            System.Web.UI.WebControls.TextBox txt3 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("Col4");
            System.Web.UI.WebControls.TextBox txt1 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("Col5");
            if (TextBox1.Text != "")
            {
                txt3.Text = double.Parse(TextBox1.Text.Replace("(","-").Replace(")","")).ToString("C").Replace("RM", "").Replace("$", "");
            }
            else
            {
                txt3.Text = "0.00";
            }
            decimal sval1 = 0, sval2 = 0;


            if (txt1.Text == "")
            {
                sval2 = 0;
            }
            else
            {
                sval2 = Convert.ToDecimal(txt1.Text);
            }

            total1 += sval2;
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            //System.Web.UI.WebControls.TextBox lblamount1 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("lblTotal1");
            System.Web.UI.WebControls.TextBox lblamount2 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("lblTotal2");
            //lblamount1.Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
            lblamount2.Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
        }
    }

    //1st grid end
    //2nd grid

    protected void QtyChanged2(object sender, EventArgs eventArgs)
    {
        decimal numTotal = 0;
        decimal unit1 = 0;
        GridViewRow row = ((GridViewRow)((TextBox)sender).NamingContainer);
        TextBox per = (TextBox)row.FindControl("Col31");
        TextBox amt1 = (TextBox)row.FindControl("Col41");
        TextBox tot1 = (TextBox)row.FindControl("Col51");
        //Label jum1 = (Label)grvStudentDetails.FooterRow.FindControl("lblTotal2");
        int qty1 = Convert.ToInt32(per.Text);
        if (amt1.Text != "")
        {
            unit1 = Convert.ToDecimal(amt1.Text.Replace("(", "-").Replace(")", ""));
        }
        else
        {
            unit1 = 0;
        }

        if (qty1.ToString() != "")
        {
            
            if (amt1.Text != "")
            {
                numTotal = (qty1 * unit1) / 100;
                if (unit1 > 0)
                {
                    tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                }
                else
                {
                    tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                }
            }
        }
        amt1.Focus();
        GrandTotal1();
        tab2();
    }

    protected void QtyChanged21(object sender, EventArgs eventArgs)
    {
        decimal numTotal = 0;
        decimal unit1 = 0;
        GridViewRow row = ((GridViewRow)((TextBox)sender).NamingContainer);
        TextBox per = (TextBox)row.FindControl("Col31");
        TextBox amt1 = (TextBox)row.FindControl("Col41");
        TextBox tot1 = (TextBox)row.FindControl("Col51");
        if (per.Text != "")
        {
            int qty1 = Convert.ToInt32(per.Text);
            if (amt1.Text != "")
            {
                unit1 = Convert.ToDecimal(amt1.Text.Replace("(", "-").Replace(")", ""));
            }
            else
            {
                unit1 = 0;
            }

            if (qty1.ToString() != "")
            {
                if (amt1.Text != "")
                {
                    numTotal = (qty1 * unit1) / 100;
                    if (unit1 > 0)
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                    }
                    else
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                    }
                }
            }
            amt1.Focus();
            tab2();
            GrandTotal1();
        }
    }

    private void GrandTotal1()
    {
        decimal GTotal = 0;
        decimal GTotal1 = 0;
        decimal ITotal = 0;
        decimal Gst = 0;
        for (int i = 0; i < grvStudentDetails1.Rows.Count; i++)
        {
            String total = (grvStudentDetails1.Rows[i].FindControl("col51") as TextBox).Text;

            TextBox jumI = (TextBox)grvStudentDetails1.FooterRow.FindControl("lblTotal21");
            if (total != "")
            {
                GTotal1 = (decimal)Convert.ToDecimal(total);
            }
            else
            {
                GTotal1 = 0;
            }
            GTotal += (decimal)Convert.ToDecimal(GTotal1);

            jumI.Text = GTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");

        }

    }

    private void FirstGridViewRow1()
    {
        DataTable dt = new DataTable();
        DataRow dr = null;
        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Col1", typeof(string)));
        dt.Columns.Add(new DataColumn("Col2", typeof(string)));
        dt.Columns.Add(new DataColumn("Col3", typeof(string)));
        dt.Columns.Add(new DataColumn("Col4", typeof(string)));
        dt.Columns.Add(new DataColumn("Col5", typeof(string)));
        dr = dt.NewRow();
        //dr["RowNumber"] = 1;
        dr["Col1"] = string.Empty;
        dr["Col2"] = string.Empty;
        dr["Col3"] = string.Empty;
        dr["Col4"] = string.Empty;
        dr["Col5"] = string.Empty;
        dt.Rows.Add(dr);

        ViewState["CurrentTable1"] = dt;

        grvStudentDetails1.DataSource = dt;
        grvStudentDetails1.DataBind();
        grvStudentDetails1.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
        grvStudentDetails1.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
    }

    protected void ButtonAdd_Click1(object sender, EventArgs e)
    {
        AddNewRow1();
        tab2();

    }

    void tab2()
    {
        p2.Attributes.Add("class", "tab-pane");
        p6.Attributes.Add("class", "tab-pane");
        p1.Attributes.Add("class", "tab-pane active");
        p3.Attributes.Add("class", "tab-pane");

        pp3.Attributes.Remove("class");
        pp2.Attributes.Remove("class");
        pp6.Attributes.Remove("class");
        pp1.Attributes.Add("class", "active");
        BindData();
    }

    private void AddNewRow1()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable1"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable1"];
            DataRow drCurrentRow = null;
            //if (dtCurrentTable.Rows.Count < 2)
            //{
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList v1 =
                      (DropDownList)grvStudentDetails1.Rows[rowIndex].Cells[1].FindControl("Col11");
                    TextBox v2 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[2].FindControl("Col21");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[3].FindControl("Col31");
                    TextBox v3 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[4].FindControl("Col41");
                    TextBox v4 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[5].FindControl("Col51");
                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["RowNumber"] = i + 1;

                    dtCurrentTable.Rows[i - 1]["Col1"] = v1.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["Col2"] = v2.Text;
                    dtCurrentTable.Rows[i - 1]["Col3"] = v2_1.Text;
                    dtCurrentTable.Rows[i - 1]["Col4"] = v3.Text;
                    dtCurrentTable.Rows[i - 1]["Col5"] = v4.Text;
                    rowIndex++;
                    //if (v3.Text != "")
                    //{
                    //    decimal amt1 = Convert.ToDecimal(v3.Text);
                    //    total += (float)amt1;
                    //}
                    //if (v4.Text != "")
                    //{
                    //    decimal amt2 = Convert.ToDecimal(v4.Text);
                    //    total1 += (float)amt2;
                    //}
                }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable1"] = dtCurrentTable;

                grvStudentDetails1.DataSource = dtCurrentTable;
                grvStudentDetails1.DataBind();
                grvStudentDetails1.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
                grvStudentDetails1.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                //((TextBox)grvStudentDetails.FooterRow.Cells[3].FindControl("lblTotal1")).Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                ((TextBox)grvStudentDetails1.FooterRow.Cells[4].FindControl("lblTotal21")).Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");

            }
            //}
        }
        else
        {
            Response.Write("ViewState is null");
        }
        SetPreviousData1();
    }



    private void SetPreviousData1()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable1"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable1"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownList v1 =
                          (DropDownList)grvStudentDetails1.Rows[rowIndex].Cells[1].FindControl("Col11");
                    TextBox v2 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[2].FindControl("Col21");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[3].FindControl("Col31");
                    TextBox v3 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[4].FindControl("Col41");
                    TextBox v4 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[5].FindControl("Col51");

                    v1.SelectedValue = dt.Rows[i]["Col1"].ToString();
                    v2.Text = dt.Rows[i]["Col2"].ToString();
                    v2_1.Text = dt.Rows[i]["Col3"].ToString();
                    v3.Text = dt.Rows[i]["Col4"].ToString();
                    v4.Text = dt.Rows[i]["Col5"].ToString();
                    rowIndex++;
                    if (v3.Text != "")
                    {
                        decimal amt1 = Convert.ToDecimal(v3.Text.Replace("(", "").Replace(")", ""));
                        total += amt1;
                    }
                    if (v4.Text != "")
                    {
                        decimal amt2 = Convert.ToDecimal(v4.Text);
                        total1 += amt2;
                    }

                }
            }
        }
    }

    protected void grvStudentDetails_RowDeleting1(object sender, GridViewDeleteEventArgs e)
    {
        SetRowData1();
        if (ViewState["CurrentTable1"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable1"];
            DataRow drCurrentRow = null;
            int rowIndex = Convert.ToInt32(e.RowIndex);
            if (dt.Rows.Count > 1)
            {
                dt.Rows.Remove(dt.Rows[rowIndex]);
                drCurrentRow = dt.NewRow();
                ViewState["CurrentTable1"] = dt;
                grvStudentDetails1.DataSource = dt;
                grvStudentDetails1.DataBind();

                for (int i = 0; i < grvStudentDetails1.Rows.Count - 1; i++)
                {
                    grvStudentDetails1.Rows[i].Cells[0].Text = Convert.ToString(i + 1);
                }
                SetPreviousData1();
                grvStudentDetails1.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
                grvStudentDetails1.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                //((TextBox)grvStudentDetails.FooterRow.Cells[3].FindControl("lblTotal1")).Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                ((TextBox)grvStudentDetails1.FooterRow.Cells[4].FindControl("lblTotal21")).Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
            }
        }
    }

    private void SetRowData1()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable1"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable1"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList v1 =
                         (DropDownList)grvStudentDetails1.Rows[rowIndex].Cells[1].FindControl("Col11");
                    TextBox v2 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[2].FindControl("Col21");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[3].FindControl("Col31");
                    TextBox v3 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[4].FindControl("Col41");
                    TextBox v4 =
                      (TextBox)grvStudentDetails1.Rows[rowIndex].Cells[5].FindControl("Col51");
                    drCurrentRow["RowNumber"] = i + 1;
                    dtCurrentTable.Rows[i - 1]["Col1"] = v1.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["Col2"] = v2.Text;
                    dtCurrentTable.Rows[i - 1]["Col3"] = v2_1.Text;
                    dtCurrentTable.Rows[i - 1]["Col4"] = v3.Text;
                    dtCurrentTable.Rows[i - 1]["Col5"] = v4.Text;
                    rowIndex++;

                }

                ViewState["CurrentTable1"] = dtCurrentTable;
                //grvStudentDetails.DataSource = dtCurrentTable;
                //grvStudentDetails.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }
        //SetPreviousData();
    }

    protected void gvEmp_RowDataBound1(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            var ddl = (DropDownList)e.Row.FindControl("Col11");
            //int CountryId = Convert.ToInt32(e.Row.Cells[0].Text);
            SqlCommand cmd = new SqlCommand("select kod_akaun,(kod_akaun + ' | ' + UPPER(nama_akaun)) as name from KW_Ref_Carta_Akaun where jenis_akaun_type !='1' and Status='A' order by kod_akaun asc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "name";
            ddl.DataValueField = "kod_akaun";
            ddl.DataBind();
            ddl.SelectedValue = ((DataRowView)e.Row.DataItem)["Col1"].ToString();
            ddl.Items.Insert(0, new ListItem("--- PILIH ---", ""));




            System.Web.UI.WebControls.TextBox txt1 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("Col51");
            decimal sval1 = 0;
            decimal sval2 = 0;


            if (txt1.Text == "")
            {
                sval2 = Convert.ToDecimal(0);
            }
            else
            {
                sval2 = Convert.ToDecimal(txt1.Text);
            }


            total1 += sval2;
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            //System.Web.UI.WebControls.TextBox lblamount1 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("lblTotal1");
            System.Web.UI.WebControls.TextBox lblamount2 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("lblTotal21");
            //lblamount1.Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
            lblamount2.Text = total1.ToString("C").Replace("RM", "").Replace("$", "").Replace("RM", "").Replace("$", "");
        }
    }

    //2nd grid end

    //3rd grid start

    protected void QtyChanged3(object sender, EventArgs eventArgs)
    {
        decimal numTotal = 0;
        decimal unit1 = 0;
        GridViewRow row = ((GridViewRow)((TextBox)sender).NamingContainer);
        TextBox per = (TextBox)row.FindControl("Col311");
        TextBox amt1 = (TextBox)row.FindControl("Col411");
        TextBox tot1 = (TextBox)row.FindControl("Col511");
        //Label jum1 = (Label)grvStudentDetails.FooterRow.FindControl("lblTotal2");
        if (per.Text != "")
        {
            int qty1 = Convert.ToInt32(per.Text);
            if (amt1.Text != "")
            {
                unit1 = Convert.ToDecimal(amt1.Text.Replace("(", "-").Replace(")", ""));
            }
            else
            {
                unit1 = 0;
            }

            if (qty1.ToString() != "")
            {
                if (amt1.Text != "")
                {
                    numTotal = (qty1 * unit1) / 100;
                    if (unit1 > 0)
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                    }
                    else
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                    }
                }
            }
            amt1.Focus();
        }
        GrandTotal2();
        tab3();
    }

    protected void QtyChanged31(object sender, EventArgs eventArgs)
    {
        decimal numTotal = 0;
        decimal unit1 = 0;
        GridViewRow row = ((GridViewRow)((TextBox)sender).NamingContainer);
        TextBox per = (TextBox)row.FindControl("Col311");
        TextBox amt1 = (TextBox)row.FindControl("Col411");
        TextBox tot1 = (TextBox)row.FindControl("Col511");
        if (per.Text != "")
        {
            int qty1 = Convert.ToInt32(per.Text);
            if (amt1.Text != "")
            {
                unit1 = Convert.ToDecimal(amt1.Text.Replace("(", "-").Replace(")", ""));
            }
            else
            {
                unit1 = 0;
            }

            if (qty1.ToString() != "")
            {
                if (amt1.Text != "")
                {
                    numTotal = (qty1 * unit1) / 100;
                    if (unit1 > 0)
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("$", "");
                    }
                    else
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("$", "");
                    }
                }
            }
            amt1.Focus();
        }
        tab3();
        GrandTotal2();
    }

    private void GrandTotal2()
    {
        decimal GTotal = 0;
        decimal GTotal1 = 0;
        decimal ITotal = 0;
        decimal Gst = 0;
        for (int i = 0; i < grvStudentDetails2.Rows.Count; i++)
        {
            String total = (grvStudentDetails2.Rows[i].FindControl("col511") as TextBox).Text;

            TextBox jumI = (TextBox)grvStudentDetails2.FooterRow.FindControl("lblTotal211");
            if (total != "")
            {
                GTotal1 = (decimal)Convert.ToDecimal(total);
            }
            else
            {
                GTotal1 = 0;
            }
            GTotal += (decimal)Convert.ToDecimal(GTotal1);

            jumI.Text = GTotal.ToString("C").Replace("RM", "").Replace("$", "");

        }

    }

    private void FirstGridViewRow2()
    {
        DataTable dt = new DataTable();
        DataRow dr = null;
        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Col1", typeof(string)));
        dt.Columns.Add(new DataColumn("Col2", typeof(string)));
        dt.Columns.Add(new DataColumn("Col3", typeof(string)));
        dt.Columns.Add(new DataColumn("Col4", typeof(string)));
        dt.Columns.Add(new DataColumn("Col5", typeof(string)));
        dr = dt.NewRow();
        //dr["RowNumber"] = 1;
        dr["Col1"] = string.Empty;
        dr["Col2"] = string.Empty;
        dr["Col3"] = string.Empty;
        dr["Col4"] = string.Empty;
        dr["Col5"] = string.Empty;
        dt.Rows.Add(dr);

        ViewState["CurrentTable2"] = dt;

        grvStudentDetails2.DataSource = dt;
        grvStudentDetails2.DataBind();
        grvStudentDetails2.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
        grvStudentDetails2.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
    }

    protected void ButtonAdd_Click2(object sender, EventArgs e)
    {
        AddNewRow2();
        tab3();
    }

    void tab3()
    {
        p1.Attributes.Add("class", "tab-pane");
        p6.Attributes.Add("class", "tab-pane");
        p2.Attributes.Add("class", "tab-pane active");
        p3.Attributes.Add("class", "tab-pane");

        pp3.Attributes.Remove("class");
        pp1.Attributes.Remove("class");
        pp6.Attributes.Remove("class");
        pp2.Attributes.Add("class", "active");
        BindData();
    }

    private void AddNewRow2()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable2"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable2"];
            DataRow drCurrentRow = null;
            //if (dtCurrentTable.Rows.Count < 2)
            //{
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList v1 =
                      (DropDownList)grvStudentDetails2.Rows[rowIndex].Cells[1].FindControl("Col111");
                    TextBox v2 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[2].FindControl("Col211");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[3].FindControl("Col311");
                    TextBox v3 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[4].FindControl("Col411");
                    TextBox v4 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[5].FindControl("Col511");
                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["RowNumber"] = i + 1;

                    dtCurrentTable.Rows[i - 1]["Col1"] = v1.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["Col2"] = v2.Text;
                    dtCurrentTable.Rows[i - 1]["Col3"] = v2_1.Text;
                    dtCurrentTable.Rows[i - 1]["Col4"] = v3.Text;
                    dtCurrentTable.Rows[i - 1]["Col5"] = v4.Text;
                    rowIndex++;
                    //if (v3.Text != "")
                    //{
                    //    decimal amt1 = Convert.ToDecimal(v3.Text);
                    //    total += (float)amt1;
                    //}
                    //if (v4.Text != "")
                    //{
                    //    decimal amt2 = Convert.ToDecimal(v4.Text);
                    //    total1 += (float)amt2;
                    //}
                }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable2"] = dtCurrentTable;

                grvStudentDetails2.DataSource = dtCurrentTable;
                grvStudentDetails2.DataBind();
                grvStudentDetails2.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
                grvStudentDetails2.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                //((TextBox)grvStudentDetails.FooterRow.Cells[3].FindControl("lblTotal1")).Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                ((TextBox)grvStudentDetails2.FooterRow.Cells[4].FindControl("lblTotal211")).Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");

            }
            //}
        }
        else
        {
            Response.Write("ViewState is null");
        }
        SetPreviousData2();
    }



    private void SetPreviousData2()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable2"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable2"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownList v1 =
                          (DropDownList)grvStudentDetails2.Rows[rowIndex].Cells[1].FindControl("Col111");
                    TextBox v2 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[2].FindControl("Col211");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[3].FindControl("Col311");
                    TextBox v3 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[4].FindControl("Col411");
                    TextBox v4 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[5].FindControl("Col511");

                    v1.SelectedValue = dt.Rows[i]["Col1"].ToString();
                    v2.Text = dt.Rows[i]["Col2"].ToString();
                    v2_1.Text = dt.Rows[i]["Col3"].ToString();
                    v3.Text = dt.Rows[i]["Col4"].ToString();
                    v4.Text = dt.Rows[i]["Col5"].ToString();
                    rowIndex++;
                    if (v3.Text != "")
                    {
                        decimal amt1 = Convert.ToDecimal(v3.Text.Replace("(", "").Replace(")", ""));
                        total += amt1;
                    }
                    if (v4.Text != "")
                    {
                        decimal amt2 = Convert.ToDecimal(v4.Text);
                        total1 += amt2;
                    }
                }
            }
        }
    }

    protected void grvStudentDetails_RowDeleting2(object sender, GridViewDeleteEventArgs e)
    {
        SetRowData2();
        if (ViewState["CurrentTable2"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable2"];
            DataRow drCurrentRow = null;
            int rowIndex = Convert.ToInt32(e.RowIndex);
            if (dt.Rows.Count > 1)
            {
                dt.Rows.Remove(dt.Rows[rowIndex]);
                drCurrentRow = dt.NewRow();
                ViewState["CurrentTable2"] = dt;
                grvStudentDetails2.DataSource = dt;
                grvStudentDetails2.DataBind();

                for (int i = 0; i < grvStudentDetails2.Rows.Count - 1; i++)
                {
                    grvStudentDetails2.Rows[i].Cells[0].Text = Convert.ToString(i + 1);
                }
                SetPreviousData2();
                grvStudentDetails2.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
                grvStudentDetails2.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                //((TextBox)grvStudentDetails.FooterRow.Cells[3].FindControl("lblTotal1")).Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                ((TextBox)grvStudentDetails2.FooterRow.Cells[4].FindControl("lblTotal211")).Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
            }
        }
    }

    private void SetRowData2()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable2"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable2"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList v1 =
                         (DropDownList)grvStudentDetails2.Rows[rowIndex].Cells[1].FindControl("Col111");
                    TextBox v2 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[2].FindControl("Col211");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[3].FindControl("Col311");
                    TextBox v3 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[4].FindControl("Col411");
                    TextBox v4 =
                      (TextBox)grvStudentDetails2.Rows[rowIndex].Cells[5].FindControl("Col511");
                    drCurrentRow["RowNumber"] = i + 1;
                    dtCurrentTable.Rows[i - 1]["Col1"] = v1.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["Col2"] = v2.Text;
                    dtCurrentTable.Rows[i - 1]["Col3"] = v2_1.Text;
                    dtCurrentTable.Rows[i - 1]["Col4"] = v3.Text;
                    dtCurrentTable.Rows[i - 1]["Col5"] = v4.Text;
                    rowIndex++;

                }

                ViewState["CurrentTable2"] = dtCurrentTable;
                //grvStudentDetails.DataSource = dtCurrentTable;
                //grvStudentDetails.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }
        //SetPreviousData();
    }

    protected void gvEmp_RowDataBound2(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            var ddl = (DropDownList)e.Row.FindControl("Col111");
            //int CountryId = Convert.ToInt32(e.Row.Cells[0].Text);
            SqlCommand cmd = new SqlCommand("select kod_akaun,(kod_akaun + ' | ' + UPPER(nama_akaun)) as name from KW_Ref_Carta_Akaun where jenis_akaun_type !='1' and Status='A' order by kod_akaun asc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "name";
            ddl.DataValueField = "kod_akaun";
            ddl.DataBind();
            ddl.SelectedValue = ((DataRowView)e.Row.DataItem)["Col1"].ToString();
            ddl.Items.Insert(0, new ListItem("--- PILIH ---", ""));




            System.Web.UI.WebControls.TextBox txt1 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("Col511");
            decimal sval1 = 0;
            decimal sval2 = 0;


            if (txt1.Text == "")
            {
                sval2 = 0;
            }
            else
            {
                sval2 = Convert.ToDecimal(txt1.Text);
            }


            total1 += sval2;
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            //System.Web.UI.WebControls.TextBox lblamount1 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("lblTotal1");
            System.Web.UI.WebControls.TextBox lblamount2 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("lblTotal211");
            //lblamount1.Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
            lblamount2.Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
        }
    }

    //3rd grid end

    //4th grid start


    protected void QtyChanged4(object sender, EventArgs eventArgs)
    {
        decimal numTotal = 0;
        decimal unit1 = 0;
        GridViewRow row = ((GridViewRow)((TextBox)sender).NamingContainer);
        TextBox per = (TextBox)row.FindControl("Col3111");
        TextBox amt1 = (TextBox)row.FindControl("Col4111");
        TextBox tot1 = (TextBox)row.FindControl("Col5111");
        //Label jum1 = (Label)grvStudentDetails.FooterRow.FindControl("lblTotal2");
        if (per.Text != "")
        {
            int qty1 = Convert.ToInt32(per.Text);
            if (amt1.Text != "")
            {
                unit1 = Convert.ToDecimal(amt1.Text.Replace("(", "-").Replace(")", ""));
            }
            else
            {
                unit1 = 0;
            }

            if (qty1.ToString() != "")
            {
                if (amt1.Text != "")
                {
                    numTotal = (qty1 * unit1) / 100;
                    if (unit1 > 0)
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("$", "");
                    }
                    else
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("$", "");
                    }
                }
            }
            amt1.Focus();
        }
        GrandTotal4();
        tab4();
    }

    protected void QtyChanged41(object sender, EventArgs eventArgs)
    {
        decimal numTotal = 0;
        decimal unit1 = 0;
        GridViewRow row = ((GridViewRow)((TextBox)sender).NamingContainer);
        TextBox per = (TextBox)row.FindControl("Col3111");
        TextBox amt1 = (TextBox)row.FindControl("Col4111");
        TextBox tot1 = (TextBox)row.FindControl("Col5111");
        if (per.Text != "")
        {
            int qty1 = Convert.ToInt32(per.Text);
            if (amt1.Text != "")
            {
                unit1 = Convert.ToDecimal(amt1.Text.Replace("(", "-").Replace(")", ""));
            }
            else
            {
                unit1 = 0;
            }

            if (qty1.ToString() != "")
            {
                if (amt1.Text != "")
                {
                    numTotal = (qty1 * unit1) / 100;
                    if (unit1 > 0)
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("$", "");
                    }
                    else
                    {
                        tot1.Text = numTotal.ToString("C").Replace("RM", "").Replace("$", "");
                    }
                }
            }
            amt1.Focus();
        }
        tab4();
        GrandTotal4();
    }

    private void GrandTotal4()
    {
        decimal GTotal = 0;
        decimal GTotal1 = 0;
        decimal ITotal = 0;
        decimal Gst = 0;
        for (int i = 0; i < grvStudentDetails3.Rows.Count; i++)
        {
            String total = (grvStudentDetails3.Rows[i].FindControl("col5111") as TextBox).Text;

            TextBox jumI = (TextBox)grvStudentDetails3.FooterRow.FindControl("lblTotal2111");
            if (total != "")
            {
                GTotal1 = (decimal)Convert.ToDecimal(total);
            }
            else
            {
                GTotal1 = 0;
            }
            GTotal += (decimal)Convert.ToDecimal(GTotal1);

            jumI.Text = GTotal.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");

        }

    }

    private void FirstGridViewRow3()
    {
        DataTable dt = new DataTable();
        DataRow dr = null;
        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Col1", typeof(string)));
        dt.Columns.Add(new DataColumn("Col2", typeof(string)));
        dt.Columns.Add(new DataColumn("Col3", typeof(string)));
        dt.Columns.Add(new DataColumn("Col4", typeof(string)));
        dt.Columns.Add(new DataColumn("Col5", typeof(string)));
        dr = dt.NewRow();
        //dr["RowNumber"] = 1;
        dr["Col1"] = string.Empty;
        dr["Col2"] = string.Empty;
        dr["Col3"] = string.Empty;
        dr["Col4"] = string.Empty;
        dr["Col5"] = string.Empty;
        dt.Rows.Add(dr);

        ViewState["CurrentTable3"] = dt;

        grvStudentDetails3.DataSource = dt;
        grvStudentDetails3.DataBind();
        grvStudentDetails3.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
        grvStudentDetails3.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
    }

    protected void ButtonAdd_Click3(object sender, EventArgs e)
    {
        AddNewRow3();
        tab4();
    }

    void tab4()
    {
        p1.Attributes.Add("class", "tab-pane");
        p2.Attributes.Add("class", "tab-pane");
        p3.Attributes.Add("class", "tab-pane active");
        p6.Attributes.Add("class", "tab-pane");

        pp6.Attributes.Remove("class");
        pp1.Attributes.Remove("class");
        pp2.Attributes.Remove("class");
        pp3.Attributes.Add("class", "active");
        BindData();
    }

    private void AddNewRow3()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable3"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable3"];
            DataRow drCurrentRow = null;
            //if (dtCurrentTable.Rows.Count < 2)
            //{
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList v1 =
                      (DropDownList)grvStudentDetails3.Rows[rowIndex].Cells[1].FindControl("Col1111");
                    TextBox v2 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[2].FindControl("Col2111");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[3].FindControl("Col3111");
                    TextBox v3 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[4].FindControl("Col4111");
                    TextBox v4 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[5].FindControl("Col5111");
                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["RowNumber"] = i + 1;

                    dtCurrentTable.Rows[i - 1]["Col1"] = v1.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["Col2"] = v2.Text;
                    dtCurrentTable.Rows[i - 1]["Col3"] = v2_1.Text;
                    dtCurrentTable.Rows[i - 1]["Col4"] = v3.Text;
                    dtCurrentTable.Rows[i - 1]["Col5"] = v4.Text;
                    rowIndex++;
                    //if (v3.Text != "")
                    //{
                    //    decimal amt1 = Convert.ToDecimal(v3.Text);
                    //    total += (float)amt1;
                    //}
                    //if (v4.Text != "")
                    //{
                    //    decimal amt2 = Convert.ToDecimal(v4.Text);
                    //    total1 += (float)amt2;
                    //}
                }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable3"] = dtCurrentTable;

                grvStudentDetails3.DataSource = dtCurrentTable;
                grvStudentDetails3.DataBind();
                grvStudentDetails3.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
                grvStudentDetails3.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                //((TextBox)grvStudentDetails.FooterRow.Cells[3].FindControl("lblTotal1")).Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                ((TextBox)grvStudentDetails3.FooterRow.Cells[4].FindControl("lblTotal2111")).Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");

            }
            //}
        }
        else
        {
            Response.Write("ViewState is null");
        }
        SetPreviousData3();
    }



    private void SetPreviousData3()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable3"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable3"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownList v1 =
                          (DropDownList)grvStudentDetails3.Rows[rowIndex].Cells[1].FindControl("Col1111");
                    TextBox v2 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[2].FindControl("Col2111");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[3].FindControl("Col3111");
                    TextBox v3 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[4].FindControl("Col4111");
                    TextBox v4 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[5].FindControl("Col5111");

                    v1.SelectedValue = dt.Rows[i]["Col1"].ToString();
                    v2.Text = dt.Rows[i]["Col2"].ToString();
                    v2_1.Text = dt.Rows[i]["Col3"].ToString();
                    v3.Text = dt.Rows[i]["Col4"].ToString();
                    v4.Text = dt.Rows[i]["Col5"].ToString();
                    rowIndex++;
                    if (v3.Text != "")
                    {
                        decimal amt1 = Convert.ToDecimal(v3.Text.Replace("(", "").Replace(")", ""));
                        total += amt1;
                    }
                    if (v4.Text != "")
                    {
                        decimal amt2 = Convert.ToDecimal(v4.Text);
                        total1 += amt2;
                    }
                }
            }
        }
    }

    protected void grvStudentDetails_RowDeleting3(object sender, GridViewDeleteEventArgs e)
    {
        SetRowData3();
        if (ViewState["CurrentTable3"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable3"];
            DataRow drCurrentRow = null;
            int rowIndex = Convert.ToInt32(e.RowIndex);
            if (dt.Rows.Count > 1)
            {
                dt.Rows.Remove(dt.Rows[rowIndex]);
                drCurrentRow = dt.NewRow();
                ViewState["CurrentTable3"] = dt;
                grvStudentDetails3.DataSource = dt;
                grvStudentDetails3.DataBind();

                for (int i = 0; i < grvStudentDetails3.Rows.Count - 1; i++)
                {
                    grvStudentDetails3.Rows[i].Cells[0].Text = Convert.ToString(i + 1);
                }
                SetPreviousData3();
                grvStudentDetails3.FooterRow.Cells[4].Text = "JUMLAH (RM) :";
                grvStudentDetails3.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                //((TextBox)grvStudentDetails.FooterRow.Cells[3].FindControl("lblTotal1")).Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
                ((TextBox)grvStudentDetails3.FooterRow.Cells[4].FindControl("lblTotal2111")).Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
            }
        }
    }

    private void SetRowData3()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable3"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable3"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    DropDownList v1 =
                         (DropDownList)grvStudentDetails3.Rows[rowIndex].Cells[1].FindControl("Col1111");
                    TextBox v2 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[2].FindControl("Col2111");
                    TextBox v2_1 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[3].FindControl("Col3111");
                    TextBox v3 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[4].FindControl("Col4111");
                    TextBox v4 =
                      (TextBox)grvStudentDetails3.Rows[rowIndex].Cells[5].FindControl("Col5111");
                    drCurrentRow["RowNumber"] = i + 1;
                    dtCurrentTable.Rows[i - 1]["Col1"] = v1.SelectedValue;
                    dtCurrentTable.Rows[i - 1]["Col2"] = v2.Text;
                    dtCurrentTable.Rows[i - 1]["Col3"] = v2_1.Text;
                    dtCurrentTable.Rows[i - 1]["Col4"] = v3.Text;
                    dtCurrentTable.Rows[i - 1]["Col5"] = v4.Text;
                    rowIndex++;

                }

                ViewState["CurrentTable3"] = dtCurrentTable;
                //grvStudentDetails.DataSource = dtCurrentTable;
                //grvStudentDetails.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }
        //SetPreviousData();
    }

    protected void gvEmp_RowDataBound3(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            var ddl = (DropDownList)e.Row.FindControl("Col1111");
            //int CountryId = Convert.ToInt32(e.Row.Cells[0].Text);
            SqlCommand cmd = new SqlCommand("select kod_akaun,(kod_akaun + ' | ' + UPPER(nama_akaun)) as name from KW_Ref_Carta_Akaun where jenis_akaun_type !='1' and Status='A' order by kod_akaun asc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "name";
            ddl.DataValueField = "kod_akaun";
            ddl.DataBind();
            ddl.SelectedValue = ((DataRowView)e.Row.DataItem)["Col1"].ToString();
            ddl.Items.Insert(0, new ListItem("--- PILIH ---", ""));




            System.Web.UI.WebControls.TextBox txt1 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("Col5111");
            decimal sval1 = 0;
            decimal sval2 = 0;


            if (txt1.Text == "")
            {
                sval2 = 0;
            }
            else
            {
                sval2 = Convert.ToDecimal(txt1.Text);
            }


            total1 += sval2;
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            //System.Web.UI.WebControls.TextBox lblamount1 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("lblTotal1");
            System.Web.UI.WebControls.TextBox lblamount2 = (System.Web.UI.WebControls.TextBox)e.Row.FindControl("lblTotal2111");
            //lblamount1.Text = total.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
            lblamount2.Text = total1.ToString("C").Replace("RM", "").Replace("RM", "").Replace("$", "");
        }
    }

    //4th grid end

    protected void clk_submit(object sender, EventArgs e)
    {
        if (Tahun_kew.SelectedValue != "")
        {
            string tk_m = string.Empty, tk_a = string.Empty;
            string rcount1 = string.Empty, rcount2 = string.Empty, rcount3 = string.Empty, rcount4 = string.Empty;
            int count1 = 0, count2 = 0, count3 = 0, count4 = 0;
            foreach (GridViewRow gvrow in grvStudentDetails.Rows)
            {
                count1++;
                rcount1 = count1.ToString();
            }

            foreach (GridViewRow gvrow in grvStudentDetails1.Rows)
            {
                count2++;
                rcount2 = count2.ToString();
            }

            foreach (GridViewRow gvrow in grvStudentDetails2.Rows)
            {
                count3++;
                rcount3 = count3.ToString();
            }

            foreach (GridViewRow gvrow in grvStudentDetails3.Rows)
            {
                count4++;
                rcount4 = count4.ToString();
            }

            string count_sqno = string.Empty;
            //DataTable ddokdicno = new DataTable();
            //    ddokdicno = DBCon.Ora_Execute_table("select * from KW_Ref_Pembahagian");
            //if (ddokdicno.Rows.Count != 0)
            //{
            string snp = DateTime.Now.ToString("MMyymmss");
            count_sqno = snp.PadRight(10, '0');
            //}
            //else
            //{
            //count_sqno = "";
            //}
            foreach (GridViewRow row in gv_refdata.Rows)
            {

                string val1_1 = ((Label)row.FindControl("lb_1")).Text.ToString();
                string val2_1 = ((Label)row.FindControl("lb_2")).Text.ToString();
                string val3_1 = ((Label)row.FindControl("lb_3")).Text.ToString();
                string val4_1 = ((Label)row.FindControl("lb_4")).Text.ToString();
                if (val1_1 != "")
                {
                    string Inssql1 = "insert into KW_Ref_Pembahagian(tmp_seq_no,tmp_tahun_kewangan,tmp_kod_akaun,tmp_descript,Ref_peratus,tmp_amt,tmp_jum_amt,crt_id,cr_dt,grp_no) values ('" + count_sqno + "','" + Tahun_kew.SelectedValue + "','" + val2_1 + "','KEUNTUNGAN (KERUGIAN) BERSIH','','','" + val4_1 + "','" + Session["New"].ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','1')";
                    Status = DBCon.Ora_Execute_CommamdText(Inssql1);
                }
            }
            if (rcount1 != "0")
            {
                foreach (GridViewRow row in grvStudentDetails.Rows)
                {
                    string val1 = ((DropDownList)row.FindControl("Col1")).Text.ToString();
                    string val2 = ((TextBox)row.FindControl("Col2")).Text.ToString();
                    string val3 = ((TextBox)row.FindControl("Col3")).Text.ToString();
                    string val4 = ((TextBox)row.FindControl("Col4")).Text.ToString();
                    string val5 = ((TextBox)row.FindControl("Col5")).Text.ToString();
                    if (val1 != "")
                    {
                        string Inssql1 = "insert into KW_Ref_Pembahagian(tmp_seq_no,tmp_tahun_kewangan,tmp_kod_akaun,tmp_descript,Ref_peratus,tmp_amt,tmp_jum_amt,crt_id,cr_dt,grp_no) values ('" + count_sqno + "','" + Tahun_kew.SelectedValue + "','" + val1 + "','" + val2 + "','" + val3 + "','" + val4.Replace("(", "-").Replace(")", "") + "','" + val5.Replace("(", "-").Replace(")", "") + "','" + Session["New"].ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','2')";
                        Status = DBCon.Ora_Execute_CommamdText(Inssql1);
                    }
                }

            }
            if (rcount2 != "0")
            {
                foreach (GridViewRow row1 in grvStudentDetails1.Rows)
                {
                    string val11 = ((DropDownList)row1.FindControl("Col11")).Text.ToString();
                    string val21 = ((TextBox)row1.FindControl("Col21")).Text.ToString();
                    string val31 = ((TextBox)row1.FindControl("Col31")).Text.ToString();
                    string val41 = ((TextBox)row1.FindControl("Col41")).Text.ToString();
                    string val51 = ((TextBox)row1.FindControl("Col51")).Text.ToString();
                    if (val11 != "")
                    {
                        string Inssql2 = "insert into KW_Ref_Pembahagian(tmp_seq_no,tmp_tahun_kewangan,tmp_kod_akaun,tmp_descript,Ref_peratus,tmp_amt,tmp_jum_amt,crt_id,cr_dt,grp_no) values ('" + count_sqno + "','" + Tahun_kew.SelectedValue + "','" + val11 + "','" + val21 + "','" + val31 + "','" + val41.Replace("(", "-").Replace(")", "") + "','" + val51.Replace("(", "-").Replace(")", "") + "','" + Session["New"].ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','3')";
                        Status = DBCon.Ora_Execute_CommamdText(Inssql2);
                    }
                }

            }
            if (rcount3 != "0")
            {
                foreach (GridViewRow row2 in grvStudentDetails2.Rows)
                {
                    string val111 = ((DropDownList)row2.FindControl("Col111")).Text.ToString();
                    string val211 = ((TextBox)row2.FindControl("Col211")).Text.ToString();
                    string val311 = ((TextBox)row2.FindControl("Col311")).Text.ToString();
                    string val411 = ((TextBox)row2.FindControl("Col411")).Text.ToString();
                    string val511 = ((TextBox)row2.FindControl("Col511")).Text.ToString();
                    if (val111 != "")
                    {
                        string Inssql3 = "insert into KW_Ref_Pembahagian(tmp_seq_no,tmp_tahun_kewangan,tmp_kod_akaun,tmp_descript,Ref_peratus,tmp_amt,tmp_jum_amt,crt_id,cr_dt,grp_no) values ('" + count_sqno + "','" + Tahun_kew.SelectedValue + "','" + val111 + "','" + val211 + "','" + val311 + "','" + val411.Replace("(", "-").Replace(")", "") + "','" + val511.Replace("(", "-").Replace(")", "") + "','" + Session["New"].ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','4')";
                        Status = DBCon.Ora_Execute_CommamdText(Inssql3);
                    }
                }

            }

            if (rcount4 != "0")
            {
                foreach (GridViewRow row3 in grvStudentDetails3.Rows)
                {
                    string val1111 = ((DropDownList)row3.FindControl("Col1111")).Text.ToString();
                    string val2111 = ((TextBox)row3.FindControl("Col2111")).Text.ToString();
                    string val3111 = ((TextBox)row3.FindControl("Col3111")).Text.ToString();
                    string val4111 = ((TextBox)row3.FindControl("Col4111")).Text.ToString();
                    string val5111 = ((TextBox)row3.FindControl("Col5111")).Text.ToString();
                    if (val1111 != "")
                    {
                        string Inssql4 = "insert into KW_Ref_Pembahagian(tmp_seq_no,tmp_tahun_kewangan,tmp_kod_akaun,tmp_descript,Ref_peratus,tmp_amt,tmp_jum_amt,crt_id,cr_dt,grp_no) values ('" + count_sqno + "','" + Tahun_kew.SelectedValue + "','" + val1111 + "','" + val2111 + "','" + val3111 + "','" + val4111.Replace("(", "-").Replace(")", "") + "','" + val5111.Replace("(", "-").Replace(")", "") + "','" + Session["New"].ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','5')";
                        Status = DBCon.Ora_Execute_CommamdText(Inssql4);
                    }
                }

            }

            if (Status == "SUCCESS")
            {
                //empty_fld();
                Session["run_sqno"] = count_sqno;
                tab1();
                Button2.Attributes.Remove("style");
                Button1.Attributes.Remove("style");
                Button4.Attributes.Add("style", "pointer-events:None; opacity: 0.5;");
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Berjaya Disimpan.',{'type': 'confirmation','title': 'Success','auto_close': 2000});", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Tidak Bermula.',{'type': 'warning','title': 'Warning','auto_close': 2000});", true);
            }

        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukan Input Carian.',{'type': 'warning','title': 'Warning','auto_close': 2000});", true);

        }
        tab1();
        BindData();
    }



    protected void BindData_show()
    {

        con.Open();
        DataTable ddicno = new DataTable();
        SqlCommand cmd = new SqlCommand("select s1.seq_no as RowNumber,s1.kod_akaun as col1,s1.akaun_keterangan as col2,s1.debit_amt as col3,s1.kredit_amt as col4 from KW_Pelarasan s1 where s1.no_rujukan='" + get_id.Text + "' order by s1.ID asc", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count == 0)
        {
            FirstGridViewRow();
            AddNewRow();
        }
        else
        {
            grvStudentDetails.DataSource = ds;
            grvStudentDetails.DataBind();
        }

        con.Close();
    }

    protected void clk_prnt(object sender, EventArgs e)
    {
        if (Session["run_sqno"].ToString() != "")
        {
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            string val1 = string.Empty, val2 = string.Empty, val3 = string.Empty, val4 = string.Empty, val5 = string.Empty, val6 = string.Empty;

            string fmdate = string.Empty, tmdate = string.Empty, tmdate1 = string.Empty;

            if (Tk_akhir.Text != "")
            {
                string tdate = Tk_akhir.Text;
                DateTime td = DateTime.ParseExact(tdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                tmdate = td.ToString("yyyy-MM-dd");
                tmdate1 = td.ToString("dd MMMM yyyy");
            }
            int min_val = 1;
            int curr_yr = Int32.Parse(DateTime.Now.Year.ToString());
            int prev_yr = (Int32.Parse(DateTime.Now.Year.ToString()) - min_val);

            dt = DBCon.Ora_Execute_table("select *,s1.nama_akaun as akaun_name,case when grp_no = '2' then 'PEMBAHAGIAN BERKANUN' when grp_no = '3' then 'PERUNTUKKAN CUKAI' when grp_no = '4' then 'LAIN-LAIN CADANGAN' when grp_no = '5' then 'CADANGKAN DIVIDEN' else '' end as kat_nam from KW_Ref_Pembahagian left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun=tmp_kod_akaun where tmp_seq_no='"+Session["run_sqno"].ToString()+"'");
            val5 = "select (a.a1 - (2 * b.a1)) as val1,c.a2 as val2,d.a3 as val3,((a.a1 - (2 * b.a1)) - (c.a2) - (d.a3)) val4,e.a3 as val5,(((a.a1 - (2 * b.a1)) - (c.a2) - (d.a3)) - e.a3) as val6 from (select sum(tmp_jum_amt) as a1,'01' as ss1 from KW_Ref_Pembahagian left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun=tmp_kod_akaun where tmp_seq_no='"+Session["run_sqno"].ToString()+"' and grp_no IN ('1','2')) as a left join (select sum(tmp_jum_amt) as a1,'01' as ss2 from KW_Ref_Pembahagian left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun=tmp_kod_akaun where tmp_seq_no='"+Session["run_sqno"].ToString()+"' and grp_no IN ('2')) as b on b.ss2=a.ss1 left join (select sum(tmp_jum_amt) as a2,'01' as ss3 from KW_Ref_Pembahagian left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun=tmp_kod_akaun where tmp_seq_no='"+Session["run_sqno"].ToString()+"' and grp_no IN ('3')) as c on c.ss3=b.ss2 left join (select sum(tmp_jum_amt) as a3,'01' as ss4 from KW_Ref_Pembahagian left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun=tmp_kod_akaun where tmp_seq_no='"+Session["run_sqno"].ToString()+"' and grp_no IN ('4')) as d on d.ss4=c.ss3 left join (select sum(tmp_jum_amt) as a3,'01' as ss4 from KW_Ref_Pembahagian left join KW_Ref_Carta_Akaun s1 on s1.kod_akaun=tmp_kod_akaun where tmp_seq_no='"+Session["run_sqno"].ToString()+"' and grp_no IN ('5')) as e on e.ss4=d.ss4";
            //dt1 = DBCon.Ora_Execute_table(val5);
            Rptviwerlejar.Reset();
            ds.Tables.Add(dt);
            //ds1.Tables.Add(dt1);

            List<DataRow> listResult = dt.AsEnumerable().ToList();
            listResult.Count();
            int countRow = 0;
            countRow = listResult.Count();



            Rptviwerlejar.LocalReport.DataSources.Clear();
            if (countRow != 0)
            {
                DataTable sel_gst1 = new DataTable();
                sel_gst1 = DBCon.Ora_Execute_table(val5);

                Rptviwerlejar.LocalReport.ReportPath = "kewengan/KW_akb.rdlc";
                ReportDataSource rds = new ReportDataSource("kwakb", dt);
                ReportDataSource rds1 = new ReportDataSource("kwpl1", dt1);
                ReportParameter[] rptParams = new ReportParameter[]{
                     new ReportParameter("d1", Convert.ToString(curr_yr)),
                     new ReportParameter("d2", Convert.ToString(prev_yr)),
                     new ReportParameter("d3", tmdate1),
                     new ReportParameter("d4", double.Parse(sel_gst1.Rows[0]["val1"].ToString()).ToString("C").Replace("$","").Replace("RM","")),
                     new ReportParameter("d5", double.Parse(sel_gst1.Rows[0]["val2"].ToString()).ToString("C").Replace("$","").Replace("RM","")),
                     new ReportParameter("d6", double.Parse(sel_gst1.Rows[0]["val3"].ToString()).ToString("C").Replace("$", "").Replace("RM", "")),
                     new ReportParameter("d7", double.Parse(sel_gst1.Rows[0]["val4"].ToString()).ToString("C").Replace("$", "").Replace("RM", "")),
                     new ReportParameter("d8", double.Parse(sel_gst1.Rows[0]["val5"].ToString()).ToString("C").Replace("$", "").Replace("RM", "")),
                     new ReportParameter("d9", double.Parse(sel_gst1.Rows[0]["val6"].ToString()).ToString("C").Replace("$", "").Replace("RM", ""))
                          };

                Rptviwerlejar.LocalReport.SetParameters(rptParams);
                Rptviwerlejar.LocalReport.DataSources.Add(rds);
                //Rptviwerlejar.LocalReport.DataSources.Add(rds1);
                Rptviwerlejar.LocalReport.Refresh();

            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod tidak dijumpai. Sila Pastikan Semua Maklumat Dimasukkan Dengan Betul.',{'type': 'warning','title': 'Warning','auto_close': 2000});", true);
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Laporan Tidak Dijana.',{'type': 'warning','title': 'Warning','auto_close': 2000});", true);
        }
    }

    protected void clk_pstledger(object sender, EventArgs e)
    {
        if (Session["run_sqno"].ToString() != "")
        {
            DataTable ddokdicno = new DataTable();
            ddokdicno = DBCon.Ora_Execute_table("select * from KW_Ref_Pembahagian where tmp_seq_no = '" + Session["run_sqno"].ToString() + "'");
            if (ddokdicno.Rows.Count != 0)
            {
                for (int k = 0; k < ddokdicno.Rows.Count; k++)
                {
                    DataTable ddokdicno1 = new DataTable();
                    ddokdicno1 = DBCon.Ora_Execute_table("select kat_akaun,kod_akaun from KW_Ref_Carta_Akaun where kod_akaun = '" + ddokdicno.Rows[k]["tmp_kod_akaun"].ToString() + "'");
                    string Inssql1 = "insert into KW_General_Ledger(kod_akaun,KW_Debit_amt,KW_kredit_amt,kat_akaun,GL_process_dt,GL_desc1,crt_id,cr_dt,GL_sts) values ('" + ddokdicno.Rows[k]["tmp_kod_akaun"].ToString() + "','" + ddokdicno.Rows[k]["tmp_jum_amt"].ToString() + "','','" + ddokdicno1.Rows[0]["kat_akaun"].ToString() + "','" + ddokdicno1.Rows[0]["cr_dt"].ToString() + "','" + ddokdicno.Rows[k]["tmp_descript"].ToString() + "','" + Session["New"].ToString() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','A')";
                    Status = DBCon.Ora_Execute_CommamdText(Inssql1);
                }

                if (Status == "SUCCESS")
                {
                    
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Berjaya Disimpan.',{'type': 'confirmation','title': 'Success','auto_close': 2000});window.location ='kw_akaun_pembahagian.aspx';", true);
                }
            }
        }
    }
    protected void btn_reset(object sender, EventArgs e)
    {
        Response.Redirect("../kewengan/kw_akaun_pembahagian.aspx");
        Session["run_sqno"] = "";
    }


}