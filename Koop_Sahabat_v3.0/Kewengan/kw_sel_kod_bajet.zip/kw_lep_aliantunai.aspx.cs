﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Threading;
public partial class kw_lep_aliantunai : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();
    private static int PageSize = 20;
    string qry1 = string.Empty, qry2 = string.Empty;
    string level;
    string Status = string.Empty;
    string userid;
    string CommandArgument1 = string.Empty, CommandArgument2 = string.Empty, CommandArgument3 = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        app_language();
        Button4.OnClientClick = @"if(this.value == 'Please wait...')
           return false;
           this.value = 'Please wait...';this.disabled=true";
        string script = " $(function () {$('.select2').select2()});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        //ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        //scriptManager.RegisterPostBackControl(this.Button4);
        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {
                userid = Session["New"].ToString();
                BindData();
                project();
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
    }
    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('831','705','1724','64','65','169','121','15')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[6][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[5][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[6][0].ToString().ToLower());
            ps_lbl4.Text = txtinfo.ToTitleCase(gt_lng.Rows[7][0].ToString().ToLower());          
            ps_lbl5.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
            ps_lbl6.Text = txtinfo.ToTitleCase(gt_lng.Rows[2][0].ToString().ToLower());
            ps_lbl7.Text = txtinfo.ToTitleCase(gt_lng.Rows[3][0].ToString().ToLower());
            Button4.Text = txtinfo.ToTitleCase(gt_lng.Rows[4][0].ToString().ToLower());
            Button1.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());
            

        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }

    void project()
    {
        DataSet Ds = new DataSet();
        try
        {
            string com = "select Ref_Projek_code,Ref_Projek_name from  KW_Ref_Projek";
            SqlDataAdapter adpt = new SqlDataAdapter(com, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            ddpro.DataSource = dt;
            ddpro.DataTextField = "Ref_Projek_name";
            ddpro.DataValueField = "Ref_Projek_code";
            ddpro.DataBind();
            ddpro.Items.Insert(0, new ListItem("--- PILIH ---", ""));

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    //void BindDropdown()
    //{
    //    DateTimeFormatInfo info = DateTimeFormatInfo.GetInstance(null);

    //    int year = DateTime.Now.Year - 5;

    //    for (int Y = year; Y <= DateTime.Now.Year; Y++)

    //    {

    //        Tahun_kew.Items.Add(new ListItem(Y.ToString(), Y.ToString()));

    //    }

    //    Tahun_kew.SelectedValue = DateTime.Now.Year.ToString();

    //}

    protected void BindData()
    {

    }

    protected void clk_submit(object sender, EventArgs e)
    {
        if (Tk_mula.Text != "" && Tk_akhir.Text != "")
        {
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            string val1 = string.Empty, val2 = string.Empty, val2_1 = string.Empty, val3 = string.Empty, val4 = string.Empty, val4_1 = string.Empty, val5 = string.Empty, val6 = string.Empty, val7 = string.Empty, val8 = string.Empty, val8_1 = string.Empty, val8_2 = string.Empty, val8_3 = string.Empty;

            string fmdate = string.Empty, pre_fmdate = string.Empty, fmonth = string.Empty, fyear = string.Empty, stdate = string.Empty, tmdate = string.Empty, pre_tmdate = string.Empty;
            int curr_yr;
            int prev_yr;

            if (Tk_mula.Text != "")
            {
                string fdate = Tk_mula.Text;
                DateTime fd = DateTime.ParseExact(fdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                DateTime fd1 = DateTime.ParseExact(fdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                fmdate = fd.ToString("yyyy-MM-dd");
                pre_fmdate = fd1.AddYears(-1).ToString("yyyy-MM-dd");
               

            }
            if (Tk_akhir.Text != "")
            {
                string tdate = Tk_akhir.Text;
                DateTime td = DateTime.ParseExact(tdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                DateTime td1 = DateTime.ParseExact(tdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                tmdate = td.ToString("yyyy-MM-dd");
                pre_tmdate = td1.AddYears(-1).ToString("yyyy-MM-dd");
            }

            //int min_val = 1;
            //curr_yr = Int32.Parse(fyear);
            //prev_yr = (Int32.Parse(fyear) - min_val);
            //string prev_yr1 = prev_yr + "-01-01";
            //string py_ldate = fyear + "-12-31";
            if (Tk_mula.Text != "" && Tk_akhir.Text != "" && ddpro.SelectedValue == "")
            {
                //val6 = "select distinct cast(a.sqno as int) as oby,cast(a.tmp_position as int) as pos,r1.kat_cd,a.kod_akaun,a.nama_akaun,ISNULL( a1.opening_amt,'0.00') as open_amt,case when d.under_jenis = a.kod_akaun then (CAST(replace((ISNULL( a1.opening_amt,'0.00')),'-','') as money) + CAST(replace((ISNULL(a2.opening_amt,'0.00')),'-','') as money)) else (CAST(replace(ISNULL(a1.opening_amt,'0.00'),'-','')  as money) + CAST(replace(ISNULL(  a2.opening_amt,'0.00'),'-','') as money)) end as oamt1,case when d.under_jenis = a.kod_akaun then (CAST(replace((((ISNULL( a1.opening_amt,'0.00') + 	ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,  '0.00')) + ((ISNULL(d.amt1,'0.00')))),'-','') as money) + CAST(replace((((ISNULL(a2.opening_amt,'0.00') + ISNULL(b1.debit,'0.00')) - 	ISNULL(b1.kredit,'0.00')) + ((ISNULL(d11.amt1,'0.00')))),'-'  ,'') as money)) else (CAST(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00')),'-','') 	as money) + CAST(replace(((ISNULL(a2.opening_amt,'0.00') +   ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00')),'-','') as money)) end as val1, (case when d.under_jenis = a.kod_akaun then CAST(replace((ISNULL(a1.opening_amt,'0.00') +   ISNULL(d.amt1,'0.00')),'-','') as money) else CAST(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money) end + case when d11.under_jenis = 	a.kod_akaun then (CAST(replace((((ISNULL(  a2.opening_amt,'0.00') + ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00')) + ((ISNULL(d11.amt1,'0.00')))),'-','') as money)) else (CAST(replace	(((ISNULL(a2.opening_amt,'0.00') +   ISNULL(b1.debit,'0.00')) - ISNULL(b1.kredit,'0.00')),'-','') as money) ) end) as val2,case when kat_cd='12' or a.kod_akaun='03.02' then replace( case when d.under_jenis = a.kod_akaun then CAST(((ISNULL(	a1.opening_amt,'0.00') - ((  ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))) + (ISNULL(d.amt1,'0.00') - ((ISNULL(d.amt1,'0.00'))))) as money) else 	CAST((ISNULL(a1.opening_amt,'0.00') -   ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))) as money) end ,'-','') else ( case when d.under_jenis = a.kod_akaun then CAST(((ISNULL(	a1.opening_amt,'0.00') - ((  ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))) + (ISNULL(d.amt1,'0.00') - ((ISNULL(d.amt1,'0.00'))))) as money) else 	CAST((ISNULL(a1.opening_amt,'0.00') -   ((ISNULL(a1.opening_amt,'0.00') + ISNULL(b.debit,'0.00')) - ISNULL(b.kredit,'0.00'))) as money) end) end as varamt from (select mm2.kod_akaun,mm2.kat_akaun,	mm2.nama_akaun,mm1.sqno,mm1.tmp_position,tmp_h1,tmp_h2,tmp_h3,tmp_h4,tmp_h5,tmp_h6   from kw_template_aliran mm1 left join KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun and 	mm2.jenis_akaun_type != '1' and mm2.AT_rep='1') as a Left join(select kod_akaun,kat_akaun , sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between 	start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as   debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>	=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%'	 and b.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,  sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where 	 GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as c on c.kod_akaun like 	 '%'+a.kod_akaun+'%' and c.kat_akaun=a.kat_akaun  left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as amt1 from   KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on 	 s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and Susu_nilai = '1'   group by m1.under_jenis,	 m1.kod_akaun,m1.kat_akaun) as d on d.under_jenis like '%'+a.kod_akaun+'%' and d.kat_akaun=a.kat_akaun left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join   KW_Opening_Balance s1 on 	 s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and  Susu_nilai = '1' group by m1.under_jenis,  	 m1.kod_akaun,m1.kat_akaun) as d1 on d1.under_jenis like '%'+a.kod_akaun+'%' and d1.kat_akaun=a.kat_akaun  Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between 	 start_dt and end_dt) as a2   on a2.kod_akaun like '%'+a.kod_akaun+'%' Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt< DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +1) group by kod_akaun) as b1 on b1.kod_akaun=a.kod_akaun Left join (select   kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,	 sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_process_dt<DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +1) group by kod_akaun,kat_akaun) as c1 on 	 c1.kod_akaun like '%'+a.kod_akaun+'%' and c1.kat_akaun=a.kat_akaun left join(select mm2.kod_akaun,  mm2.under_jenis,sum(opening_amt) as amt1 from kw_template_aliran mm1 left join 	 KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun left join KW_Opening_Balance s1 on s1.kod_akaun=  mm1.tmp_kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt 	 where jenis_akaun_type != '1' and AT_rep='1' group by mm2.under_jenis,mm2.kod_akaun) as d11 on d11.under_jenis=a.kod_akaun left join(  select m1.kod_akaun,m1.under_jenis,sum(opening_amt) as 	 amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt   where jenis_akaun_type != '1' and 	 kkk_rep='1' and Susu_nilai = '1' group by m1.under_jenis,m1.kod_akaun) as d12 on d1.under_jenis=a.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=   a.kat_akaun where tmp_h1 = 'S' 	 or tmp_h2 = 'S' or tmp_h3 = 'S' or tmp_h4 = 'S' or tmp_h5 = 'S' or tmp_h6='S' order by cast(a.sqno as int),cast(a.tmp_position as int)";
                val6 = "select distinct cast(a.sqno as int) as oby,case when cast(a.sqno as int) IN ('1','2','3','4','5') then '01' else '02' end as oby1 ,cast(a.tmp_position as int) as pos,r1.kat_cd,a.kod_akaun,a.nama_akaun,ISNULL( a1.opening_amt,'0.00') as open_amt,ISNULL( pre_a.opening_amt,'0.00') as pre_open_amt  ,(((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00'))) as val1  ,(((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) as val2  ,case when r1.kat_cd='12' or a.kod_akaun='03.02' or a.kod_akaun='03.02.01' then cast(replace( ((((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) - (((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00')))) ,'-','') as money) else ((((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) - (((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00')))) end varamt   from 	(select mm2.kod_akaun,mm2.kat_akaun,	mm2.nama_akaun,mm1.sqno,mm1.tmp_position,tmp_h1,tmp_h2,tmp_h3,tmp_h4,tmp_h5,tmp_h6,tmp_h7   from kw_template_aliran mm1 left join KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun and 	mm2.jenis_akaun_type != '1' and mm2.AT_rep='1') as a 	Left join(select kod_akaun,kat_akaun , sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as   debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>	=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun=a.kat_akaun 	 left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as opening_amt from   KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on 	 s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and Susu_nilai = '1'   group by m1.under_jenis,	 m1.kod_akaun,m1.kat_akaun) as d on d.under_jenis like '%'+a.kod_akaun+'%' and d.kat_akaun=a.kat_akaun 	Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,  sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as c on c.kod_akaun like '%'+d.kod_akaun+'%' and c.kat_akaun =d.kat_akaun Left join(select kod_akaun,kat_akaun , sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + pre_fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as pre_a on pre_a.kod_akaun like '%'+a.kod_akaun+'%' and pre_a.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as   debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + pre_fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + pre_tmdate + "'), +1) group by kod_akaun,kat_akaun) as pre_b on pre_b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun=a.kat_akaun left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as opening_amt from KW_Ref_Carta_Akaun m1 left join   KW_Opening_Balance s1 on  s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + pre_fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and  Susu_nilai = '1' group by m1.under_jenis,  m1.kod_akaun,m1.kat_akaun) as pre_c on pre_c.under_jenis like '%'+a.kod_akaun+'%' and pre_c.kat_akaun=a.kat_akaun  Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + pre_fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + pre_tmdate + "'), +1) group by kod_akaun,kat_akaun) as pre_d on pre_d.kod_akaun=pre_c.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=   a.kat_akaun where ISNULL(kat_cd,'') != '' and tmp_h1 = 'S' or tmp_h2 = 'S' or tmp_h3 = 'S' or tmp_h4 = 'S' or tmp_h5 = 'S' or tmp_h6='S' or tmp_h7='S' order by cast(a.sqno as int),cast(a.tmp_position as int)";
                val7 = "select oby1,sum(varamt) as vamt from (select distinct cast(a.sqno as int) as oby,case when cast(a.sqno as int) IN ('1','2','3','4','5') then '01' else '02' end as oby1 ,cast(a.tmp_position as int) as pos,r1.kat_cd,a.kod_akaun,a.nama_akaun,ISNULL( a1.opening_amt,'0.00') as open_amt,ISNULL( pre_a.opening_amt,'0.00') as pre_open_amt  ,(((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00'))) as val1  ,(((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) as val2  ,case when r1.kat_cd='12' or a.kod_akaun='03.02' or a.kod_akaun='03.02.01' then cast(replace( ((((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) - (((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00')))) ,'-','') as money) else ((((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) - (((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00')))) end varamt   from 	(select mm2.kod_akaun,mm2.kat_akaun,	mm2.nama_akaun,mm1.sqno,mm1.tmp_position,tmp_h1,tmp_h2,tmp_h3,tmp_h4,tmp_h5,tmp_h6,tmp_h7   from kw_template_aliran mm1 left join KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun and 	mm2.jenis_akaun_type != '1' and mm2.AT_rep='1') as a 	Left join(select kod_akaun,kat_akaun , sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as   debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>	=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun=a.kat_akaun 	 left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as opening_amt from   KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on 	 s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and Susu_nilai = '1'   group by m1.under_jenis,	 m1.kod_akaun,m1.kat_akaun) as d on d.under_jenis like '%'+a.kod_akaun+'%' and d.kat_akaun=a.kat_akaun 	Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,  sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as c on c.kod_akaun like '%'+d.kod_akaun+'%' and c.kat_akaun =d.kat_akaun Left join(select kod_akaun,kat_akaun , sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + pre_fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as pre_a on pre_a.kod_akaun like '%'+a.kod_akaun+'%' and pre_a.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as   debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + pre_fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + pre_tmdate + "'), +1) group by kod_akaun,kat_akaun) as pre_b on pre_b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun=a.kat_akaun left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as opening_amt from KW_Ref_Carta_Akaun m1 left join   KW_Opening_Balance s1 on  s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + pre_fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and  Susu_nilai = '1' group by m1.under_jenis,  m1.kod_akaun,m1.kat_akaun) as pre_c on pre_c.under_jenis like '%'+a.kod_akaun+'%' and pre_c.kat_akaun=a.kat_akaun  Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + pre_fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + pre_tmdate + "'), +1) group by kod_akaun,kat_akaun) as pre_d on pre_d.kod_akaun=pre_c.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=   a.kat_akaun where ISNULL(kat_cd,'') != '' and tmp_h1 = 'S' or tmp_h2 = 'S' or tmp_h3 = 'S' or tmp_h4 = 'S' or tmp_h5 = 'S' or tmp_h6='S' or tmp_h7='S') as  f1 group by oby1";
                //val8 = "select ISNULL(sum(distinct case when d.under_jenis = a.kod_akaun then (CAST(replace((ISNULL( a1.opening_amt,'0.00')),'-','') as money) + CAST(replace((ISNULL(a2.opening_amt,'0.00')),'-','') as money)) else (CAST(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money) + CAST(replace(ISNULL(a2.opening_amt,'0.00'),'-','') as money)) end) as oamt1 from (select mm2.kod_akaun,mm2.kat_akaun,mm2.nama_akaun,mm1.sqno,mm1.tmp_position from kw_template_aliran mm1 left join KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun  and mm2.jenis_akaun_type != '1' and mm2.AT_rep='1' where mm1.sqno ='5') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + curr_yr + "') as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as c on c.kod_akaun=a.kod_akaun left join(select m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and opening_year='" + curr_yr + "' where jenis_akaun_type != '1' and kkk_rep='1' and Susu_nilai = '1' group by m1.under_jenis,m1.kod_akaun) as d on d.under_jenis=a.kod_akaun left join(select m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and opening_year='" + curr_yr + "' where jenis_akaun_type != '1' and kkk_rep='1' and  Susu_nilai = '1' group by m1.under_jenis,m1.kod_akaun) as d1 on d1.under_jenis=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + prev_yr + "') as a2 on a2.kod_akaun= a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + prev_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + prev_yr1 + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + py_ldate + "'), +1) group by kod_akaun) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + prev_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + prev_yr1 + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + py_ldate + "'), +1) group by kod_akaun) as c1 on c1.kod_akaun=a.kod_akaun left join(select mm2.kod_akaun,mm2.under_jenis,sum(opening_amt) as amt1 from kw_template_aliran mm1 left join KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun left join KW_Opening_Balance s1 on s1.kod_akaun=mm1.tmp_kod_akaun and set_sts='1' and opening_year='" + prev_yr + "' where jenis_akaun_type != '1' and mm1.sqno ='5' and AT_rep='1' group by mm2.under_jenis,mm2.kod_akaun) as d11 on d11.under_jenis=a.kod_akaun left join(select m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and opening_year='" + prev_yr + "' where jenis_akaun_type != '1' and kkk_rep='1' and Susu_nilai = '1' group by m1.under_jenis,m1.kod_akaun) as d12 on d1.under_jenis=a.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun ";
                
                val5 = "select '05.02' as kod_akaun,'0.00' res,(ISNULL(a.val1,'0.00') - ISNULL(b.val1,'0.00')) as kt from (select '01' as vv1,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1 from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type='2' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) group by kod_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun ) as a left join (select '01' as vv1,(SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) * 2) as val1 from (select * from KW_Ref_Carta_Akaun where PAL_rep='1' and jenis_akaun_type='2') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '2018'), +0) group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' ) as b on b.vv1=a.vv1";
            }
            else if (Tk_mula.Text != "" && Tk_akhir.Text != "" && ddpro.SelectedValue != "")
            {
                //val6 = "select case when r1.kat_cd='10' then '01' when r1.kat_cd='15' then '02' when r1.kat_cd='11' then '03' when r1.kat_cd='12' then '04' else '05' end as oby,r1.bal_type as baltype,case when r1.bal_type='01' then 'K' else 'D' end as baltype2,r1.kat_cd,r1.kat_akuan,a.nama_akaun,a.kod_akaun, case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end as val1,cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) as val2,'' as varamt from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' and AT_rep='1' and jenis_akaun_type='" + akaun_level.SelectedValue + "') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + prev_yr + "') as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + prev_yr + "') and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + fyear + "') as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where YEAR(GL_process_dt) IN ('" + fyear + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and GL_projek='" + ddpro.SelectedValue + "' group by kod_akaun) as b2 on b2.kod_akaun=a.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun order by oby asc";
                val6 = "select distinct cast(a.sqno as int) as oby,case when cast(a.sqno as int) IN ('1','2','3','4','5') then '01' else '02' end as oby1 ,cast(a.tmp_position as int) as pos,r1.kat_cd,a.kod_akaun,a.nama_akaun,ISNULL( a1.opening_amt,'0.00') as open_amt,ISNULL( pre_a.opening_amt,'0.00') as pre_open_amt  ,(((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00'))) as val1  ,(((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) as val2  ,case when r1.kat_cd='12' or r1.kat_cd='03' then cast(replace( ((((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) - (((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00')))) ,'-','') as money) else ((((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) - (((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00')))) end varamt   from 	(select mm2.kod_akaun,mm2.kat_akaun,	mm2.nama_akaun,mm1.sqno,mm1.tmp_position,tmp_h1,tmp_h2,tmp_h3,tmp_h4,tmp_h5,tmp_h6,tmp_h7   from kw_template_aliran mm1 left join KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun and 	mm2.jenis_akaun_type != '1' and mm2.AT_rep='1') as a 	Left join(select kod_akaun,kat_akaun , sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as   debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>	=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun=a.kat_akaun 	 left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as opening_amt from   KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on 	 s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and Susu_nilai = '1'   group by m1.under_jenis,	 m1.kod_akaun,m1.kat_akaun) as d on d.under_jenis like '%'+a.kod_akaun+'%' and d.kat_akaun=a.kat_akaun 	Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,  sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as c on c.kod_akaun like '%'+d.kod_akaun+'%' and c.kat_akaun =d.kat_akaun Left join(select kod_akaun,kat_akaun , sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + pre_fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as pre_a on pre_a.kod_akaun like '%'+a.kod_akaun+'%' and pre_a.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as   debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + pre_fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + pre_tmdate + "'), +1) group by kod_akaun,kat_akaun) as pre_b on pre_b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun=a.kat_akaun left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as opening_amt from KW_Ref_Carta_Akaun m1 left join   KW_Opening_Balance s1 on  s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + pre_fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and  Susu_nilai = '1' group by m1.under_jenis,  m1.kod_akaun,m1.kat_akaun) as pre_c on pre_c.under_jenis like '%'+a.kod_akaun+'%' and pre_c.kat_akaun=a.kat_akaun  Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + pre_fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + pre_tmdate + "'), +1) group by kod_akaun,kat_akaun) as pre_d on pre_d.kod_akaun=pre_c.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=   a.kat_akaun where ISNULL(kat_cd,'') != '' and tmp_h1 = 'S' or tmp_h2 = 'S' or tmp_h3 = 'S' or tmp_h4 = 'S' or tmp_h5 = 'S' or tmp_h6='S' or tmp_h7='S' order by cast(a.sqno as int),cast(a.tmp_position as int)";
                val7 = "select oby1,sum(varamt) as vamt from (select distinct cast(a.sqno as int) as oby,case when cast(a.sqno as int) IN ('1','2','3','4','5') then '01' else '02' end as oby1 ,cast(a.tmp_position as int) as pos,r1.kat_cd,a.kod_akaun,a.nama_akaun,ISNULL( a1.opening_amt,'0.00') as open_amt,ISNULL( pre_a.opening_amt,'0.00') as pre_open_amt  ,(((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00'))) as val1  ,(((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) as val2  ,case when r1.kat_cd='12' or r1.kat_cd='03' then cast(replace( ((((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) - (((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00')))) ,'-','') as money) else ((((ISNULL( pre_a.opening_amt,'0.00') + ISNULL( pre_b.debit,'0.00')) - ISNULL( pre_b.kredit,'0.00')) - ((ISNULL( pre_c.opening_amt,'0.00') + ISNULL( pre_d.debit,'0.00')) - ISNULL( pre_d.kredit,'0.00'))) - (((ISNULL( a1.opening_amt,'0.00') + ISNULL( b.debit,'0.00')) - ISNULL( b.kredit,'0.00')) - ((ISNULL( d.opening_amt,'0.00') + ISNULL( c.debit,'0.00')) - ISNULL( c.kredit,'0.00')))) end varamt   from 	(select mm2.kod_akaun,mm2.kat_akaun,	mm2.nama_akaun,mm1.sqno,mm1.tmp_position,tmp_h1,tmp_h2,tmp_h3,tmp_h4,tmp_h5,tmp_h6,tmp_h7   from kw_template_aliran mm1 left join KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun and 	mm2.jenis_akaun_type != '1' and mm2.AT_rep='1') as a 	Left join(select kod_akaun,kat_akaun , sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as a1 on a1.kod_akaun like '%'+a.kod_akaun+'%' and a1.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as   debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>	=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as b on b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun=a.kat_akaun 	 left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as opening_amt from   KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on 	 s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and Susu_nilai = '1'   group by m1.under_jenis,	 m1.kod_akaun,m1.kat_akaun) as d on d.under_jenis like '%'+a.kod_akaun+'%' and d.kat_akaun=a.kat_akaun 	Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,  sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun,kat_akaun) as c on c.kod_akaun like '%'+d.kod_akaun+'%' and c.kat_akaun =d.kat_akaun Left join(select kod_akaun,kat_akaun , sum(ISNULL(opening_amt,'0.00')) as opening_amt from KW_Opening_Balance where set_sts='1' and '" + pre_fmdate + "' between start_dt and end_dt group by kod_akaun,kat_akaun) as pre_a on pre_a.kod_akaun like '%'+a.kod_akaun+'%' and pre_a.kat_akaun=a.kat_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as   debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit,kat_akaun from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + pre_fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + pre_tmdate + "'), +1) group by kod_akaun,kat_akaun) as pre_b on pre_b.kod_akaun like '%'+a.kod_akaun+'%' and b.kat_akaun=a.kat_akaun left join(select m1.kod_akaun,m1.kat_akaun,m1.under_jenis,sum(opening_amt) as opening_amt from KW_Ref_Carta_Akaun m1 left join   KW_Opening_Balance s1 on  s1.kod_akaun=m1.kod_akaun and set_sts='1' and '" + pre_fmdate + "' between start_dt and end_dt where jenis_akaun_type != '1' and kkk_rep='1' and  Susu_nilai = '1' group by m1.under_jenis,  m1.kod_akaun,m1.kat_akaun) as pre_c on pre_c.under_jenis like '%'+a.kod_akaun+'%' and pre_c.kat_akaun=a.kat_akaun  Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit,kat_akaun from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + pre_fmdate + "'), 0) and GL_process_dt<=  DATEADD(day, DATEDIFF(day, 0, '" + pre_tmdate + "'), +1) group by kod_akaun,kat_akaun) as pre_d on pre_d.kod_akaun=pre_c.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=   a.kat_akaun where ISNULL(kat_cd,'') != '' and tmp_h1 = 'S' or tmp_h2 = 'S' or tmp_h3 = 'S' or tmp_h4 = 'S' or tmp_h5 = 'S' or tmp_h6='S' or tmp_h7='S') as  f1 group by oby1";
                //val8 = "select ISNULL(sum(distinct case when d.under_jenis = a.kod_akaun then (CAST(replace((ISNULL( a1.opening_amt,'0.00')),'-','') as money) + CAST(replace((ISNULL(a2.opening_amt,'0.00')),'-','') as money)) else (CAST(replace(ISNULL(a1.opening_amt,'0.00'),'-','') as money) + CAST(replace(ISNULL(a2.opening_amt,'0.00'),'-','') as money)) end) as oamt1 from (select mm2.kod_akaun,mm2.kat_akaun,mm2.nama_akaun,mm1.sqno,mm1.tmp_position from kw_template_aliran mm1 left join KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun  and mm2.jenis_akaun_type != '1' and mm2.AT_rep='1' where mm1.sqno ='5') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + curr_yr + "') as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b on b.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and YEAR(GL_process_dt) IN ('" + curr_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as c on c.kod_akaun=a.kod_akaun left join(select m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and opening_year='" + curr_yr + "' where jenis_akaun_type != '1' and kkk_rep='1' and Susu_nilai = '1' group by m1.under_jenis,m1.kod_akaun) as d on d.under_jenis=a.kod_akaun left join(select m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and opening_year='" + curr_yr + "' where jenis_akaun_type != '1' and kkk_rep='1' and  Susu_nilai = '1' group by m1.under_jenis,m1.kod_akaun) as d1 on d1.under_jenis=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and opening_year='" + prev_yr + "') as a2 on a2.kod_akaun= a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and YEAR(GL_process_dt) IN ('" + prev_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + prev_yr1 + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + py_ldate + "'), +1) group by kod_akaun) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(ISNULL(KW_Debit_amt,'0.00')) as debit,sum(ISNULL(KW_kredit_amt,'0.00')) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and YEAR(GL_process_dt) IN ('" + prev_yr + "') and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + prev_yr1 + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + py_ldate + "'), +1) group by kod_akaun) as c1 on c1.kod_akaun=a.kod_akaun left join(select mm2.kod_akaun,mm2.under_jenis,sum(opening_amt) as amt1 from kw_template_aliran mm1 left join KW_Ref_Carta_Akaun mm2 on mm2.kod_akaun=mm1.tmp_kod_akaun left join KW_Opening_Balance s1 on s1.kod_akaun=mm1.tmp_kod_akaun and set_sts='1' and opening_year='" + prev_yr + "' where jenis_akaun_type != '1' and mm1.sqno ='5' and AT_rep='1' group by mm2.under_jenis,mm2.kod_akaun) as d11 on d11.under_jenis=a.kod_akaun left join(select m1.kod_akaun,m1.under_jenis,sum(opening_amt) as amt1 from KW_Ref_Carta_Akaun m1 left join KW_Opening_Balance s1 on s1.kod_akaun=m1.kod_akaun and set_sts='1' and opening_year='" + prev_yr + "' where jenis_akaun_type != '1' and kkk_rep='1' and Susu_nilai = '1' group by m1.under_jenis,m1.kod_akaun) as d12 on d1.under_jenis=a.kod_akaun left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun ";                
                val5 = "select '05.02' as kod_akaun,'0.00' res,(ISNULL(a.val1,'0.00') - ISNULL(b.val1,'0.00')) as kt from (select '01' as vv1,sum( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) as val1 from (select * from KW_Ref_Carta_Akaun where jenis_akaun_type='2' and PAL_rep='1') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), +0) group by kod_akaun) as a2 on a2.kod_akaun like '%'+a.kod_akaun+'%' Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' left join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun ) as a left join (select '01' as vv1,(SUM( case when ISNULL(b1.opening_amt,'0.00') = '0.00' then cast(replace(((cast(replace(((ISNULL(a1.opening_amt,'0.00') + ISNULL(a2.debit,'0.00')) - ISNULL(a2.kredit,'0.00')),'-','') as money) + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money)  else cast(replace(((ISNULL(b1.opening_amt,'0.00') + ISNULL(b2.debit,'0.00')) - ISNULL(b2.kredit,'0.00')),'-','') as money) end) * 2) as val1 from (select * from KW_Ref_Carta_Akaun where PAL_rep='1' and jenis_akaun_type='2') as a Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as a1 on a1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '2018'), +0) group by kod_akaun) as a2 on a2.kod_akaun=a.kod_akaun Left join(select kod_akaun,ISNULL(opening_amt,'0.00') as opening_amt from KW_Opening_Balance where set_sts='1' and '" + fmdate + "' between start_dt and end_dt) as b1 on b1.kod_akaun=a.kod_akaun Left join (select kod_akaun,sum(KW_Debit_amt) as debit,sum(KW_kredit_amt) kredit from KW_General_Ledger where GL_projek='" + ddpro.SelectedValue + "' and GL_process_dt>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and GL_process_dt<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) group by kod_akaun) as b2 on b2.kod_akaun like '%'+a.kod_akaun+'%' inner join KW_Kategori_akaun as r1 on r1.kat_cd=a.kat_akaun and r1.bal_type='D' ) as b on b.vv1=a.vv1";
            }



            dt = DBCon.Ora_Execute_table(val6);
            //dt1 = DBCon.Ora_Execute_table(val5);
            Rptviwerlejar.Reset();
            ds.Tables.Add(dt);
            //ds1.Tables.Add(dt1);

            List<DataRow> listResult = dt.AsEnumerable().ToList();
            listResult.Count();
            int countRow = 0;
            countRow = listResult.Count();



            Rptviwerlejar.LocalReport.DataSources.Clear();
            if (countRow != 0)
            {
                DataTable sel_gst1 = new DataTable();
                sel_gst1 = DBCon.Ora_Execute_table(val5);

                DataTable sel_gst2 = new DataTable();
                sel_gst2 = DBCon.Ora_Execute_table(val7);

                //DataTable sel_gst3 = new DataTable();
                //sel_gst3 = DBCon.Ora_Execute_table(val8);

                if (sel_gst1.Rows.Count != 0)
                {
                    val2 = sel_gst1.Rows[0]["kt"].ToString();
                    val2_1 = sel_gst1.Rows[0]["res"].ToString();
                }
                else
                {
                    val2 = "0.00";
                    val2_1 = "0.00";

                }

                if (sel_gst2.Rows.Count != 0)
                {
                    val4 = sel_gst2.Rows[0]["vamt"].ToString();                    
                }
                else
                {
                    val4 = "0.00";                    
                }

                //if (sel_gst3.Rows.Count != 0)
                //{
                //    val8_1 = double.Parse(sel_gst3.Rows[0]["oamt1"].ToString()).ToString("C").Replace("RM", "").Replace("$", "");
                //    val8_2 = sel_gst3.Rows[0]["oamt1"].ToString();
                //}
                //else
                //{
                    val8_1 = "0.00";
                    val8_2 = "0.00";
                //}

                double var1 = double.Parse(val2_1);
                val3 = double.Parse(Convert.ToString(var1)).ToString("C").Replace("RM", "").Replace("$", "");

                double var2 = double.Parse(val2) + double.Parse(val4);
                val8_3 = double.Parse(Convert.ToString(var2)).ToString("C").Replace("RM", "").Replace("$", "");

                string get_edt = string.Empty;
                DataTable sel_gst_edt = new DataTable();
                sel_gst_edt = DBCon.Ora_Execute_table("select top(1) Format(tarikh_akhir,'dd MMMM yyyy') as end_dt from kw_profile_syarikat where cur_sts='1' order by tarikh_akhir desc");
                if (sel_gst_edt.Rows.Count != 0)
                {
                    get_edt = sel_gst_edt.Rows[0]["end_dt"].ToString();

                }

                Rptviwerlejar.LocalReport.ReportPath = "Kewengan/KW_lap_aliran.rdlc";
                ReportDataSource rds = new ReportDataSource("kwalian", dt);
                //ReportDataSource rds1 = new ReportDataSource("kwpl1", dt1);
                ReportParameter[] rptParams = new ReportParameter[]{
                    new ReportParameter("d1", Convert.ToString(fyear)),
                     new ReportParameter("d2", ""),
                     new ReportParameter("d3", double.Parse(val2).ToString("C").Replace("RM", "").Replace("$", "")),
                     new ReportParameter("d4", double.Parse(val3).ToString("C").Replace("RM", "").Replace("$", "")),
                     new ReportParameter("d5", double.Parse(val4).ToString("C").Replace("RM", "").Replace("$", "")),
                     new ReportParameter("d6", double.Parse(val8_1).ToString("C").Replace("RM", "").Replace("$", "")),
                     new ReportParameter("d7", val8_3),
                     new ReportParameter("d8", get_edt)
                          };

                Rptviwerlejar.LocalReport.SetParameters(rptParams);
                Rptviwerlejar.LocalReport.DataSources.Add(rds);
                //Rptviwerlejar.LocalReport.DataSources.Add(rds1);
                Rptviwerlejar.LocalReport.Refresh();
                System.Threading.Thread.Sleep(1);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod tidak dijumpai. Sila Pastikan Semua Maklumat Dimasukkan Dengan Betul.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukan Input Carian.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
        }
    }



    protected void btn_reset(object sender, EventArgs e)
    {
        Response.Redirect("../kewengan/kw_lep_aliantunai.aspx");
    }


}