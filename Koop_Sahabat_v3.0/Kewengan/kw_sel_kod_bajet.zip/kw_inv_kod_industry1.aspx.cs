﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Threading;

public partial class kw_inv_kod_industry1 : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();
    private static int PageSize = 20;
    decimal total = 0, total1 = 0;
    string uniqueId;
    string qry1 = string.Empty, qry2 = string.Empty;
    string level;
    string Status = string.Empty, Status_del = string.Empty, Status1 = string.Empty, Status2 = string.Empty;
    string userid;
    string CommandArgument1 = string.Empty, CommandArgument2 = string.Empty, CommandArgument3 = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        string script = " $(function () {$('.select2').select2()});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {
                userid = Session["New"].ToString();
              
                get_barang();
                BindData_show();
                //if (Session["pro_id"].ToString() != "")
                //{

                //    view_details();
                //}
                //else
                //{

                //    ver_id.Text = "0";
                //}
                app_language();
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
    }
    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('759','705')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());
          
        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }


    void view_details()
    {
       
    }

    protected void gvEmp_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            var ddl = (DropDownList)e.Row.FindControl("lbl1");
            //int CountryId = Convert.ToInt32(e.Row.Cells[0].Text);
            SqlCommand cmd = new SqlCommand("select *,(msic_kod +' | '+ msic_desc) as name from KW_Ref_Kod_Industri", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "name";
            ddl.DataValueField = "msic_kod";
            ddl.DataBind();
            ddl.SelectedValue = ((DataRowView)e.Row.DataItem)["lbl1"].ToString();
            ddl.Items.Insert(0, new ListItem("--- PILIH ---", ""));

        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            System.Web.UI.WebControls.Label lblamount2 = (System.Web.UI.WebControls.Label)e.Row.FindControl("lblTotal2");

            DataTable ddokdicno = new DataTable();
            ddokdicno = DBCon.Ora_Execute_table("select * from Kw_kod_industry where kod_industry != ''");
            if (ddokdicno.Rows.Count != 0)
            {
                lblamount2.Text = "100 %";
            }
            else
            {
                lblamount2.Text = "0 %";
            }
        }
    }

    protected void QtyChanged(object sender, EventArgs eventArgs)
    {
        decimal numTotal = 0;



        GridViewRow row = ((GridViewRow)((System.Web.UI.WebControls.DropDownList)sender).NamingContainer);
        System.Web.UI.WebControls.DropDownList kod = (System.Web.UI.WebControls.DropDownList)row.FindControl("lbl1");
        System.Web.UI.WebControls.Label per = (System.Web.UI.WebControls.Label)row.FindControl("lbl2");
        System.Web.UI.WebControls.Label val_id = (System.Web.UI.WebControls.Label)row.FindControl("lbl_id");
        System.Web.UI.WebControls.Label jum1 = (System.Web.UI.WebControls.Label)gv_refdata.FooterRow.FindControl("lblTotal2");

        string rcount1 = string.Empty, rcount2 = string.Empty, rcount3 = string.Empty, rcount4 = string.Empty;
        int count1 = 0, count2 = 0;
        int perval1 = 0;
        foreach (GridViewRow gvrow in gv_refdata.Rows)
        {
            string val1_1 = ((System.Web.UI.WebControls.DropDownList)gvrow.FindControl("lbl1")).SelectedValue;
            if (val1_1.ToString() != "")
            {
               
                    count1++;
                    rcount1 = count1.ToString();
               
            }
        }

        jum1.Text = "100";
       
        if (rcount1 != "")
        {
            int ss1 = Int32.Parse(jum1.Text) / Int32.Parse(rcount1);
            per.Text = ss1.ToString();
        }
        else
        {
            per.Text = "0";
        }
        if (kod.SelectedValue != "")
        {
            count2 = Int32.Parse(per.Text);
        }
        else
        {
            count2 = 0;
        }
            string Inssql2 = "UPDATE Kw_kod_industry set kod_industry='"+ kod.SelectedValue + "',indutry_per='" + count2 + "' where Id='" + val_id.Text + "'";
        Status = DBCon.Ora_Execute_CommamdText(Inssql2);

       

        if (Status == "SUCCESS")
        {
                      
            string Inssql1 = "UPDATE Kw_kod_industry set indutry_per='" + per.Text + "',upd_id='" + Session["New"].ToString() + "',upd_dt='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where Id !='6' and kod_industry != ''";
            Status = DBCon.Ora_Execute_CommamdText(Inssql1);
            BindData_show();
        }
    }
    protected void BindData_show()
    {

        con.Open();
        DataTable ddicno = new DataTable();
        SqlCommand cmd = new SqlCommand("select *,CONVERT(varchar(10), case when CONVERT(varchar(10), Kod_industry) ='0' then '' else CONVERT(varchar(10), Kod_industry) end) as lbl1 from Kw_kod_industry order by Id", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count == 0)
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gv_refdata.DataSource = ds;
            gv_refdata.DataBind();
            int columncount = gv_refdata.Rows[0].Cells.Count;
            gv_refdata.Rows[0].Cells.Clear();
            gv_refdata.Rows[0].Cells.Add(new TableCell());
            gv_refdata.Rows[0].Cells[0].ColumnSpan = columncount;
            gv_refdata.Rows[0].Cells[0].Text = "<center>Maklumat Carian Tidak Dijumpai</center>";
        }
        else
        {
            gv_refdata.DataSource = ds;
            gv_refdata.DataBind();
            gv_refdata.FooterRow.Cells[1].Text = "JUMLAH";
            gv_refdata.FooterRow.Cells[1].HorizontalAlign = HorizontalAlign.Right;
        }

        con.Close();
    }

    protected void gvSelected_PageIndexChanging1(object sender, GridViewPageEventArgs e)
    {
        gv_refdata.PageIndex = e.NewPageIndex;
        gv_refdata.DataBind();
        BindData_show();
    }
     
   
    void get_barang()
    {
        //DataSet Ds = new DataSet();
        //try
        //{

        //    string com = "SELECT kod_barang, (kod_barang +' : ' + nama_barang) as name FROM KW_kemasukan_inventori";
        //    SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        //    DataTable dt = new DataTable();
        //    adpt.Fill(dt);
        //    DropDownList1.DataSource = dt;
        //    DropDownList1.DataBind();
        //    DropDownList1.DataTextField = "name";
        //    DropDownList1.DataValueField = "kod_barang";
        //    DropDownList1.DataBind();
        //    DropDownList1.Items.Insert(0, new ListItem("--- PILIH ---", ""));
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
    }
    protected void get_pelinfo(object sender, EventArgs e)
    {
        DataTable ddokdicno1 = new DataTable();
        ddokdicno1 = DBCon.Ora_Execute_table("select distinct Ref_nama_syarikat,(ref_alamat +', '+ Ref_kawalan +', '+ ref_alamat_ked +', '+pel_bandar +', ' + s1.hr_negeri_desc +', '+pel_poskod +', '+ s2.CountryName) as address from KW_Ref_Pelanggan left join Ref_hr_negeri as s1 on s1.hr_negeri_Code=pel_negeri left join Country s2 on s2.ID=pel_negera where Ref_no_syarikat='' ");
        if (ddokdicno1.Rows.Count != 0)
        {
            //TextBox2.Text = ddokdicno1.Rows[0]["address"].ToString();
        }
    }

    //protected void clk_submit(object sender, EventArgs e)
    //{
    //    foreach (GridViewRow row2 in gv_refdata.Rows)
    //    {
    //        //string val1 = ((DropDownList)row2.FindControl("Col111")).Text.ToString();
    //        string val1 = ((System.Web.UI.WebControls.TextBox)row2.FindControl("lbl1")).Text.ToString();
    //        string val2 = ((System.Web.UI.WebControls.TextBox)row2.FindControl("lbl2")).Text.ToString();
    //        string val_id = ((System.Web.UI.WebControls.Label)row2.FindControl("lbl_id")).Text.ToString();

    //        string Inssql1 = "UPDATE Kw_kod_industry set kod_industry='" + val1 + "',indutry_per='" + val2 + "',upd_id='" + Session["New"].ToString() + "',upd_dt='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where Id='" + val_id + "'";
    //        Status = DBCon.Ora_Execute_CommamdText(Inssql1);
    //    }
    //    if (Status == "SUCCESS")
    //    {
    //        BindData_show();
    //        ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod Berjaya Disimpan.',{'type': 'confirmation','title': 'Success','auto_close': 2000});", true);
    //    }
    //}
    //protected void Button5_Click(object sender, EventArgs e)
    //{
    //    Session["validate_success"] = "";
    //    Session["alrt_msg"] = "";
    //    Session["pro_id"] = "";
    //    Response.Redirect("../kewengan/kw_inv_pengaluaran.aspx");
    //}

    //protected void Click_bck(object sender, EventArgs e)
    //{
    //    Session["validate_success"] = "";
    //    Session["alrt_msg"] = "";
    //    Session["pro_id"] = "";
    //    Response.Redirect("../kewengan/kw_inv_pengaluaran_view.aspx");
    //}

   
}