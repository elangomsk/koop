﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Threading;

public partial class kw_lep_jurnal : System.Web.UI.Page
{
    
    DBConnection Dblog = new DBConnection();
    string cs = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    string conString = ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KSAIMBConnectionString"].ConnectionString);
    DBConnection DBCon = new DBConnection();
    private static int PageSize = 20;
    string qry1 = string.Empty, qry2 = string.Empty;
    string sqry1 = string.Empty, sqry2 = string.Empty;
    string level;
    string Status = string.Empty;
    string userid;
    string CommandArgument1 = string.Empty, CommandArgument2 = string.Empty, CommandArgument3 = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        app_language();
        Button4.OnClientClick = @"if(this.value == 'Please wait...')
           return false;
           this.value = 'Please wait...';this.disabled=true";
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.Button4);
        string script = " $(document).ready(function () { $(" + chk_lst.ClientID + ").SumoSelect({ selectAll: true }); $('.select2').select2();});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);

        if (!IsPostBack)
        {
            if (Session["New"] != null)
            {

                level = Session["level"].ToString();
                userid = Session["New"].ToString();
                bind_kod_akaun();
                BindData();
            }
            else
            {
                Response.Redirect("../KSAIMB_Login.aspx");
            }
        }
      
    }
    void app_language()

    {
        if (Session["New"] != null)
        {
            DataTable ste_set = new DataTable();
            ste_set = DBCon.Ora_Execute_table("select * from site_settings where ID IN ('1')");

            DataTable gt_lng = new DataTable();
            gt_lng = DBCon.Ora_Execute_table("select " + Session["site_languaage"].ToString() + " from Ref_language where ID IN ('1844','705','1724','64','65','824','825','121','15')");

            CultureInfo culinfo = Thread.CurrentThread.CurrentCulture;
            TextInfo txtinfo = culinfo.TextInfo;

            ps_lbl1.Text = txtinfo.ToTitleCase(gt_lng.Rows[8][0].ToString().ToLower());
            ps_lbl2.Text = txtinfo.ToTitleCase(gt_lng.Rows[5][0].ToString().ToLower());
            ps_lbl3.Text = txtinfo.ToTitleCase(gt_lng.Rows[8][0].ToString().ToLower());
            ps_lbl4.Text = txtinfo.ToTitleCase(gt_lng.Rows[7][0].ToString().ToLower());    
            ps_lbl5.Text = txtinfo.ToTitleCase(gt_lng.Rows[1][0].ToString().ToLower());
            ps_lbl6.Text = txtinfo.ToTitleCase(gt_lng.Rows[2][0].ToString().ToLower());
            ps_lbl7.Text = txtinfo.ToTitleCase(gt_lng.Rows[6][0].ToString().ToLower());
            ps_lbl8.Text = txtinfo.ToTitleCase(gt_lng.Rows[4][0].ToString().ToLower());
            Button4.Text = txtinfo.ToTitleCase(gt_lng.Rows[3][0].ToString().ToLower());
            Button1.Text = txtinfo.ToTitleCase(gt_lng.Rows[0][0].ToString().ToLower());

        }
        else
        {
            Response.Redirect("../KSAIMB_Login.aspx");
        }
    }
    protected void bind_gview(object sender, EventArgs e)
    {

        bind_kod_akaun();
        string script = " $(document).ready(function () { $(" + chk_lst.ClientID + ").SumoSelect({ selectAll: true });});";
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", script, true);
    }

    void bind_kod_akaun()
    {

        //string get_qry = string.Empty;

        //if(DropDownList1.SelectedValue =="1")
        //{
        //    get_qry = "select kod_akaun,(kod_akaun +' | '+ upper(nama_akaun)) as name from KW_Ref_Carta_Akaun where jenis_akaun_type = '1' order by kod_akaun asc";
        //}
        //else if (DropDownList1.SelectedValue == "2")
        //{
        //    get_qry = "select kod_akaun,(kod_akaun +' | '+ upper(nama_akaun)) as name from KW_Ref_Carta_Akaun inner join KW_Ref_Pelanggan on Ref_kod_akaun = kod_akaun where jenis_akaun_type != '1' order by kod_akaun asc";
        //}
        //else if (DropDownList1.SelectedValue == "3")
        //{
        //    get_qry = "select kod_akaun,(kod_akaun +' | '+ upper(nama_akaun)) as name from KW_Ref_Carta_Akaun inner join KW_Ref_Pembekal on Ref_kod_akaun = kod_akaun where jenis_akaun_type != '1' order by kod_akaun asc";
        //}
        //else
        //{

        //    get_qry = "select kod_akaun,(kod_akaun +' | '+ upper(nama_akaun)) as name from KW_Ref_Carta_Akaun where jenis_akaun_type != '1' order by kod_akaun asc";

        //}

        //DataSet ds = new DataSet();

        //string cmdstr = get_qry;

        //SqlDataAdapter adp = new SqlDataAdapter(cmdstr, con);

        //adp.Fill(ds);



        //if (ds.Tables[0].Rows.Count > 0)

        //{

        //    chk_lst.DataSource = ds.Tables[0];

        //    chk_lst.DataTextField = "name";

        //    chk_lst.DataValueField = "kod_akaun";

        //    chk_lst.DataBind();

        //}
    }
    protected void BindData()
    {

    }



    protected void clk_submit(object sender, EventArgs e)
    {
        if (Tk_mula.Text != "" && Tk_akhir.Text != "")
        {
            string rcount = string.Empty, rcount1 = string.Empty;
            int count = 0, count1 = 1;
            string ss1 = string.Empty;
            foreach (ListItem li in chk_lst.Items)
            {
                if (li.Selected == true)
                {
                    count++;
                }
                rcount = count.ToString();
            }
            string selectedValues = string.Empty;
            foreach (ListItem li in chk_lst.Items)
            {
                if (li.Selected == true)
                {
                    if (Int32.Parse(rcount) > count1)
                    {
                        ss1 = ",";
                    }
                    else
                    {
                        ss1 = "";
                    }

                    selectedValues += li.Value + ss1;

                    count1++;
                }
                rcount1 = count1.ToString();
            }

            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            string fmdate = string.Empty, fmonth = string.Empty, fyear = string.Empty, stdate = string.Empty, tmdate = string.Empty;
            if (Tk_mula.Text != "")
            {
                string fdate = Tk_mula.Text;
                DateTime fd = DateTime.ParseExact(fdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                fmdate = fd.ToString("yyyy-MM-dd");
                fmonth = fd.ToString("MM");
                fyear = fd.ToString("yyyy");
                stdate = fyear + "-01-01";
            }
            if (Tk_akhir.Text != "")
            {
                string tdate = Tk_akhir.Text;
                DateTime td = DateTime.ParseExact(tdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                tmdate = td.ToString("yyyy-MM-dd");
            }


            string tname1 = string.Empty;
            if (selectedValues != "" && Tk_mula.Text != "" && Tk_akhir.Text != "")
            {
                sqry1 = "select * from (select * from (select '05' as oby,'JURNAL PENERIMAAN' as oby_desc,FORMAT(kp.tarikh_invois,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarikh_invois as tarikh1,kg.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_invois as Ruj1,'' as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Penerimaan_invois kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois and kg.GL_type='S' left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kg.kod_akaun) as a union all select * from (select '06' as oby,'JURNAL PEMBAYARAAN' as oby_desc,FORMAT(kp.tarkih_invois,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarkih_invois as tarikh1,kg.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_invois as Ruj1,'' as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Pembayaran_invoisBil_item kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois and kg.GL_type='P' left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kg.kod_akaun) as b UNION ALL (select * from (select '04' as oby,'JURNAL AM' as oby_desc,FORMAT(kp.tarikh,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarikh as tarikh1,kp.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_rujukan as Ruj1,'' as Ruj2,kp.akaun_keterangan as description,kp.debit_amt as debit,kp.kredit_amt as kredit from KW_Pelarasan kp inner join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kp.kod_akaun) as b1) union all (select * from (select '01' as oby,'JURNAL BANK' as oby_desc,FORMAT(kp.tarikh_Payment,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarikh_Payment as tarikh1,kp.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_rujukan as Ruj1,kp.no_rujukan2 as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Penerimaan_payment kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois and kg.GL_process_dt=kp.tarikh_Payment and kg.kod_akaun !='03.14.11' left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kp.kod_akaun) as b2) union all(select * from (select '02' as oby,'JURNAL TUNAI PENERIMAAN' as oby_desc,FORMAT(kp.tarikh_Payment,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarikh_Payment as tarikh1,kp.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_rujukan as Ruj1,kp.no_rujukan2 as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Penerimaan_payment kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois and kg.GL_process_dt=kp.tarikh_Payment and kg.kod_akaun ='03.14.11' left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kp.kod_akaun) as b3) union all (select * from (select '03' as oby,'JURNAL TUNAI PEMBAYARAAN' as oby_desc,FORMAT(kp.tarkih_pv,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarkih_pv as tarikh1,kg.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.No_cek as Ruj1,kp.no_invois as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Pembayaran_Pay_voucer kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kg.kod_akaun) as b4) ) as a1 where a1.kod_akaun !='0' and a1.tarikh1>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and a1.tarikh1<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) and a1.oby IN (" + selectedValues + ") order by a1.oby,a1.tarikh1";
            }
            else if (selectedValues == "" && Tk_mula.Text != "" && Tk_akhir.Text != "")
            {
                sqry1 = "select * from (select * from (select '05' as oby,'JURNAL PENERIMAAN' as oby_desc,FORMAT(kp.tarikh_invois,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarikh_invois as tarikh1,kg.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_invois as Ruj1,'' as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Penerimaan_invois kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois and kg.GL_type='S' left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kg.kod_akaun) as a union all select * from (select '06' as oby,'JURNAL PEMBAYARAAN' as oby_desc,FORMAT(kp.tarkih_invois,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarkih_invois as tarikh1,kg.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_invois as Ruj1,'' as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Pembayaran_invoisBil_item kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois and kg.GL_type='P' left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kg.kod_akaun) as b UNION ALL (select * from (select '04' as oby,'JURNAL AM' as oby_desc,FORMAT(kp.tarikh,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarikh as tarikh1,kp.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_rujukan as Ruj1,'' as Ruj2,kp.akaun_keterangan as description,kp.debit_amt as debit,kp.kredit_amt as kredit from KW_Pelarasan kp inner join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kp.kod_akaun) as b1) union all (select * from (select '01' as oby,'JURNAL BANK' as oby_desc,FORMAT(kp.tarikh_Payment,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarikh_Payment as tarikh1,kp.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_rujukan as Ruj1,kp.no_rujukan2 as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Penerimaan_payment kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois and kg.GL_process_dt=kp.tarikh_Payment and kg.kod_akaun !='03.14.11' left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kp.kod_akaun) as b2) union all(select * from (select '02' as oby,'JURNAL TUNAI PENERIMAAN' as oby_desc,FORMAT(kp.tarikh_Payment,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarikh_Payment as tarikh1,kp.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.no_rujukan as Ruj1,kp.no_rujukan2 as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Penerimaan_payment kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois and kg.GL_process_dt=kp.tarikh_Payment and kg.kod_akaun ='03.14.11' left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kp.kod_akaun) as b3) union all (select * from (select '03' as oby,'JURNAL TUNAI PEMBAYARAAN' as oby_desc,FORMAT(kp.tarkih_pv,'dd/MM/yyyy', 'en-us') as tarikh,kp.tarkih_pv as tarikh1,kg.kod_akaun as kod_akaun,kc.nama_akaun as nama_akaun,kp.No_cek as Ruj1,kp.no_invois as Ruj2,kg.GL_desc1 as description,kg.KW_Debit_amt as debit,kg.KW_kredit_amt as kredit from KW_Pembayaran_Pay_voucer kp inner join KW_General_Ledger kg on kg.GL_invois_no=kp.no_invois left join KW_Ref_Carta_Akaun kc on kc.kod_akaun=kg.kod_akaun) as b4) ) as a1 where a1.kod_akaun !='0' and a1.tarikh1>=DATEADD(day, DATEDIFF(day, 0, '" + fmdate + "'), 0) and a1.tarikh1<=DATEADD(day, DATEDIFF(day, 0, '" + tmdate + "'), +1) order by a1.oby,a1.tarikh1";
            }




            dt = DBCon.Ora_Execute_table(sqry1);
            //dt1 = DBCon.Ora_Execute_table(sqry2);
            ds.Tables.Add(dt);
            //ds1.Tables.Add(dt1);

            string vs1 = string.Empty, vs2 = string.Empty, vs3 = string.Empty, vs4 = string.Empty, vs5 = string.Empty, vs6 = string.Empty;





            if (Tk_mula.Text != "")
            {
                vs3 = Tk_mula.Text;
            }
            else
            {
                vs3 = "-";
            }

            if (Tk_akhir.Text != "")
            {
                vs4 = Tk_akhir.Text;
            }
            else
            {
                vs4 = "-";
            }


            Rptviwerlejar.Reset();
            Rptviwerlejar.LocalReport.Refresh();
            List<DataRow> listResult = dt.AsEnumerable().ToList();
            listResult.Count();
            int countRow = 0;
            countRow = listResult.Count();



            Rptviwerlejar.LocalReport.DataSources.Clear();
            if (countRow != 0)
            {
                //DataTable cnt_open = new DataTable();

                //cnt_open = DBCon.Ora_Execute_table(sqry2);
                if (rpt_type.SelectedValue == "01")
                {
                    Rptviwerlejar.LocalReport.ReportPath = "kewengan/KW_lep_journal.rdlc";
                }
                else
                {
                    Rptviwerlejar.LocalReport.ReportPath = "kewengan/KW_lep_journal_ls.rdlc";
                }
                ReportDataSource rds = new ReportDataSource("DataSet1", dt);
                //ReportDataSource rds1 = new ReportDataSource("kwlegar1", dt1);
                ReportParameter[] rptParams = new ReportParameter[]{
                     new ReportParameter("s1", ""),
                     new ReportParameter("s2", ""),
                     new ReportParameter("s3", Tk_mula.Text),
                     new ReportParameter("s4", Tk_akhir.Text),
                     new ReportParameter("S5", "")
                          };

                Rptviwerlejar.LocalReport.SetParameters(rptParams);
                Rptviwerlejar.LocalReport.DataSources.Add(rds);
                //Rptviwerlejar.LocalReport.DataSources.Add(rds1);
                Rptviwerlejar.LocalReport.DisplayName = "JURNAL_" + DateTime.Now.ToString("yyyyMMdd");
                Rptviwerlejar.LocalReport.Refresh();

                //Warning[] warnings;

                //string[] streamids;

                //string mimeType;

                //string encoding;

                //string extension;

                //string fname = DateTime.Now.ToString("dd_MM_yyyy");

                //string devinfo = "<DeviceInfo><ColorDepth>32</ColorDepth><DpiX>350</DpiX><DpiY>350</DpiY><OutputFormat>PDF</OutputFormat>" +
                //       "  <PageWidth>12.20in</PageWidth>" +
                //        "  <PageHeight>8.27in</PageHeight>" +
                //        "  <MarginTop>0.1in</MarginTop>" +
                //        "  <MarginLeft>0.5in</MarginLeft>" +
                //         "  <MarginRight>0in</MarginRight>" +
                //         "  <MarginBottom>0in</MarginBottom>" +
                //       "</DeviceInfo>";

                //byte[] bytes = Rptviwerlejar.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamids, out warnings);

                //Response.Buffer = true;
                //Response.Clear();
                //Response.ContentType = mimeType;
                //Response.AddHeader("content-disposition", "Attatchment; filename=Lejar_AM" + DateTime.Now.ToString("ddMMyyyy") +"." + extension);
                //Response.BinaryWrite(bytes);
                //Response.Flush();
                //Response.End();

            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Rekod tidak dijumpai. Sila Pastikan Semua Maklumat Dimasukkan Dengan Betul.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
            }

        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "$.Zebra_Dialog('Sila Masukan Input Carian.',{'type': 'warning','title': 'warning','auto_close': 2000});", true);
        }
    }



   
    protected void btn_reset(object sender, EventArgs e)
    {
        Response.Redirect("../kewengan/kw_lep_jurnal.aspx");
    }


}